cd ../build
make
../bin/compiler ../mytest/myinput.sy -s2 -o ../mytest/myoutput.out