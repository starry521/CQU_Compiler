cd ../build
make
../bin/compiler ../mytest/myinput.sy -e -o ../mytest/myoutput2.out