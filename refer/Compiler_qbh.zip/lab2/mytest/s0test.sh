cd ../build
make
../bin/compiler ../mytest/myinput.sy -s0 -o ../mytest/myoutput.out