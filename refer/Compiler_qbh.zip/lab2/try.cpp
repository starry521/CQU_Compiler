#include<bits/stdc++.h>
using namespace std;

//test break
//test continue
int main() {
    string s = "0x40";
    int a = stoi(s);
    cout << a << endl;
    return 0;
}