#include "front/semantic.h"

#include <cassert>

using ir::Function;
using ir::Instruction;
using ir::Operand;
using ir::Operator;

#define TODO assert(0 && "TODO");

#define GET_CHILD_PTR(node, type, index)                     \
    auto node = dynamic_cast<type *>(root->children[index]); \
    assert(node);
#define ANALYSIS(node, type, index)                          \
    auto node = dynamic_cast<type *>(root->children[index]); \
    assert(node);                                            \
    analysis##type(node, buffer);
#define COPY_EXP_NODE(from, to)              \
    to->is_computable = from->is_computable; \
    to->v = from->v;                         \
    to->t = from->t;

map<std::string, ir::Function *> *frontend::get_lib_funcs()
{
    static map<std::string, ir::Function *> lib_funcs = {
        {"getint", new Function("getint", Type::Int)},
        {"getch", new Function("getch", Type::Int)},
        {"getfloat", new Function("getfloat", Type::Float)},
        {"getarray", new Function("getarray", {Operand("arr", Type::IntPtr)}, Type::Int)},
        {"getfarray", new Function("getfarray", {Operand("arr", Type::FloatPtr)}, Type::Int)},
        {"putint", new Function("putint", {Operand("i", Type::Int)}, Type::null)},
        {"putch", new Function("putch", {Operand("i", Type::Int)}, Type::null)},
        {"putfloat", new Function("putfloat", {Operand("f", Type::Float)}, Type::null)},
        {"putarray", new Function("putarray", {Operand("n", Type::Int), Operand("arr", Type::IntPtr)}, Type::null)},
        {"putfarray", new Function("putfarray", {Operand("n", Type::Int), Operand("arr", Type::FloatPtr)}, Type::null)},
    };
    return &lib_funcs;
}

void frontend::SymbolTable::add_scope()
{
    ScopeInfo scope_info;
    scope_info.cnt = 0;
    scope_info.name = "block " + std::to_string(scope_stack.size());
    scope_stack.push_back(scope_info);
}
void frontend::SymbolTable::exit_scope()
{
    scope_stack.pop_back();
}

string frontend::SymbolTable::get_scoped_name(string id) const
{
    for (auto it = scope_stack.rbegin(); it != scope_stack.rend(); it++)
    {
        auto scope = *it;
        if (scope.table.find(id) != scope.table.end())
        {
            return scope.name + "_" + id;
        }
    }
}

Operand frontend::SymbolTable::get_operand(string id) const
{
    for (auto it = scope_stack.rbegin(); it != scope_stack.rend(); it++)
    {
        auto scope = *it;
        if (scope.table.find(id) != scope.table.end())
        {
            return scope.table.at(id).operand;
        }
    }
}

frontend::STE frontend::SymbolTable::get_ste(string id) const
{
    for (auto it = scope_stack.rbegin(); it != scope_stack.rend(); it++)
    {
        auto scope = *it;
        if (scope.table.find(id) != scope.table.end())
        {
            return scope.table.at(id);
        }
    }
}

frontend::Analyzer::Analyzer() : tmp_cnt(0), symbol_table()
{
    // add lib functions
    auto lib_funcs = get_lib_funcs();
    for (auto &func : *lib_funcs)
    {
        symbol_table.functions[func.first] = func.second;
    }
}

ir::Program frontend::Analyzer::get_ir_program(CompUnit *root)
{
}

// CompUnit -> (Decl | FuncDef) [CompUnit]
void frontend::Analyzer::analysisCompUnit(CompUnit *root, vector<ir::Instruction *> &buffer)
{

    if (root->children.size() == 1)
    {
        if (root->children[0]->type == NodeType::DECL)
        {
            analysisDecl(dynamic_cast<Decl *>(root->children[0]), buffer);
        }
        else if (root->children[0]->type == NodeType::FUNCDEF)
        {
            analysisFuncDef(dynamic_cast<FuncDef *>(root->children[0]), buffer);
        }
        else
        {
            assert(0);
        }
    }
}

/*
FuncDef -> FuncType Ident '(' [FuncFParams] ')' Block
*/
void frontend::Analyzer::analysisFuncDef(FuncDef *root, ir::Function &func)
{
    for (auto child : root->children)
    {
        if (child->type == NodeType::FUNCFPARAMS)
        {
            analysisFuncFParams(dynamic_cast<FuncFParams *>(child), );
        }
        else if (child->type == NodeType::BLOCK)
        {
            analysisBlock(dynamic_cast<Block *>(child), );
        }
        else
        {
            assert(0);
        }
    }
}

// BType -> 'int' | 'float'
void frontend::Analyzer::analysisBType(BType *root)
{
    return;
}
// Decl -> ConstDecl | VarDecl
void frontend::Analyzer::analysisDecl(Decl *root, vector<ir::Instruction *> &buffer)
{
    if (root->children[0]->type == NodeType::CONSTDECL)
    {
        ANALYSIS(constdecl, ConstDecl, 0);
    }
    else if (root->children[0]->type == NodeType::VARDECL)
    {
        ANALYSIS(vardecl, VarDecl, 0);
    }
}

// ConstDecl -> 'const' BType ConstDef { ',' ConstDef } ';'
void frontend::Analyzer::analysisConstDecl(ConstDecl *root, vector<ir::Instruction *> &buffer)
{
    GET_CHILD_PTR(btype, BType, 1);
    Term *bt = dynamic_cast<Term *>(btype->children[0]);
    root->t = bt->token.type == TokenType::INTTK ? Type::Int : Type::Float;
    ANALYSIS(constdef, ConstDef, 2);
    for (int i = 2; i < root->children.size(); i = i + 2)
    {
        GET_CHILD_PTR(term, Term, i);
        if (term->token.type == TokenType::SEMICN)
            break;
        ANALYSIS(constdef, ConstDef, i + 1);
    }
}

// ConstDef -> Ident { '[' ConstExp ']' } '=' ConstInitVal
void frontend::Analyzer::analysisConstDef(ConstDef *root, vector<ir::Instruction *> &buffer)
{
    ConstDecl *parent = dynamic_cast<ConstDecl *>(root->parent);
    Type ident_type = parent->t;
    GET_CHILD_PTR(ident, Term, 0);
    string Ident_name = ident->token.value;
    STE ste;
    Operand ident_operand = Operand(Ident_name, ident_type);
    if (root->children.size() > 1)
    {
        GET_CHILD_PTR(term_0, Term, 1);
        if (term_0->token.type == TokenType::LBRACK)
        {
            if (ident_operand.type == Type::Int)
                ident_operand.type = Type::IntPtr;
            else if (ident_operand.type == Type::Float)
                ident_operand.type = Type::FloatPtr;
            GET_CHILD_PTR(constexp_1, ConstExp, 2);
            ste.dimension.push_back(std::stoi(constexp_1->v));
            if (root->children.size() > 4)
            {
                GET_CHILD_PTR(term_1, Term, 4);
                if (term_1->token.type == TokenType::LBRACK)
                {
                    GET_CHILD_PTR(constexp_2, ConstExp, 5);
                    ste.dimension.push_back(std::stoi(constexp_2->v));
                }
            }
        }
    }
    ste.operand = ident_operand;
    symbol_table.scope_stack.back().table[Ident_name] = ste;
    string ident_after_rename = symbol_table.get_scoped_name(Ident_name);

    GET_CHILD_PTR(term_0, Term, 1);
    // const int/float a = ...;
    if (term_0->token.type == TokenType::ASSIGN)
    {
        ANALYSIS(constinitval, ConstInitVal, 2);
        string initval_value = constinitval->v;
        if (ident_type == Type::Int)
        {
            if (constinitval->t == Type::IntLiteral)
                buffer.push_back(new Instruction(Operand(initval_value, Type::IntLiteral),
                                                 Operand(),
                                                 Operand(ident_after_rename, Type::Int),
                                                 Operator::def));
            else if (constinitval->t == Type::Int)
                buffer.push_back(new Instruction(Operand(initval_value, Type::Int),
                                                 Operand(),
                                                 Operand(ident_after_rename, Type::Int),
                                                 Operator::def));
            else if (constinitval->t == Type::FloatLiteral)
            {
                string temp_float = "temp" + std::to_string(tmp_cnt++);
                buffer.push_back(new Instruction(Operand(initval_value, Type::FloatLiteral),
                                                 Operand(),
                                                 Operand(temp_float, Type::Float),
                                                 Operator::fdef));
                buffer.push_back(new Instruction(Operand(temp_float, Type::Float),
                                                 Operand(),
                                                 Operand(ident_after_rename, Type::Int),
                                                 Operator::cvt_f2i));
            }
            else if (constinitval->t == Type::Float)
                buffer.push_back(new Instruction(Operand(initval_value, Type::Float),
                                                 Operand(),
                                                 Operand(ident_after_rename, Type::Int),
                                                 Operator::cvt_f2i));
        }
        else if (ident_type == Type::Float)
        {
            if (constinitval->t == Type::FloatLiteral)
                buffer.push_back(new Instruction(Operand(initval_value, Type::FloatLiteral),
                                                 Operand(),
                                                 Operand(ident_after_rename, Type::Float),
                                                 Operator::fdef));
            else if (constinitval->t == Type::Float)
                buffer.push_back(new Instruction(Operand(initval_value, Type::Float),
                                                 Operand(),
                                                 Operand(ident_after_rename, Type::Float),
                                                 Operator::fdef));
            else if (constinitval->t == Type::IntLiteral)
            {
                string temp_int = "temp" + std::to_string(tmp_cnt++);
                buffer.push_back(new Instruction(Operand(initval_value, Type::IntLiteral),
                                                 Operand(),
                                                 Operand(temp_int, Type::Int),
                                                 Operator::def));
                buffer.push_back(new Instruction(Operand(temp_int, Type::IntLiteral),
                                                 Operand(),
                                                 Operand(ident_after_rename, Type::Float),
                                                 Operator::cvt_i2f));
            }
            else if (constinitval->t == Type::Int)
                buffer.push_back(new Instruction(Operand(initval_value, Type::Int),
                                                 Operand(),
                                                 Operand(ident_after_rename, Type::Float),
                                                 Operator::cvt_i2f));
        }
    }
    else if (term_0->token.type == TokenType::LBRACK)
    {
        int ident_array_dim = ste.dimension.size();
        int allco_size;
        allco_size = ident_array_dim == 1 ? ste.dimension[0] : ste.dimension[0] * ste.dimension[1];
        buffer.push_back(new Instruction(Operand(std::to_string(allco_size), Type::IntLiteral),
                                         Operand(),
                                         Operand(ident_after_rename, ident_operand.type),
                                         Operator::alloc));

        // int/float a[3]={1,2,3};
        // int/float a[2][3]={1,2,3,4,5,6};

        ANALYSIS(constinitval, ConstInitVal, root->children.size() - 2);
        string temp_var_list = constinitval->v;
        Type var_type = constinitval->t;
        string temp_var_name = "";
        int j = 0;
        for (int i = 0; i < constinitval->v.size(); i++)
        {
            if (constinitval->v[i] == ',')
            {
                buffer.push_back(new Instruction(Operand(ident_after_rename, ident_operand.type),
                                                 Operand(std::to_string(j), Type::IntLiteral),
                                                 Operand(temp_var_name, ident_type),
                                                 Operator::store));
                j++;
                temp_var_name = "";
            }
            else
                temp_var_name += temp_var_list[i];
        }
    }
}

// ConstInitVal -> ConstExp | '{' [ ConstInitVal { ',' ConstInitVal } ] '}'
void frontend::Analyzer::analysisConstInitVal(ConstInitVal *root, vector<ir::Instruction *> &buffer)
{
    if (root->children.size() == 1)
    {
        ANALYSIS(constexp, ConstExp, 0);
        root->v = constexp->v;
        root->t = constexp->t;
    }
    else
    {
        ConstDef *const_def = dynamic_cast<ConstDef *>(root->parent);
        VarDecl *const_decl = dynamic_cast<VarDecl *>(const_def->parent);
        string var_name_list = "";
        for (int i = 0; i < root->children.size() - 1; i += 2)
        {
            ANALYSIS(constinitval_i, ConstInitVal, i);
            string constinitval_v = constinitval_i->v;
            Type constinitval_t = constinitval_i->t;
            if (const_decl->t == Type::Int)
            {
                if (constinitval_t == Type::Int)
                    var_name_list = var_name_list + constinitval_i->v + ",";
                else if (constinitval_t == Type::Float)
                {
                    string temp_int = "temp" + std::to_string(tmp_cnt++);
                    buffer.push_back(new Instruction(Operand(constinitval_v, Type::Float),
                                                     Operand(),
                                                     Operand(temp_int, Type::Int),
                                                     Operator::cvt_f2i));
                    var_name_list = var_name_list + temp_int + ",";
                }
                else if (constinitval_t == Type::IntLiteral)
                {
                    string temp_int = "temp" + std::to_string(tmp_cnt++);
                    buffer.push_back(new Instruction(Operand(constinitval_v, Type::IntLiteral),
                                                     Operand(),
                                                     Operand(temp_int, Type::Int),
                                                     Operator::def));
                    var_name_list = var_name_list + temp_int + ",";
                }
                else if (constinitval_t == Type::FloatLiteral)
                {
                    string temp_int = "temp" + std::to_string(tmp_cnt++);
                    buffer.push_back(new Instruction(Operand(std::to_string(int(std::stof(constinitval_v))), Type::IntLiteral),
                                                     Operand(),
                                                     Operand(temp_int, Type::Int),
                                                     Operator::def));
                    var_name_list = var_name_list + temp_int + ",";
                }
            }
            else if (const_decl->t == Type::Float)
            {
                if (constinitval_t == Type::Float)
                    var_name_list = var_name_list + constinitval_i->v + ",";
                else if (constinitval_t == Type::Int)
                {
                    string temp_float = "temp" + std::to_string(tmp_cnt++);
                    buffer.push_back(new Instruction(Operand(constinitval_v, Type::Int),
                                                     Operand(),
                                                     Operand(temp_float, Type::Float),
                                                     Operator::cvt_i2f));
                    var_name_list = var_name_list + temp_float + ",";
                }
                else if (constinitval_t == Type::IntLiteral)
                {
                    string temp_float = "temp" + std::to_string(tmp_cnt++);
                    buffer.push_back(new Instruction(Operand(constinitval_v, Type::IntLiteral),
                                                     Operand(),
                                                     Operand(temp_float, Type::Float),
                                                     Operator::fdef));
                    var_name_list = var_name_list + temp_float + ",";
                }
                else if (constinitval_t == Type::FloatLiteral)
                {
                    string temp_float = "temp" + std::to_string(tmp_cnt++);
                    buffer.push_back(new Instruction(Operand(std::to_string(float(std::stoi(constinitval_v))), Type::FloatLiteral),
                                                     Operand(),
                                                     Operand(temp_float, Type::Float),
                                                     Operator::fdef));
                    var_name_list = var_name_list + temp_float + ",";
                }
            }
        }
        root->v = var_name_list;
        root->t = const_decl->t;
    }
}

// VarDecl -> BType VarDef { ',' VarDef } ';'
void frontend::Analyzer::analysisVarDecl(VarDecl *root, vector<ir::Instruction *> &buffer)
{
    GET_CHILD_PTR(btype, BType, 0);
    Term *bt = dynamic_cast<Term *>(btype->children[0]);
    root->t = bt->token.type == TokenType::INTTK ? Type::Int : Type::Float;
    ANALYSIS(vardef, VarDef, 1);
    for (int i = 2; i < root->children.size(); i += 2)
    {
        GET_CHILD_PTR(term, Term, i);
        if (term->token.type == TokenType::SEMICN)
            break;
        ANALYSIS(vardef, VarDef, i + 1);
    }
}

// VarDef -> Ident { '[' ConstExp ']' } [ '=' InitVal ]
void frontend::Analyzer::analysisVarDef(VarDef *root, vector<ir::Instruction *> &buffer)
{
    VarDecl *parent = dynamic_cast<VarDecl *>(root->parent);
    Type ident_type = parent->t;
    GET_CHILD_PTR(ident, Term, 0);
    string Ident_name = ident->token.value;
    STE ste;
    Operand ident_operand = Operand(Ident_name, ident_type);
    if (root->children.size() > 1)
    {
        GET_CHILD_PTR(term_0, Term, 1);
        if (term_0->token.type == TokenType::LBRACK)
        {
            if (ident_operand.type == Type::Int)
                ident_operand.type = Type::IntPtr;
            else if (ident_operand.type == Type::Float)
                ident_operand.type = Type::FloatPtr;
            GET_CHILD_PTR(constexp_1, ConstExp, 2);
            ste.dimension.push_back(std::stoi(constexp_1->v));
            if (root->children.size() > 4)
            {
                GET_CHILD_PTR(term_1, Term, 4);
                if (term_1->token.type == TokenType::LBRACK)
                {
                    GET_CHILD_PTR(constexp_2, ConstExp, 5);
                    ste.dimension.push_back(std::stoi(constexp_2->v));
                }
            }
        }
    }
    ste.operand = ident_operand;
    symbol_table.scope_stack.back().table[Ident_name] = ste;
    string ident_after_rename = symbol_table.get_scoped_name(Ident_name);

    // int/float a;
    if (root->children.size() == 1)
    {
        if (ident_operand.type == Type::Int)
            buffer.push_back(new Instruction(Operand("0", Type::IntLiteral),
                                             Operand(),
                                             Operand(ident_after_rename, Type::Int),
                                             Operator::def));
        else if (ident_operand.type == Type::Float)
            buffer.push_back(new Instruction(Operand("0.0", Type::FloatLiteral),
                                             Operand(),
                                             Operand(ident_after_rename, Type::Float),
                                             Operator::fdef));
    }
    else
    {
        GET_CHILD_PTR(term_0, Term, 1);
        // int/float a = ...;
        if (term_0->token.type == TokenType::ASSIGN)
        {
            ANALYSIS(initval, InitVal, 2);
            string initval_value = initval->v;
            if (ident_type == Type::Int)
            {
                if (initval->t == Type::IntLiteral)
                    buffer.push_back(new Instruction(Operand(initval_value, Type::IntLiteral),
                                                     Operand(),
                                                     Operand(ident_after_rename, Type::Int),
                                                     Operator::def));
                else if (initval->t == Type::Int)
                    buffer.push_back(new Instruction(Operand(initval_value, Type::Int),
                                                     Operand(),
                                                     Operand(ident_after_rename, Type::Int),
                                                     Operator::def));
                else if (initval->t == Type::FloatLiteral)
                {
                    string temp_float = "temp" + std::to_string(tmp_cnt++);
                    buffer.push_back(new Instruction(Operand(initval_value, Type::FloatLiteral),
                                                     Operand(),
                                                     Operand(temp_float, Type::Float),
                                                     Operator::fdef));
                    buffer.push_back(new Instruction(Operand(temp_float, Type::Float),
                                                     Operand(),
                                                     Operand(ident_after_rename, Type::Int),
                                                     Operator::cvt_f2i));
                }
                else if (initval->t == Type::Float)
                    buffer.push_back(new Instruction(Operand(initval_value, Type::Float),
                                                     Operand(),
                                                     Operand(ident_after_rename, Type::Int),
                                                     Operator::cvt_f2i));
            }
            else if (ident_type == Type::Float)
            {
                if (initval->t == Type::FloatLiteral)
                    buffer.push_back(new Instruction(Operand(initval_value, Type::FloatLiteral),
                                                     Operand(),
                                                     Operand(ident_after_rename, Type::Float),
                                                     Operator::fdef));
                else if (initval->t == Type::Float)
                    buffer.push_back(new Instruction(Operand(initval_value, Type::Float),
                                                     Operand(),
                                                     Operand(ident_after_rename, Type::Float),
                                                     Operator::fdef));
                else if (initval->t == Type::IntLiteral)
                {
                    string temp_int = "temp" + std::to_string(tmp_cnt++);
                    buffer.push_back(new Instruction(Operand(initval_value, Type::IntLiteral),
                                                     Operand(),
                                                     Operand(temp_int, Type::Int),
                                                     Operator::def));
                    buffer.push_back(new Instruction(Operand(temp_int, Type::IntLiteral),
                                                     Operand(),
                                                     Operand(ident_after_rename, Type::Float),
                                                     Operator::cvt_i2f));
                }
                else if (initval->t == Type::Int)
                    buffer.push_back(new Instruction(Operand(initval_value, Type::Int),
                                                     Operand(),
                                                     Operand(ident_after_rename, Type::Float),
                                                     Operator::cvt_i2f));
            }
        }
        else if (term_0->token.type == TokenType::LBRACK)
        {
            int ident_array_dim = ste.dimension.size();
            int allco_size;
            allco_size = ident_array_dim == 1 ? ste.dimension[0] : ste.dimension[0] * ste.dimension[1];
            buffer.push_back(new Instruction(Operand(std::to_string(allco_size), Type::IntLiteral),
                                             Operand(),
                                             Operand(ident_after_rename, ident_operand.type),
                                             Operator::alloc));
            // int/float a[10];
            // 申请空间后什么都不做

            // //int/float a[10]={};
            // inr/float a[10][10]={};
            if (root->children.size() == 7 || root->children.size() == 10)
            {
                for (int i = 0; i < allco_size; i++)
                    buffer.push_back(new Instruction(Operand(ident_after_rename, ident_operand.type),
                                                     Operand(std::to_string(i), Type::IntLiteral),
                                                     Operand(ident_type == Type::Int ? "0" : "0.0", ident_type == Type::Int ? Type::IntLiteral : Type::FloatLiteral),
                                                     Operator::store));
            }

            // int/float a[3]={1,2,3};
            // int/float a[2][3]={1,2,3,4,5,6};
            else if (root->children.size() == 8 || root->children.size() == 11)
            {
                ANALYSIS(initval, InitVal, root->children.size() - 2);
                string temp_var_list = initval->v;
                Type var_type = initval->t;
                string temp_var_name = "";
                int j = 0;
                for (int i = 0; i < initval->v.size(); i++)
                {
                    if (initval->v[i] == ',')
                    {
                        buffer.push_back(new Instruction(Operand(ident_after_rename, ident_operand.type),
                                                         Operand(std::to_string(j), Type::IntLiteral),
                                                         Operand(temp_var_name, ident_type),
                                                         Operator::store));
                        j++;
                        temp_var_name = "";
                    }
                    else
                        temp_var_name += temp_var_list[i];
                }
            }
        }
    }
}

// ConstExp -> AddExp
void frontend::Analyzer::analysisConstExp(ConstExp *root, vector<ir::Instruction *> &buffer)
{
    ANALYSIS(addexp, AddExp, 0);
    COPY_EXP_NODE(addexp, root);
}

// InitVal -> Exp | '{' [ InitVal { ',' InitVal } ] '}'
void frontend::Analyzer::analysisInitVal(InitVal *root, vector<ir::Instruction *> &buffer)
{
    if (root->children.size() == 1)
    {
        ANALYSIS(exp, Exp, 0);
        COPY_EXP_NODE(exp, root);
    }
    else
    {
        VarDef *var_def = dynamic_cast<VarDef *>(root->parent);
        VarDecl *var_decl = dynamic_cast<VarDecl *>(var_def->parent);
        string var_name_list = "";
        for (int i = 0; i < root->children.size() - 1; i += 2)
        {
            ANALYSIS(initval_i, InitVal, i);
            string initval_v = initval_i->v;
            Type initval_t = initval_i->t;
            if (var_decl->t == Type::Int)
            {
                if (initval_t == Type::Int)
                    var_name_list = var_name_list + initval_i->v + ",";
                else if (initval_t == Type::Float)
                {
                    string temp_int = "temp" + std::to_string(tmp_cnt++);
                    buffer.push_back(new Instruction(Operand(initval_v, Type::Float),
                                                     Operand(),
                                                     Operand(temp_int, Type::Int),
                                                     Operator::cvt_f2i));
                    var_name_list = var_name_list + temp_int + ",";
                }
                else if (initval_t == Type::IntLiteral)
                {
                    string temp_int = "temp" + std::to_string(tmp_cnt++);
                    buffer.push_back(new Instruction(Operand(initval_v, Type::IntLiteral),
                                                     Operand(),
                                                     Operand(temp_int, Type::Int),
                                                     Operator::def));
                    var_name_list = var_name_list + temp_int + ",";
                }
                else if (initval_t == Type::FloatLiteral)
                {
                    string temp_int = "temp" + std::to_string(tmp_cnt++);
                    buffer.push_back(new Instruction(Operand(std::to_string(int(std::stof(initval_v))), Type::IntLiteral),
                                                     Operand(),
                                                     Operand(temp_int, Type::Int),
                                                     Operator::def));
                    var_name_list = var_name_list + temp_int + ",";
                }
            }
            else if (var_decl->t == Type::Float)
            {
                if (initval_t == Type::Float)
                    var_name_list = var_name_list + initval_i->v + ",";
                else if (initval_t == Type::Int)
                {
                    string temp_float = "temp" + std::to_string(tmp_cnt++);
                    buffer.push_back(new Instruction(Operand(initval_v, Type::Int),
                                                     Operand(),
                                                     Operand(temp_float, Type::Float),
                                                     Operator::cvt_i2f));
                    var_name_list = var_name_list + temp_float + ",";
                }
                else if (initval_t == Type::IntLiteral)
                {
                    string temp_float = "temp" + std::to_string(tmp_cnt++);
                    buffer.push_back(new Instruction(Operand(initval_v, Type::IntLiteral),
                                                     Operand(),
                                                     Operand(temp_float, Type::Float),
                                                     Operator::fdef));
                    var_name_list = var_name_list + temp_float + ",";
                }
                else if (initval_t == Type::FloatLiteral)
                {
                    string temp_float = "temp" + std::to_string(tmp_cnt++);
                    buffer.push_back(new Instruction(Operand(std::to_string(float(std::stoi(initval_v))), Type::FloatLiteral),
                                                     Operand(),
                                                     Operand(temp_float, Type::Float),
                                                     Operator::fdef));
                    var_name_list = var_name_list + temp_float + ",";
                }
            }
        }
        root->v = var_name_list;
        root->t = var_decl->t;
    }
}

// Exp -> AddExp
void frontend::Analyzer::analysisExp(Exp *root, vector<ir::Instruction *> &buffer)
{
    ANALYSIS(addexp, AddExp, 0);
    COPY_EXP_NODE(addexp, root);
}

// AddExp -> MulExp { ('+' | '-') MulExp }
void frontend::Analyzer::analysisAddExp(AddExp *root, vector<ir::Instruction *> &buffer)
{
    ANALYSIS(mulexp_0, MulExp, 0);
    COPY_EXP_NODE(mulexp_0, root);
    for (int i = 1; i < root->children.size(); i = i + 2)
    {
        GET_CHILD_PTR(term, Term, i);
        ANALYSIS(mulexp_i, MulExp, i + 1);
        string op = term->token.value;
        if (root->t != mulexp_i->t)
        {

            if (mulexp_i->t == Type::Float && root->t == Type::IntLiteral)
            {
                string temp_result = "temp" + std::to_string(tmp_cnt++);
                buffer.push_back(new Instruction(Operand(std::to_string(float(std::stoi(root->v))), Type::FloatLiteral),
                                                 Operand(),
                                                 Operand(temp_result, Type::Float),
                                                 Operator::fdef));
                buffer.push_back(new Instruction(Operand(temp_result, Type::Float),
                                                 Operand(mulexp_i->v, Type::Float),
                                                 Operand(temp_result, Type::Float),
                                                 op == "+" ? Operator::add : Operator::sub));
                root->v = temp_result;
                root->t = Type::Float;
            }
            else if (mulexp_i->t == Type::Float && root->t == Type::FloatLiteral)
            {
                string temp_result = "temp" + std::to_string(tmp_cnt++);
                buffer.push_back(new Instruction(Operand(root->v, Type::FloatLiteral),
                                                 Operand(),
                                                 Operand(temp_result, Type::Float),
                                                 Operator::fdef));
                buffer.push_back(new Instruction(Operand(root->v, Type::Float),
                                                 Operand(mulexp_i->v, Type::Float),
                                                 Operand(temp_result, Type::Float),
                                                 op == "+" ? Operator::add : Operator::sub));
                root->v = temp_result;
                root->t = Type::Float;
            }
            else if (mulexp_i->t == Type::Float && root->t == Type::Int)
            {
                buffer.push_back(new Instruction(Operand(root->v, Type::Int),
                                                 Operand(),
                                                 Operand(root->v, Type::Float),
                                                 Operator::cvt_i2f));
                buffer.push_back(new Instruction(Operand(root->v, Type::Float),
                                                 Operand(mulexp_i->v, Type::Float),
                                                 Operand(root->v, Type::Float),
                                                 op == "+" ? Operator::add : Operator::sub));
                root->t = Type::Float;
            }
            else if (mulexp_i->t == Type::Float && root->t == Type::Float)
            {
                buffer.push_back(new Instruction(Operand(root->v, Type::Float),
                                                 Operand(mulexp_i->v, Type::Float),
                                                 Operand(root->v, Type::Float),
                                                 op == "+" ? Operator::add : Operator::sub));
            }
            else if (mulexp_i->t == Type::FloatLiteral && root->t == Type::IntLiteral)
            {
                if (op == "+")
                    root->v = std::to_string(std::stoi(root->v) + std::stof(mulexp_i->v));
                else if (op == "-")
                    root->v = std::to_string(std::stoi(root->v) - std::stof(mulexp_i->v));
                root->t = Type::FloatLiteral;
            }
            else if (mulexp_i->t == Type::FloatLiteral && root->t == Type::FloatLiteral)
            {
                if (op == "+")
                    root->v = std::to_string(std::stof(root->v) + std::stof(mulexp_i->v));
                else if (op == "-")
                    root->v = std::to_string(std::stof(root->v) - std::stof(mulexp_i->v));
            }
            else if (mulexp_i->t == Type::FloatLiteral && root->t == Type::Int)
            {
                string temp_result = "temp" + std::to_string(tmp_cnt++);
                string temp_float = "temp" + std::to_string(tmp_cnt++);
                buffer.push_back(new Instruction(Operand(root->v, Type::Int),
                                                 Operand(),
                                                 Operand(temp_result, Type::Float),
                                                 Operator::cvt_i2f));
                buffer.push_back(new Instruction(Operand(mulexp_i->v, Type::FloatLiteral),
                                                 Operand(),
                                                 Operand(temp_float, Type::Float),
                                                 Operator::fdef));
                buffer.push_back(new Instruction(Operand(temp_result, Type::Float),
                                                 Operand(temp_float, Type::Float),
                                                 Operand(temp_result, Type::Float),
                                                 op == "+" ? Operator::add : Operator::sub));
                root->v = temp_result;
                root->t = Type::Float;
            }
            else if (mulexp_i->t == Type::FloatLiteral && root->t == Type::Float)
            {
                string temp_float = "temp" + std::to_string(tmp_cnt++);
                buffer.push_back(new Instruction(Operand(mulexp_i->v, Type::FloatLiteral),
                                                 Operand(),
                                                 Operand(temp_float, Type::Float),
                                                 Operator::fdef));
                buffer.push_back(new Instruction(Operand(root->v, Type::Float),
                                                 Operand(temp_float, Type::Float),
                                                 Operand(root->v, Type::Float),
                                                 op == "+" ? Operator::add : Operator::sub));
            }
            else if (mulexp_i->t == Type::IntLiteral && root->t == Type::IntLiteral)
            {
                if (op == "+")
                    root->v = std::to_string(std::stoi(root->v) + std::stoi(mulexp_i->v));
                else if (op == "-")
                    root->v = std::to_string(std::stoi(root->v) - std::stoi(mulexp_i->v));
            }
            else if (mulexp_i->t == Type::IntLiteral && root->t == Type::FloatLiteral)
            {
                if (op == "+")
                    root->v = std::to_string(std::stoi(root->v) + std::stof(mulexp_i->v));
                else if (op == "-")
                    root->v = std::to_string(std::stoi(root->v) - std::stof(mulexp_i->v));
                root->t = Type::FloatLiteral;
            }
            else if (mulexp_i->t == Type::IntLiteral && root->t == Type::Int)
            {
                string temp_int = "temp" + std::to_string(tmp_cnt++);
                buffer.push_back(new Instruction(Operand(mulexp_i->v, Type::IntLiteral),
                                                 Operand(),
                                                 Operand(temp_int, Type::Int),
                                                 Operator::def));
                buffer.push_back(new Instruction(Operand(root->v, Type::Int),
                                                 Operand(temp_int, Type::Int),
                                                 Operand(root->v, Type::Int),
                                                 op == "+" ? Operator::add : Operator::sub));
            }
            else if (mulexp_i->t == Type::IntLiteral && root->t == Type::Float)
            {
                string temp_int = "temp" + std::to_string(tmp_cnt++);
                buffer.push_back(new Instruction(Operand(mulexp_i->v, Type::IntLiteral),
                                                 Operand(),
                                                 Operand(temp_int, Type::Int),
                                                 Operator::def));
                buffer.push_back(new Instruction(Operand(root->v, Type::Float),
                                                 Operand(temp_int, Type::Int),
                                                 Operand(root->v, Type::Float),
                                                 op == "+" ? Operator::add : Operator::sub));
            }
            else if (mulexp_i->t == Type::Int && root->t == Type::FloatLiteral)
            {
                string temp_result = "temp" + std::to_string(tmp_cnt++);
                string temp_float = "temp" + std::to_string(tmp_cnt++);
                buffer.push_back(new Instruction(Operand(root->v, Type::FloatLiteral),
                                                 Operand(),
                                                 Operand(temp_result, Type::Float),
                                                 Operator::fdef));
                buffer.push_back(new Instruction(Operand(mulexp_i->v, Type::Int),
                                                 Operand(),
                                                 Operand(temp_float, Type::Float),
                                                 Operator::cvt_i2f));
                buffer.push_back(new Instruction(Operand(temp_result, Type::Float),
                                                 Operand(temp_float, Type::Float),
                                                 Operand(temp_result, Type::Float),
                                                 op == "+" ? Operator::add : Operator::sub));
                root->v = temp_result;
                root->t = Type::Float;
            }
            else if (mulexp_i->t == Type::Int && root->t == Type::IntLiteral)
            {
                string temp_result = "temp" + std::to_string(tmp_cnt++);
                buffer.push_back(new Instruction(Operand(root->v, Type::IntLiteral),
                                                 Operand(),
                                                 Operand(temp_result, Type::Int),
                                                 Operator::def));
                buffer.push_back(new Instruction(Operand(temp_result, Type::Int),
                                                 Operand(mulexp_i->v, Type::Int),
                                                 Operand(temp_result, Type::Int),
                                                 op == "+" ? Operator::add : Operator::sub));
                root->v = temp_result;
                root->t = Type::Int;
            }
            else if (mulexp_i->t == Type::Int && root->t == Type::Int)
            {
                buffer.push_back(new Instruction(Operand(root->v, Type::Int),
                                                 Operand(mulexp_i->v, Type::Int),
                                                 Operand(root->v, Type::Int),
                                                 op == "+" ? Operator::add : Operator::sub));
            }
            else if (mulexp_i->t == Type::Int && root->t == Type::Float)
            {
                string temp_Float = "temp" + std::to_string(tmp_cnt++);
                buffer.push_back(new Instruction(Operand(mulexp_i->v, Type::Int),
                                                 Operand(),
                                                 Operand(temp_Float, Type::Float),
                                                 Operator::cvt_i2f));
                buffer.push_back(new Instruction(Operand(root->v, Type::Float),
                                                 Operand(temp_Float, Type::Float),
                                                 Operand(root->v, Type::Float),
                                                 op == "+" ? Operator::add : Operator::sub));
            }
        }
    }
}

// MulExp -> UnaryExp { ('*' | '/' | '%') UnaryExp }
void frontend::Analyzer::analysisMulExp(MulExp *root, vector<ir::Instruction *> &buffer)
{
    ANALYSIS(unaryexpNode_0, UnaryExp, 0);
    COPY_EXP_NODE(unaryexpNode_0, root);
    for (int i = 1; i < root->children.size(); i = i + 2)
    {
        GET_CHILD_PTR(term, Term, i);
        ANALYSIS(mulexp_i, UnaryExp, i + 1);
        string op = term->token.value;
        if (root->t != mulexp_i->t)
        {

            if (mulexp_i->t == Type::Float && root->t == Type::IntLiteral)
            {
                string temp_result = "temp" + std::to_string(tmp_cnt++);
                buffer.push_back(new Instruction(Operand(std::to_string(float(std::stoi(root->v))), Type::FloatLiteral),
                                                 Operand(),
                                                 Operand(temp_result, Type::Float),
                                                 Operator::fdef));
                buffer.push_back(new Instruction(Operand(temp_result, Type::Float),
                                                 Operand(mulexp_i->v, Type::Float),
                                                 Operand(temp_result, Type::Float),
                                                 op == "*" ? Operator::mul : Operator::div));
                root->v = temp_result;
                root->t = Type::Float;
            }
            else if (mulexp_i->t == Type::Float && root->t == Type::FloatLiteral)
            {
                string temp_result = "temp" + std::to_string(tmp_cnt++);
                buffer.push_back(new Instruction(Operand(root->v, Type::FloatLiteral),
                                                 Operand(),
                                                 Operand(temp_result, Type::Float),
                                                 Operator::fdef));
                buffer.push_back(new Instruction(Operand(root->v, Type::Float),
                                                 Operand(mulexp_i->v, Type::Float),
                                                 Operand(temp_result, Type::Float),
                                                 op == "*" ? Operator::mul : Operator::div));
                root->v = temp_result;
                root->t = Type::Float;
            }
            else if (mulexp_i->t == Type::Float && root->t == Type::Int)
            {
                buffer.push_back(new Instruction(Operand(root->v, Type::Int),
                                                 Operand(),
                                                 Operand(root->v, Type::Float),
                                                 Operator::cvt_i2f));
                buffer.push_back(new Instruction(Operand(root->v, Type::Float),
                                                 Operand(mulexp_i->v, Type::Float),
                                                 Operand(root->v, Type::Float),
                                                 op == "*" ? Operator::mul : Operator::div));
                root->t = Type::Float;
            }
            else if (mulexp_i->t == Type::Float && root->t == Type::Float)
            {
                buffer.push_back(new Instruction(Operand(root->v, Type::Float),
                                                 Operand(mulexp_i->v, Type::Float),
                                                 Operand(root->v, Type::Float),
                                                 op == "*" ? Operator::mul : Operator::div));
            }
            else if (mulexp_i->t == Type::FloatLiteral && root->t == Type::IntLiteral)
            {
                if (op == "*")
                    root->v = std::to_string(std::stoi(root->v) * std::stof(mulexp_i->v));
                else if (op == "/")
                    root->v = std::to_string(std::stoi(root->v) / std::stof(mulexp_i->v));
                root->t = Type::FloatLiteral;
            }
            else if (mulexp_i->t == Type::FloatLiteral && root->t == Type::FloatLiteral)
            {
                if (op == "*")
                    root->v = std::to_string(std::stof(root->v) * std::stof(mulexp_i->v));
                else if (op == "/")
                    root->v = std::to_string(std::stof(root->v) / std::stof(mulexp_i->v));
            }
            else if (mulexp_i->t == Type::FloatLiteral && root->t == Type::Int)
            {
                string temp_result = "temp" + std::to_string(tmp_cnt++);
                string temp_float = "temp" + std::to_string(tmp_cnt++);
                buffer.push_back(new Instruction(Operand(root->v, Type::Int),
                                                 Operand(),
                                                 Operand(temp_result, Type::Float),
                                                 Operator::cvt_i2f));
                buffer.push_back(new Instruction(Operand(mulexp_i->v, Type::FloatLiteral),
                                                 Operand(),
                                                 Operand(temp_float, Type::Float),
                                                 Operator::fdef));
                buffer.push_back(new Instruction(Operand(temp_result, Type::Float),
                                                 Operand(temp_float, Type::Float),
                                                 Operand(temp_result, Type::Float),
                                                 op == "*" ? Operator::mul : Operator::div));
                root->v = temp_result;
                root->t = Type::Float;
            }
            else if (mulexp_i->t == Type::FloatLiteral && root->t == Type::Float)
            {
                string temp_float = "temp" + std::to_string(tmp_cnt++);
                buffer.push_back(new Instruction(Operand(mulexp_i->v, Type::FloatLiteral),
                                                 Operand(),
                                                 Operand(temp_float, Type::Float),
                                                 Operator::fdef));
                buffer.push_back(new Instruction(Operand(root->v, Type::Float),
                                                 Operand(temp_float, Type::Float),
                                                 Operand(root->v, Type::Float),
                                                 op == "*" ? Operator::mul : Operator::div));
            }
            else if (mulexp_i->t == Type::IntLiteral && root->t == Type::IntLiteral)
            {
                if (op == "*")
                    root->v = std::to_string(std::stoi(root->v) * std::stoi(mulexp_i->v));
                else if (op == "/")
                    root->v = std::to_string(std::stoi(root->v) / std::stoi(mulexp_i->v));
                else if (op == "%")
                    root->v = std::to_string(std::stoi(root->v) % std::stoi(mulexp_i->v));
            }
            else if (mulexp_i->t == Type::IntLiteral && root->t == Type::FloatLiteral)
            {
                if (op == "*")
                    root->v = std::to_string(std::stoi(root->v) * std::stof(mulexp_i->v));
                else if (op == "/")
                    root->v = std::to_string(std::stoi(root->v) / std::stof(mulexp_i->v));
                root->t = Type::FloatLiteral;
            }
            else if (mulexp_i->t == Type::IntLiteral && root->t == Type::Int)
            {
                string temp_int = "temp" + std::to_string(tmp_cnt++);
                buffer.push_back(new Instruction(Operand(mulexp_i->v, Type::IntLiteral),
                                                 Operand(),
                                                 Operand(temp_int, Type::Int),
                                                 Operator::def));
                buffer.push_back(new Instruction(Operand(root->v, Type::Int),
                                                 Operand(temp_int, Type::Int),
                                                 Operand(root->v, Type::Int),
                                                 op == "*" ? Operator::mul : op == "/" ? Operator::div
                                                                                       : Operator::mod));
            }
            else if (mulexp_i->t == Type::IntLiteral && root->t == Type::Float)
            {
                string temp_int = "temp" + std::to_string(tmp_cnt++);
                buffer.push_back(new Instruction(Operand(mulexp_i->v, Type::IntLiteral),
                                                 Operand(),
                                                 Operand(temp_int, Type::Int),
                                                 Operator::def));
                buffer.push_back(new Instruction(Operand(root->v, Type::Float),
                                                 Operand(temp_int, Type::Int),
                                                 Operand(root->v, Type::Float),
                                                 op == "*" ? Operator::mul : Operator::div));
            }
            else if (mulexp_i->t == Type::Int && root->t == Type::FloatLiteral)
            {
                string temp_result = "temp" + std::to_string(tmp_cnt++);
                string temp_float = "temp" + std::to_string(tmp_cnt++);
                buffer.push_back(new Instruction(Operand(root->v, Type::FloatLiteral),
                                                 Operand(),
                                                 Operand(temp_result, Type::Float),
                                                 Operator::fdef));
                buffer.push_back(new Instruction(Operand(mulexp_i->v, Type::Int),
                                                 Operand(),
                                                 Operand(temp_float, Type::Float),
                                                 Operator::cvt_i2f));
                buffer.push_back(new Instruction(Operand(temp_result, Type::Float),
                                                 Operand(temp_float, Type::Float),
                                                 Operand(temp_result, Type::Float),
                                                 op == "*" ? Operator::mul : Operator::div));
                root->v = temp_result;
                root->t = Type::Float;
            }
            else if (mulexp_i->t == Type::Int && root->t == Type::IntLiteral)
            {
                string temp_result = "temp" + std::to_string(tmp_cnt++);
                buffer.push_back(new Instruction(Operand(root->v, Type::IntLiteral),
                                                 Operand(),
                                                 Operand(temp_result, Type::Int),
                                                 Operator::def));
                buffer.push_back(new Instruction(Operand(temp_result, Type::Int),
                                                 Operand(mulexp_i->v, Type::Int),
                                                 Operand(temp_result, Type::Int),
                                                 op == "*" ? Operator::mul : op == "/" ? Operator::div
                                                                                       : Operator::mod));
                root->v = temp_result;
                root->t = Type::Int;
            }
            else if (mulexp_i->t == Type::Int && root->t == Type::Int)
            {
                buffer.push_back(new Instruction(Operand(root->v, Type::Int),
                                                 Operand(mulexp_i->v, Type::Int),
                                                 Operand(root->v, Type::Int),
                                                 op == "*" ? Operator::mul : op == "/" ? Operator::div
                                                                                       : Operator::mod));
            }
            else if (mulexp_i->t == Type::Int && root->t == Type::Float)
            {
                string temp_Float = "temp" + std::to_string(tmp_cnt++);
                buffer.push_back(new Instruction(Operand(mulexp_i->v, Type::Int),
                                                 Operand(),
                                                 Operand(temp_Float, Type::Float),
                                                 Operator::cvt_i2f));
                buffer.push_back(new Instruction(Operand(root->v, Type::Float),
                                                 Operand(temp_Float, Type::Float),
                                                 Operand(root->v, Type::Float),
                                                 op == "*" ? Operator::mul : Operator::div));
            }
        }
    }
}

// UnaryExp -> PrimaryExp | Ident '(' [FuncRParams] ')' | UnaryOp UnaryExp
void frontend::Analyzer::analysisUnaryExp(UnaryExp *root, vector<ir::Instruction *> &buffer)
{
    if (root->children[0]->type == NodeType::PRIMARYEXP)
    {
        ANALYSIS(primaryexp, PrimaryExp, 0);
        COPY_EXP_NODE(primaryexp, root);
    }
    else if (root->children[0]->type == NodeType::UNARYOP)
    {
        ANALYSIS(unaryexp, UnaryExp, 1);
        Term *term = dynamic_cast<Term *>(root->children[0]);
        //+a
        if (term->token.type == TokenType::PLUS)
        {
            COPY_EXP_NODE(unaryexp, root);
        }
        //-a
        else if (term->token.type == TokenType::MINU)
        {
            if (unaryexp->t == Type::IntLiteral || unaryexp->t == Type::FloatLiteral)
                root->v = "-" + unaryexp->v;
            else if (unaryexp->t == Type::Int)
            {
                string temp_0 = "temp" + std::to_string(tmp_cnt++);
                buffer.push_back(new Instruction(Operand("0", Type::IntLiteral),
                                                 Operand(),
                                                 Operand(temp_0, Type::Int),
                                                 Operator::def));
                string temp_neg_result = "temp" + std::to_string(tmp_cnt++);
                buffer.push_back(new Instruction(Operand(temp_0, Type::Int),
                                                 Operand(unaryexp->v, Type::Int),
                                                 Operand(temp_neg_result, Type::Int),
                                                 Operator::sub));
                root->v = temp_neg_result;
                root->t = Type::Int;
            }
            else if (unaryexp->t == Type::Float)
            {
                string temp_0 = "temp" + std::to_string(tmp_cnt++);
                buffer.push_back(new Instruction(Operand("0.0", Type::FloatLiteral),
                                                 Operand(),
                                                 Operand(temp_0, Type::Float),
                                                 Operator::def));
                string temp_neg_result = "temp" + std::to_string(tmp_cnt++);
                buffer.push_back(new Instruction(Operand(temp_0, Type::Float),
                                                 Operand(unaryexp->v, Type::Float),
                                                 Operand(temp_neg_result, Type::Float),
                                                 Operator::fsub));
                root->v = temp_neg_result;
                root->t = Type::Float;
            }
        }
        //! a
        else if (term->token.type == TokenType::NOT)
        {
            if (unaryexp->t == Type::IntLiteral)
            {
                root->v = unaryexp->v = std::to_string(!std::stoi(unaryexp->v));
                root->t = Type::IntLiteral;
            }
            else if (unaryexp->t == Type::FloatLiteral)
            {
                root->v = unaryexp->v = std::to_string(!std::stof(unaryexp->v));
                root->t = Type::FloatLiteral;
            }
            else if (unaryexp->t == Type::Int)
            {
                string temp_not_result = "temp" + std::to_string(tmp_cnt++);
                buffer.push_back(new Instruction(Operand(unaryexp->v, Type::Int),
                                                 Operand(),
                                                 Operand(temp_not_result, Type::Int),
                                                 Operator::_not));
                root->v = temp_not_result;
                root->t = Type::Int;
            }
            else if (unaryexp->t == Type::Float)
            {
                string temp_not_result = "temp" + std::to_string(tmp_cnt++);
                buffer.push_back(new Instruction(Operand(unaryexp->v, Type::Float),
                                                 Operand(),
                                                 Operand(temp_not_result, Type::Float),
                                                 Operator::_not));
                root->v = temp_not_result;
                root->t = Type::Float;
            }
        }
    }
    else
    {
    }
}

// UnaryOp -> '+' | '-' | '!'
void frontend::Analyzer::analysisUnaryOp(UnaryOp *root, vector<ir::Instruction *> &buffer)
{
    return;
}

// PrimaryExp -> '(' Exp ')' | LVal | Number
void frontend::Analyzer::analysisPrimaryExp(PrimaryExp *root, vector<ir::Instruction *> &buffer)
{
    if (root->children[0]->type == NodeType::LVAL)
    {
        ANALYSIS(lval, LVal, 0);
        COPY_EXP_NODE(lval, root);
    }
    else if (root->children[0]->type == NodeType::NUMBER)
    {
        ANALYSIS(number, Number, 0);
        COPY_EXP_NODE(number, root);
    }
    else
    {
        ANALYSIS(exp, Exp, 1);
        COPY_EXP_NODE(exp, root);
    }
}

// LVal -> Ident {'[' Exp ']'}
void frontend::Analyzer::analysisLVal(LVal *root, vector<ir::Instruction *> &buffer)
{
    GET_CHILD_PTR(term, Term, 0);
    std::string var_name = term->token.value;
    STE oprand_ste = symbol_table.get_ste(var_name);
    string var_name_after_rename = symbol_table.get_scoped_name(var_name);
    // a
    if (root->children.size() == 1)
    {
        root->v = (oprand_ste.operand.type == Type::IntLiteral || oprand_ste.operand.type == Type::FloatLiteral) ? oprand_ste.literal_value : var_name;
        root->t = oprand_ste.operand.type;
    }
    else if (root->children.size() == 4)
    {
        ANALYSIS(exp, Exp, 2);
        string temp_var_name = "temp" + std::to_string(tmp_cnt++);
        // a[1]
        if (oprand_ste.dimension.size() == 1)
        {
            Type temp_type = oprand_ste.operand.type == Type::IntPtr ? Type::Int : Type::Float;
            buffer.push_back(new Instruction(Operand(var_name_after_rename, oprand_ste.operand.type),
                                             Operand(exp->v, exp->t),
                                             Operand(temp_var_name, temp_type),
                                             Operator::load));
            root->v = temp_var_name;
            root->t = temp_type;
        }
        // a[][3]
        else
        {
            Type temp_type = oprand_ste.operand.type;
            // a[1]
            if (exp->t == Type::IntLiteral)
            {
                string offset = std::to_string(std::stoi(exp->v) * oprand_ste.dimension[1]);
                buffer.push_back(new Instruction(Operand(var_name_after_rename, oprand_ste.operand.type),
                                                 Operand(offset, Type::IntLiteral),
                                                 Operand(temp_var_name, temp_type),
                                                 Operator::getptr));
            }
            // a[1+2]
            else
            {
                string temp_offset = "temp" + std::to_string(tmp_cnt++);
                string temp_mul_name = "temp" + std::to_string(tmp_cnt++);
                buffer.push_back(new Instruction(Operand(std::to_string(oprand_ste.dimension[1]), Type::IntLiteral),
                                                 Operand(),
                                                 Operand(temp_mul_name, Type::Int),
                                                 Operator::def));
                buffer.push_back(new Instruction(Operand(exp->v, exp->t),
                                                 Operand(temp_offset, Type::Int),
                                                 Operand(temp_var_name, Type::Int),
                                                 Operator::mul));
                buffer.push_back(new Instruction(Operand(var_name_after_rename, oprand_ste.operand.type),
                                                 Operand(temp_offset, Type::Int),
                                                 Operand(temp_var_name, temp_type),
                                                 Operator::getptr));
            }
            root->v = temp_var_name;
            root->t = temp_type;
        }
    }
    // a[1][2]
    else if (root->children.size() == 7)
    {
        ANALYSIS(exp_0, Exp, 2);
        ANALYSIS(exp_1, Exp, 5);
        string temp_dim_0 = "temp" + std::to_string(tmp_cnt++);
        string temp_dim_1 = "temp" + std::to_string(tmp_cnt++);
        buffer.push_back(new Instruction(Operand(exp_0->v, exp_0->t),
                                         Operand(),
                                         Operand(temp_dim_0, Type::Int),
                                         Operator::def));
        buffer.push_back(new Instruction(Operand(exp_1->v, exp_1->t),
                                         Operand(),
                                         Operand(temp_dim_1, Type::Int),
                                         Operator::def));
        string temp_col = "temp" + std::to_string(tmp_cnt++);
        buffer.push_back(new Instruction(Operand(std::to_string(oprand_ste.dimension[1]), Type::IntLiteral),
                                         Operand(),
                                         Operand(temp_col, Type::Int),
                                         Operator::def));
        string temp_line_offset = "temp" + std::to_string(tmp_cnt++);
        buffer.push_back(new Instruction(Operand(temp_dim_0, Type::Int),
                                         Operand(temp_col, Type::Int),
                                         Operand(temp_line_offset, Type::Int),
                                         Operator::mul));
        string temp_offset = "temp" + std::to_string(tmp_cnt++);
        buffer.push_back(new Instruction(Operand(temp_line_offset, Type::Int),
                                         Operand(temp_dim_1, Type::Int),
                                         Operand(temp_offset, Type::Int),
                                         Operator::add));
        string temp_var_name = "temp" + std::to_string(tmp_cnt++);
        Type temp_type = oprand_ste.operand.type == Type::IntPtr ? Type::Int : Type::Float;
        buffer.push_back(new Instruction(Operand(var_name_after_rename, oprand_ste.operand.type),
                                         Operand(temp_offset, Type::Int),
                                         Operand(temp_var_name, temp_type),
                                         Operator::load));
    }
}

// Number -> IntConst | floatConst
void frontend::Analyzer::analysisNumber(Number *root, vector<ir::Instruction *> &buffer)
{
    GET_CHILD_PTR(term, Term, 0);
    if (term->token.type == TokenType::INTLTR)
    {
        root->t = Type::IntLiteral;
        std::string str = dynamic_cast<Term *>(root->children[0])->token.value;
        if (str[0] == '0' && (str[1] == 'x' || str[1] == 'X'))
            root->v = std::to_string(std::stoi(str, nullptr, 16));
        else if (str[0] == '0' && (str[1] == 'b' || str[1] == 'B'))
            root->v = std::to_string(std::stoi(str, nullptr, 2));
        else if (str[0] == '0')
            root->v = std::to_string(std::stoi(str, nullptr, 8));
        else
            root->v = str;
    }
    else if (term->token.type == TokenType::FLOATLTR)
    {
        root->t = Type::FloatLiteral;
        root->v = term->token.value;
    }
    else
    {
        assert(0 && "analysisNumber error");
    }
}

// FuncDef -> FuncType Ident '(' [FuncFParams] ')' Block
void frontend::Analyzer::analysisFuncDef(FuncDef *root, ir::Program &buffer)
{
}
// FuncType -> 'void' | 'int' | 'float'
void frontend::Analyzer::analysisFuncType(FuncType *root)
{
    return;
}
// FuncFParam -> BType Ident ['[' ']' { '[' Exp ']' }]
void frontend::Analyzer::analysisFuncFParam(FuncFParam *root, vector<ir::Instruction *> &buffer)
{
}
// FuncFParams -> FuncFParam { ',' FuncFParam }
void frontend::Analyzer::analysisFuncFParams(FuncFParams *root, vector<ir::Instruction *> &buffer)
{
}
// Block -> '{' { BlockItem } '}'
void frontend::Analyzer::analysisBlock(Block *root, vector<ir::Instruction *> &buffer)
{
}
// BlockItem -> Decl | Stmt
void frontend::Analyzer::analysisBlockItem(BlockItem *root, vector<ir::Instruction *> &buffer)
{
}
// Stmt -> LVal '=' Exp ';' | Block | 'if' '(' Cond ')' Stmt [ 'else' Stmt ] | 'while' '(' Cond ')' Stmt | 'break' ';' | 'continue' ';' | 'return' [Exp] ';' | [Exp] ';'
void frontend::Analyzer::analysisStmt(Stmt *root, vector<ir::Instruction *> &buffer)
{
}

// Cond -> LOrExp
void frontend::Analyzer::analysisCond(Cond *root, vector<ir::Instruction *> &buffer)
{
}

// PrimaryExp -> '(' Exp ')' | LVal | Number
void frontend::Analyzer::analysisPrimaryExp(PrimaryExp *root, vector<ir::Instruction *> &buffer)
{
}

// FuncRParams -> Exp { ',' Exp }
void frontend::Analyzer::analysisFuncRParams(FuncRParams *root, vector<ir::Instruction *> &buffer)
{
}

// RelExp -> AddExp { ('<' | '>' | '<=' | '>=') AddExp }
void frontend::Analyzer::analysisRelExp(RelExp *root, vector<ir::Instruction *> &buffer)
{
}
// EqExp -> RelExp { ('==' | '!=') RelExp }
void frontend::Analyzer::analysisEqExp(EqExp *root, vector<ir::Instruction *> &buffer)
{
}
// LAndExp -> EqExp { '&&' EqExp }
void frontend::Analyzer::analysisLAndExp(LAndExp *root, vector<ir::Instruction *> &buffer)
{
}
// LOrExp -> LAndExp [ '||' LOrExp ]
void frontend::Analyzer::analysisLOrExp(LOrExp *root, vector<ir::Instruction *> &buffer)
{
}
