#include"backend/generator.h"

#include <assert.h>
#include <unordered_map>
#include <unordered_set>
#include <iostream>
#include <algorithm>


#define TODO assert(0 && "todo")

std::string toString(rv::rvREG r)
{
    switch (r)
    {
    case rv::rvREG::ZERO:
        return "zero";
    case rv::rvREG::RA:
        return "ra";
    case rv::rvREG::SP:
        return "sp";
    case rv::rvREG::GP:
        return "gp";
    case rv::rvREG::TP:
        return "tp";
    case rv::rvREG::T0:
        return "t0";
    case rv::rvREG::T1:
        return "t1";
    case rv::rvREG::T2:
        return "t2";
    case rv::rvREG::S0:
        return "s0"; // ? 在汇编中s0与fp有何区别
    case rv::rvREG::S1:
        return "s1";
    case rv::rvREG::A0:
        return "a0";
    case rv::rvREG::A1:
        return "a1";
    case rv::rvREG::A2:
        return "a2";
    case rv::rvREG::A3:
        return "a3";
    case rv::rvREG::A4:
        return "a4";
    case rv::rvREG::A5:
        return "a5";
    case rv::rvREG::A6:
        return "a6";
    case rv::rvREG::A7:
        return "a7";
    case rv::rvREG::S2:
        return "s2";
    case rv::rvREG::S3:
        return "s3";
    case rv::rvREG::S4:
        return "s4";
    case rv::rvREG::S5:
        return "s5";
    case rv::rvREG::S6:
        return "s6";
    case rv::rvREG::S7:
        return "s7";
    case rv::rvREG::S8:
        return "s8";
    case rv::rvREG::S9:
        return "s9";
    case rv::rvREG::S10:
        return "s10";
    case rv::rvREG::S11:
        return "s11";
    case rv::rvREG::T3:
        return "t3";
    case rv::rvREG::T4:
        return "t4";
    case rv::rvREG::T5:
        return "t5";
    case rv::rvREG::T6:
        return "t6";
    case rv::rvREG::FT0:
        return "ft0";
    case rv::rvREG::FT1:
        return "ft1";
    case rv::rvREG::FT2:
        return "ft2";
    case rv::rvREG::FT3:
        return "ft3";
    case rv::rvREG::FT4:
        return "ft4";
    case rv::rvREG::FT5:
        return "ft5";
    case rv::rvREG::FT6:
        return "ft6";
    case rv::rvREG::FT7:
        return "ft7";
    case rv::rvREG::FS0:
        return "fs0";
    case rv::rvREG::FS1:
        return "fs1";
    case rv::rvREG::FA0:
        return "fa0";
    case rv::rvREG::FA1:
        return "fa1";
    case rv::rvREG::FA2:
        return "fa2";
    case rv::rvREG::FA3:
        return "fa3";
    case rv::rvREG::FA4:
        return "fa4";
    case rv::rvREG::FA5:
        return "fa5";
    case rv::rvREG::FA6:
        return "fa6";
    case rv::rvREG::FA7:
        return "fa7";
    case rv::rvREG::FS2:
        return "fs2";
    case rv::rvREG::FS3:
        return "fs3";
    case rv::rvREG::FS4:
        return "fs4";
    case rv::rvREG::FS5:
        return "fs5";
    case rv::rvREG::FS6:
        return "fs6";
    case rv::rvREG::FS7:
        return "fs7";
    case rv::rvREG::FS8:
        return "fs8";
    case rv::rvREG::FS9:
        return "fs9";
    case rv::rvREG::FS10:
        return "fs10";
    case rv::rvREG::FS11:
        return "fs11";
    case rv::rvREG::FT8:
        return "ft8";
    case rv::rvREG::FT9:
        return "ft9";
    case rv::rvREG::FT10:
        return "ft10";
    case rv::rvREG::FT11:
        return "ft11";
    default:
        assert(0 && "Error rvREG Type");
    }
}

bool backend::Generator::is_global(const std::string& operand_name)
{
    return global_vars.count(operand_name);
}

void backend::Generator::init_func(const ir::Function* func)
{
    curr_func = func;

    // 清空所有记录
    stack_offset_table.clear();
    curr_ir_addr = -1;
    jump_label_map.clear();
    curr_stack_used_bytes = 0;

    // 重置寄存器分配记录
    free_int_regs.clear();
    free_int_regs.insert(int_regs.begin(),int_regs.end());
    
    // 首先统计该函数中涉及的变量个数
    std::unordered_set<std::string> operand_set_in_func;
    // 首先扫描函数的参数
    for (ir::Operand para:func->ParameterList)
    {
        operand_set_in_func.insert(para.name);
        // para.type: [Int, IntPtr]
    }
    // 扫描所有指令中的操作数
    for (int i = 0; i < func->InstVec.size(); i++)
    {
        // 分别扫描des, op1, op2
        auto instr = func->InstVec[i];
        // des
        if (instr->des.type != ir::Type::null && instr->des.type != ir::Type::IntLiteral)
        {
            // 全局变量不会被计入
            if (!is_global(instr->des.name))
                operand_set_in_func.insert(instr->des.name);
        }
        // op1
        if (instr->op1.type != ir::Type::null && instr->op1.type != ir::Type::IntLiteral)
        {
            // 全局变量不会被计入
            if (!is_global(instr->op1.name))
                operand_set_in_func.insert(instr->op1.name);
        }
        // op2
        if (instr->op2.type != ir::Type::null && instr->op2.type != ir::Type::IntLiteral)
        {
            // 全局变量不会被计入
            if (!is_global(instr->op2.name))
                operand_set_in_func.insert(instr->op2.name);
        }
    }

    // 确定STACK_SIZE
    stack_size = (operand_set_in_func.size() + 13) * 4; // Callee保存寄存器个数:25-1+1=24 (排除了SP的保存, 因为通过+ -, 进入时-, 退出时+来实现保存不变的, 增加了RA的保存, 为了实现简单)
    std::cout << "Estimated Stack Size For " << func->name << " :" << stack_size << "\n";

    // 向文件输出, 分配STACK
    fout << "\taddi\tsp,sp,-" << this->stack_size << "\n"; // 动态估测栈需要的空间

    // 开始初始化stack_offset_table
    int curr_offset = 0;
    // 从12个Callee寄存器(s0-s11) + RA寄存器 开始
    for (rv::rvREG reg:saved_callee_regs)
    {
        stack_offset_table[saved_callee_stack_prefix+toString(reg)] = curr_offset;
        // 保存寄存器内容到栈中
        fout << "\tsw\t" << toString(reg) << "," << stack_offset_table[saved_callee_stack_prefix+toString(reg)] << "(sp)\n";
        curr_offset += 4;
    }
    // 分配、保存函数参数
    for (int i = 0; i < curr_func->ParameterList.size(); i++)
    {
        // 不支持浮点数函数参数
        assert(curr_func->ParameterList[i].type == ir::Type::Int || curr_func->ParameterList[i].type == ir::Type::IntPtr);

        stack_offset_table[curr_func->ParameterList[i].name] = curr_offset;
        curr_offset += 4;
        std::vector<rv::rvREG> int_arg_regs {rv::rvREG::A0, rv::rvREG::A1, rv::rvREG::A2, rv::rvREG::A3, rv::rvREG::A4, rv::rvREG::A5, rv::rvREG::A6, rv::rvREG::A7};
        // 还需要完成从寄存器/帧中加载到栈
        if (i <= 7)
        {
            // 从寄存器中加载到栈
            fout << "\tsw\t" << toString(int_arg_regs[i]) << ", " << stack_offset_table[curr_func->ParameterList[i].name] << "(sp)\n";
        }
        else
        {
            // 从帧中加载到栈
            fout << "\tlw\tt0, " << stack_size+(i-8)*4 << "(sp)\n";
            fout << "\tsw\tt0, " << stack_offset_table[curr_func->ParameterList[i].name] << "(sp)\n";
        }
    }
    // 分配函数体中的变量
    for (int i = 0; i < func->InstVec.size(); i++)
    {
        // 分别扫描des, op1, op2
        auto instr = func->InstVec[i];
        // des
        if (instr->des.type != ir::Type::null && instr->des.type != ir::Type::IntLiteral)
        {
            // 全局变量不会被计入
            if (!is_global(instr->des.name) && stack_offset_table.find(instr->des.name) == stack_offset_table.end())
            {
                stack_offset_table[instr->des.name] = curr_offset;
                curr_offset += 4;
            }
        }
        // op1
        if (instr->op1.type != ir::Type::null && instr->op1.type != ir::Type::IntLiteral)
        {
            // 全局变量不会被计入
            if (!is_global(instr->op1.name) && stack_offset_table.find(instr->op1.name) == stack_offset_table.end())
            {
                stack_offset_table[instr->op1.name] = curr_offset;
                curr_offset += 4;
            }
        }
        // op2
        if (instr->op2.type != ir::Type::null && instr->op2.type != ir::Type::IntLiteral)
        {
            // 全局变量不会被计入
            if (!is_global(instr->op2.name) && stack_offset_table.find(instr->op2.name) == stack_offset_table.end())
            {
                stack_offset_table[instr->op2.name] = curr_offset;
                curr_offset += 4;
            }
        }
    }

    // 扫描一次所有GOTO指令, 提前分配好LABEL名与IR指令地址映射
    for (int i = 0; i < func->InstVec.size(); i++)
    {
        auto instr = func->InstVec[i];
        if (instr->op == ir::Operator::_goto)
        {
            int jump_label_offset = std::stoi(instr->des.name);
            if (!jump_label_map.count(i + jump_label_offset))
                jump_label_map[i + jump_label_offset] = "_ir_goto_label" + std::to_string(label_count++);
        }
    }
}

void backend::Generator::set_nopic()
{
    fout << "\t.option nopic\n";
}

void backend::Generator::set_data()
{
    fout << "\t.data\n";
}

void backend::Generator::set_bss()
{
    fout << "\t.bss\n";
}

void backend::Generator::set_label(const std::string& lable)
{
    fout << lable << ":\n";
}

void backend::Generator::set_text()
{
    fout << "\t.text\n";
}

backend::Generator::Generator(ir::Program& p, std::ofstream& f): program(p), fout(f) {}

int backend::Generator::get_offset(const std::string& operand_name)
{
    return stack_offset_table[operand_name];
}

rv::rvREG backend::Generator::alloc_int_reg()
{
    rv::rvREG result = *free_int_regs.begin();
    free_int_regs.erase(result);
    return result;
}

rv::rvREG backend::Generator::alloc_and_load_int_reg(ir::Operand operand)
{
    rv::rvREG result = alloc_int_reg();
    assert((operand.type == ir::Type::Int) || (operand.type == ir::Type::IntPtr));
    // 判断是全局变量还是局部变量
    if (!is_global(operand.name))
    {
        // 从栈中加载
        fout << "\tlw\t" << toString(result) << ", " << get_offset(operand.name) << "(sp)\n";
    }
    else
    {
        // 从全局变量表中加载
        if (operand.type == ir::Type::Int)
        {
            rv::rvREG tmp_addr_reg = alloc_int_reg();
            fout << "\tla\t" << toString(tmp_addr_reg) << ", " << operand.name << "\n";
            fout << "\tlw\t" << toString(result) << ", 0(" << toString(tmp_addr_reg) << ")\n";
            free_int_reg(tmp_addr_reg);
        }
        else
            fout << "\tla\t" << toString(result) << ", " << operand.name << "\n";
    }
    return result;
}

void backend::Generator::free_int_reg(rv::rvREG int_reg)
{
    free_int_regs.insert(int_reg);
}

void backend::Generator::save_int_operand(ir::Operand operand, rv::rvREG int_reg)
{
    // 将当前寄存器中的值存入内存
    assert(operand.type == ir::Type::Int || operand.type == ir::Type::IntPtr);
    // 判断是全局变量还是局部变量
    if (!is_global(operand.name))
    {
        // 存入栈中
        fout << "\tsw\t" << toString(int_reg) << ", " << get_offset(operand.name) << "(sp)\n";
    }
    else
    {
        // 存入全局变量表中
        rv::rvREG tmp_addr_reg = alloc_int_reg();
        fout << "\tla\t" << toString(tmp_addr_reg) << ", " << operand.name << "\n";
        fout << "\tsw\t" << toString(int_reg) << ", 0(" << toString(tmp_addr_reg) << ")\n";
        free_int_reg(tmp_addr_reg);
    }
}

void backend::Generator::gen() {
    // 输出基本头部
    set_nopic();

    // 从ir::Program.globalVars中读出全局变量, 存入寄存器分配器中的全局变量表
    for (auto globalval:program.globalVal)
    {
        std::cout << globalval.val.name << std::endl;
        this->global_vars.insert(globalval.val.name);
    }

    // 首先处理全局变量
    gen_global_data();

    // 进入代码段
    set_text();

    // 按顺序处理每个函数
    for (int i = 0; i < int(program.functions.size())-1; i++)
        gen_func(program.functions[i]);
}

void backend::Generator::gen_global_data()
{
    // 对于整数/浮点变量, 不处理const变量, 只处理全局变量

    // 第一次扫描, 只处理单个的整数与浮点变量声明 (使用gcc生成汇编测试, 全局变量的初始化必须为常数, 否则会报错)
    set_data();
    const ir::Function& global_func = program.functions.back(); // 在语义分析中, 最后才加入的全局函数
    for (const ir::Instruction* instr : global_func.InstVec)
    {
        if (instr->op == ir::Operator::def || instr->op == ir::Operator::fdef)
        {
            fout << "\t.globl\t" << instr->des.name << "\n";
            fout << "\t.type\t" << instr->des.name << ", @object\n";
            fout << "\t.size\t" << instr->des.name << ", 4\n";
            fout << "\t.align\t" << "4\n";
            set_label(instr->des.name);

            // 不允许全局变量声明中出现变量
            assert(instr->op1.type != ir::Type::Int && instr->op1.type != ir::Type::Float);
            // 整数, 也只能是整数(不实现浮点数)
            if (instr->des.type == ir::Type::Int)
            {
                assert(instr->op1.type == ir::Type::IntLiteral);
                fout << "\t.word\t" << instr->op1.name << "\n";
            }
        }
    }
    
    // 第二次扫描, 处理有初始值的数组
    std::unordered_map<std::string,ir::GlobalVal> global_array_vals;
    for (const ir::GlobalVal& array_globalval : program.globalVal)
    {
        if (array_globalval.val.type == ir::Type::IntPtr) // 全局整数数组 (不实现浮点数)
            global_array_vals.emplace(array_globalval.val.name, array_globalval);
    }
    for (const ir::Instruction* instr : global_func.InstVec)
    {
        if (instr->op == ir::Operator::store)
        {
            if (global_array_vals.count(instr->op1.name)) // 初次扫描到
            {
                auto& array_globalval = global_array_vals.find(instr->op1.name)->second;
                int arr_len = array_globalval.maxlen;
                fout << "\t.globl\t" << instr->op1.name << "\n";
                fout << "\t.type\t" << instr->op1.name << ", @object\n";
                fout << "\t.size\t" << instr->op1.name << ", " << arr_len * 4 << "\n";
                fout << "\t.align\t" << "4\n";
                set_label(instr->op1.name);
                // 从global_array_vals中移除
                global_array_vals.erase(instr->op1.name);
            }
            // 不允许全局变量声明中出现变量
            assert(instr->des.type != ir::Type::Int && instr->des.type != ir::Type::Float);
            // 整数, 也只能是整数 (不实现浮点数)
            if (instr->des.type == ir::Type::IntLiteral)
            {
                fout << "\t.word\t" << instr->des.name << "\n";
            }
        }
    }

    // 第三次扫描, 将所有没有进行初始化的数组放入bss中
    if (global_array_vals.size() > 0)
    {
        set_bss();
        for (const auto& array_globalval : global_array_vals)
        {
            fout << "\t.globl\t" << array_globalval.first << "\n";
            fout << "\t.type\t" << array_globalval.first << ", @object\n";
            fout << "\t.size\t" << array_globalval.first << ", " << array_globalval.second.maxlen * 4 << "\n";
            fout << "\t.align\t" << "4\n";
            set_label(array_globalval.first);
            fout << "\t.space\t" << array_globalval.second.maxlen * 4 << "\n";
        }
    }
}

void backend::Generator::gen_func(const ir::Function& func)
{
    curr_function = &func; // 当前函数的指针

    fout << "\t.globl\t" << func.name << "\n";
    fout << "\t.type\t" << func.name << ", @function\n";
    set_label(func.name);

    // 寄存器分配器初始化 && 函数变量初始化
    this->init_func(&func);

    // 根据函数中的每条指令, 生成汇编
    for (const ir::Instruction* instr : func.InstVec)
    {
        curr_ir_addr++;
        if (jump_label_map.count(curr_ir_addr))
        {
            // 增加标签
            set_label(jump_label_map[curr_ir_addr]);
        }
        gen_instr(*instr);
    }

    fout << "\t.size\t" << func.name << ", .-" << func.name << "\n";
}

void backend::Generator::gen_instr(const ir::Instruction& instr)
{
    ir::Operator instr_op = instr.op;
    switch (instr_op)
    {
    case ir::Operator::_return:
        gen_instr_return(instr);
        break;
    case ir::Operator::def:
    case ir::Operator::mov:
        gen_instr_mov(instr);
        break;
    case ir::Operator::add:
        gen_instr_add(instr);
        break;
    case ir::Operator::sub:
        gen_instr_sub(instr);
        break;
    case ir::Operator::mul:
        gen_instr_mul(instr);
        break;
    case ir::Operator::div:
        gen_instr_div(instr);
        break;
    case ir::Operator::mod:
        gen_instr_mod(instr);
        break;
    case ir::Operator::lss:
        gen_instr_lss(instr);
        break;
    case ir::Operator::gtr:
        gen_instr_gtr(instr);
        break;
    case ir::Operator::leq:
        gen_instr_leq(instr);
        break;
    case ir::Operator::geq:
        gen_instr_geq(instr);
        break;
    case ir::Operator::eq:
        gen_instr_eq(instr);
        break;
    case ir::Operator::neq:
        gen_instr_neq(instr);
        break;
    case ir::Operator::_not:
        gen_instr_not(instr);
        break;
    case ir::Operator::_and:
        gen_instr_and(instr);
        break;
    case ir::Operator::_or:
        gen_instr_or(instr);
        break;
    case ir::Operator::alloc:
        gen_instr_alloc(instr);
        break;
    case ir::Operator::load:
        gen_instr_load(instr);
        break;
    case ir::Operator::store:
        gen_instr_store(instr);
        break;
    case ir::Operator::getptr:
        gen_instr_getptr(instr);
        break;
    case ir::Operator::call:
        gen_instr_call(instr);
        break;
    case ir::Operator::_goto:
        gen_instr_goto(instr);
        break;
    case ir::Operator::__unuse__:
        gen_instr_unuse(instr);
        break;
    default:
        std::cout << "Not Implemented:" << ir::toString(instr_op) << std::endl;
        break;
    }
}

void backend::Generator::gen_instr_return(const ir::Instruction& instr)
{
    // 不需要进行寄存器管理, 本函数的最后一条语句 (需要将栈中暂存的数据存回寄存器？应该不用)

    // 根据函数返回值类型，将结果保存在a0或fa0中
    if (instr.op1.type == ir::Type::IntLiteral)
    {
        fout << "\tli\ta0," << std::stoi(instr.op1.name) << "\n";
    }
    else if (instr.op1.type == ir::Type::Int)
    {
        rv::rvREG tmp_reg = alloc_and_load_int_reg(instr.op1);
        fout << "\tmv\ta0," << toString(tmp_reg) << "\n";
        free_int_reg(tmp_reg);
    }
    else if (instr.op1.type == ir::Type::Float)
    {
        assert(0 && "不支持浮点");
    }

    // 恢复所有保存寄存器
    for (auto reg : this->saved_callee_regs)
    {
        fout << "\tlw\t" << toString(reg) << "," << stack_offset_table[saved_callee_stack_prefix+toString(reg)] << "(sp)\n";
    }

    // 恢复sp寄存器
    fout << "\taddi\tsp,sp," << this->stack_size << "\n";
    // 返回
    fout << "\tret\n";
}

void backend::Generator::gen_instr_mov(const ir::Instruction& instr)
{
    rv::rvREG tmp_result_reg = alloc_int_reg();
    // 赋值有2种情况, 1: 操作数1为立即数, 2: 操作数1为变量
    // 1: 操作数1为立即数
    if (instr.op1.type == ir::Type::IntLiteral)
    {
        fout << "\tli\t" << toString(tmp_result_reg) << "," << std::stoi(instr.op1.name) << "\n";
    }
    // 2: 操作数1为变量
    else
    {
        rv::rvREG tmp_op1_reg = alloc_and_load_int_reg(instr.op1);
        fout << "\tmv\t" << toString(tmp_result_reg) << "," << toString(tmp_op1_reg) << "\n";
        free_int_reg(tmp_op1_reg);
    }
    save_int_operand(instr.des, tmp_result_reg);
    free_int_reg(tmp_result_reg);
}

void backend::Generator::gen_instr_add(const ir::Instruction& instr)
{
    //op1 + op2 -> des 其中op1、op2均为变量, 因为我在实验2中保证计算均为变量
    rv::rvREG tmp_op1_reg = alloc_and_load_int_reg(instr.op1);
    rv::rvREG tmp_op2_reg = alloc_and_load_int_reg(instr.op2);
    rv::rvREG result = alloc_int_reg();
    fout << "\tadd\t" << toString(result) << "," << toString(tmp_op1_reg) << "," << toString(tmp_op2_reg) << "\n";
    save_int_operand(instr.des, result);
    free_int_reg(tmp_op1_reg);
    free_int_reg(tmp_op2_reg);
    free_int_reg(result);
}

void backend::Generator::gen_instr_sub(const ir::Instruction& instr)
{
    //op1 - op2 -> des 其中op1、op2均为变量, 因为我在实验2中保证计算均为变量
    rv::rvREG tmp_op1_reg = alloc_and_load_int_reg(instr.op1);
    rv::rvREG tmp_op2_reg = alloc_and_load_int_reg(instr.op2);
    rv::rvREG result = alloc_int_reg();
    fout << "\tsub\t" << toString(result) << "," << toString(tmp_op1_reg) << "," << toString(tmp_op2_reg) << "\n";
    save_int_operand(instr.des, result);
    free_int_reg(tmp_op1_reg);
    free_int_reg(tmp_op2_reg);
    free_int_reg(result);
}

void backend::Generator::gen_instr_mul(const ir::Instruction& instr)
{
    //op1 * op2 -> des 其中op1、op2均为变量, 因为我在实验2中保证计算均为变量
    rv::rvREG tmp_op1_reg = alloc_and_load_int_reg(instr.op1);
    rv::rvREG tmp_op2_reg = alloc_and_load_int_reg(instr.op2);
    rv::rvREG result = alloc_int_reg();
    fout << "\tmul\t" << toString(result) << "," << toString(tmp_op1_reg) << "," << toString(tmp_op2_reg) << "\n";
    save_int_operand(instr.des, result);
    free_int_reg(tmp_op1_reg);
    free_int_reg(tmp_op2_reg);
    free_int_reg(result);
}

void backend::Generator::gen_instr_div(const ir::Instruction& instr)
{
    //op1 / op2 -> des 其中op1、op2均为变量, 因为我在实验2中保证计算均为变量
    rv::rvREG tmp_op1_reg = alloc_and_load_int_reg(instr.op1);
    rv::rvREG tmp_op2_reg = alloc_and_load_int_reg(instr.op2);
    rv::rvREG result = alloc_int_reg();
    fout << "\tdiv\t" << toString(result) << "," << toString(tmp_op1_reg) << "," << toString(tmp_op2_reg) << "\n";
    save_int_operand(instr.des, result);
    free_int_reg(tmp_op1_reg);
    free_int_reg(tmp_op2_reg);
    free_int_reg(result);
}

void backend::Generator::gen_instr_mod(const ir::Instruction& instr)
{
    //op1 % op2 -> des 其中op1、op2均为变量, 因为我在实验2中保证计算均为变量
    rv::rvREG tmp_op1_reg = alloc_and_load_int_reg(instr.op1);
    rv::rvREG tmp_op2_reg = alloc_and_load_int_reg(instr.op2);
    rv::rvREG result = alloc_int_reg();
    fout << "\trem\t" << toString(result) << "," << toString(tmp_op1_reg) << "," << toString(tmp_op2_reg) << "\n";
    save_int_operand(instr.des, result);
    free_int_reg(tmp_op1_reg);
    free_int_reg(tmp_op2_reg);
    free_int_reg(result);
}

void backend::Generator::gen_instr_lss(const ir::Instruction& instr)
{
    //op1 < op2 -> des 其中op1、op2均为变量, 因为我在实验2中保证计算均为变量
    rv::rvREG tmp_op1_reg = alloc_and_load_int_reg(instr.op1);
    rv::rvREG tmp_op2_reg = alloc_and_load_int_reg(instr.op2);
    rv::rvREG result = alloc_int_reg();
    fout << "\tslt\t" << toString(result) << "," << toString(tmp_op1_reg) << "," << toString(tmp_op2_reg) << "\n";
    save_int_operand(instr.des, result);
    free_int_reg(tmp_op1_reg);
    free_int_reg(tmp_op2_reg);
    free_int_reg(result);
}

void backend::Generator::gen_instr_leq(const ir::Instruction& instr)
{
    //op1 <= op2 -> des 其中op1、op2均为变量, 因为我在实验2中保证计算均为变量
    rv::rvREG tmp_op1_reg = alloc_and_load_int_reg(instr.op1);
    rv::rvREG tmp_op2_reg = alloc_and_load_int_reg(instr.op2);
    rv::rvREG result = alloc_int_reg();
    fout << "\tslt\t" << toString(result) << "," << toString(tmp_op2_reg) << "," << toString(tmp_op1_reg) << "\n";
    fout << "\txori\t" << toString(result) << "," << toString(result) << ",1\n";
    save_int_operand(instr.des, result);
    free_int_reg(tmp_op1_reg);
    free_int_reg(tmp_op2_reg);
    free_int_reg(result);
}

void backend::Generator::gen_instr_gtr(const ir::Instruction& instr)
{
    //op1 > op2 -> des 其中op1、op2均为变量, 因为我在实验2中保证计算均为变量
    rv::rvREG tmp_op1_reg = alloc_and_load_int_reg(instr.op1);
    rv::rvREG tmp_op2_reg = alloc_and_load_int_reg(instr.op2);
    rv::rvREG result = alloc_int_reg();
    fout << "\tslt\t" << toString(result) << "," << toString(tmp_op2_reg) << "," << toString(tmp_op1_reg) << "\n";
    save_int_operand(instr.des, result);
    free_int_reg(tmp_op1_reg);
    free_int_reg(tmp_op2_reg);
    free_int_reg(result);
}

void backend::Generator::gen_instr_geq(const ir::Instruction& instr)
{
    //op1 >= op2 -> des 其中op1、op2均为变量, 因为我在实验2中保证计算均为变量
    rv::rvREG tmp_op1_reg = alloc_and_load_int_reg(instr.op1);
    rv::rvREG tmp_op2_reg = alloc_and_load_int_reg(instr.op2);
    rv::rvREG result = alloc_int_reg();
    fout << "\tslt\t" << toString(result) << "," << toString(tmp_op1_reg) << "," << toString(tmp_op2_reg) << "\n";
    fout << "\txori\t" << toString(result) << "," << toString(result) << ",1\n";
    save_int_operand(instr.des, result);
    free_int_reg(tmp_op1_reg);
    free_int_reg(tmp_op2_reg);
    free_int_reg(result);
}

void backend::Generator::gen_instr_eq(const ir::Instruction& instr)
{
    //op1 == op2 -> des 其中op1、op2均为变量, 因为我在实验2中保证计算均为变量
    rv::rvREG tmp_op1_reg = alloc_and_load_int_reg(instr.op1);
    rv::rvREG tmp_op2_reg = alloc_and_load_int_reg(instr.op2);
    rv::rvREG result = alloc_int_reg();
    fout << "\txor\t" << toString(result) << "," << toString(tmp_op1_reg) << "," << toString(tmp_op2_reg) << "\n";
    fout << "\tsltiu\t" << toString(result) << "," << toString(result) << ",1\n";
    save_int_operand(instr.des, result);
    free_int_reg(tmp_op1_reg);
    free_int_reg(tmp_op2_reg);
    free_int_reg(result);  
}

void backend::Generator::gen_instr_neq(const ir::Instruction& instr)
{
    //op1 != op2 -> des 其中op1、op2均为变量, 因为我在实验2中保证计算均为变量
    rv::rvREG tmp_op1_reg = alloc_and_load_int_reg(instr.op1);
    rv::rvREG tmp_op2_reg = alloc_and_load_int_reg(instr.op2);
    rv::rvREG result = alloc_int_reg();
    fout << "\txor\t" << toString(result) << "," << toString(tmp_op1_reg) << "," << toString(tmp_op2_reg) << "\n";
    fout << "\tsltiu\t" << toString(result) << "," << toString(result) << ",1\n";
    fout << "\txori\t" << toString(result) << "," << toString(result) << ",1\n";
    save_int_operand(instr.des, result);
    free_int_reg(tmp_op1_reg);
    free_int_reg(tmp_op2_reg);
    free_int_reg(result);  
}

void backend::Generator::gen_instr_not(const ir::Instruction& instr)
{
    //!op1 -> des其中op1为变量
    rv::rvREG tmp_op1_reg = alloc_and_load_int_reg(instr.op1);
    rv::rvREG result = alloc_int_reg();
    fout << "\tsltiu\t" << toString(result) << "," << toString(tmp_op1_reg) << ",1\n";
    save_int_operand(instr.des, result);
    free_int_reg(tmp_op1_reg);
    free_int_reg(result);
}

void backend::Generator::gen_instr_and(const ir::Instruction& instr)
{
    //op1 && op2 -> des 其中op1、op2可能为变量,也可能为常量
    if (instr.op1.type == ir::Type::IntLiteral) // op1为常量
    {
        rv::rvREG tmp_op1_reg = alloc_int_reg();
        rv::rvREG tmp_op2_reg = alloc_and_load_int_reg(instr.op2);
        rv::rvREG result = alloc_int_reg();
        fout << "\tli\t" << toString(tmp_op1_reg) << "," << instr.op1.name << "\n";
        fout << "\tsltiu\t" << toString(result) << "," << toString(tmp_op1_reg) << ",1\n"; // 0 - 1  非0 - 0
        fout << "\txori\t" << toString(result) << "," << toString(result) << ",1\n"; // 0 - 0  非0 - 1
        fout << "\tsltiu\t" << toString(tmp_op2_reg) << "," << toString(tmp_op2_reg) << ",1\n"; // 0 - 1  非0 - 0
        fout << "\txori\t" << toString(tmp_op2_reg) << "," << toString(tmp_op2_reg) << ",1\n"; // 0 - 0  非0 - 1
        fout << "\tand\t" << toString(result) << "," << toString(result) << "," << toString(tmp_op2_reg) << "\n";
        save_int_operand(instr.des, result);
        free_int_reg(tmp_op1_reg);
        free_int_reg(tmp_op2_reg);
        free_int_reg(result);
    }
    else if (instr.op2.type == ir::Type::IntLiteral) // op2为常量
    {
        rv::rvREG tmp_op1_reg = alloc_and_load_int_reg(instr.op1);
        rv::rvREG tmp_op2_reg = alloc_int_reg();
        rv::rvREG result = alloc_int_reg();
        fout << "\tli\t" << toString(tmp_op2_reg) << "," << instr.op2.name << "\n";
        fout << "\tsltiu\t" << toString(result) << "," << toString(tmp_op1_reg) << ",1\n"; // 0 - 1  非0 - 0
        fout << "\txori\t" << toString(result) << "," << toString(result) << ",1\n"; // 0 - 0  非0 - 1
        fout << "\tsltiu\t" << toString(tmp_op2_reg) << "," << toString(tmp_op2_reg) << ",1\n"; // 0 - 1  非0 - 0
        fout << "\txori\t" << toString(tmp_op2_reg) << "," << toString(tmp_op2_reg) << ",1\n"; // 0 - 0  非0 - 1
        fout << "\tand\t" << toString(result) << "," << toString(result) << "," << toString(tmp_op2_reg) << "\n";
        save_int_operand(instr.des, result);
        free_int_reg(tmp_op1_reg);
        free_int_reg(tmp_op2_reg);
        free_int_reg(result);
    }
    else // 全变量
    {
        rv::rvREG tmp_op1_reg = alloc_and_load_int_reg(instr.op1);
        rv::rvREG tmp_op2_reg = alloc_and_load_int_reg(instr.op2);
        rv::rvREG result = alloc_int_reg();
        fout << "\tsltiu\t" << toString(result) << "," << toString(tmp_op1_reg) << ",1\n"; // 0 - 1  非0 - 0
        fout << "\txori\t" << toString(result) << "," << toString(result) << ",1\n"; // 0 - 0  非0 - 1
        fout << "\tsltiu\t" << toString(tmp_op2_reg) << "," << toString(tmp_op2_reg) << ",1\n"; // 0 - 1  非0 - 0
        fout << "\txori\t" << toString(tmp_op2_reg) << "," << toString(tmp_op2_reg) << ",1\n"; // 0 - 0  非0 - 1
        fout << "\tand\t" << toString(result) << "," << toString(result) << "," << toString(tmp_op2_reg) << "\n";
        save_int_operand(instr.des, result);
        free_int_reg(tmp_op1_reg);
        free_int_reg(tmp_op2_reg);
        free_int_reg(result);
    }
}

void backend::Generator::gen_instr_or(const ir::Instruction& instr)
{
    //op1 || op2 -> des 其中op1、op2可能为常量
    if (instr.op1.type == ir::Type::IntLiteral) // op1为常量
    {
        rv::rvREG tmp_op1_reg = alloc_int_reg();
        rv::rvREG tmp_op2_reg = alloc_and_load_int_reg(instr.op2);
        rv::rvREG result = alloc_int_reg();
        fout << "\tli\t" << toString(tmp_op1_reg) << "," << instr.op1.name << "\n";
        fout << "\tsltiu\t" << toString(result) << "," << toString(tmp_op1_reg) << ",1\n"; // 0 - 1  非0 - 0
        fout << "\txori\t" << toString(result) << "," << toString(result) << ",1\n"; // 0 - 0  非0 - 1
        fout << "\tsltiu\t" << toString(tmp_op2_reg) << "," << toString(tmp_op2_reg) << ",1\n"; // 0 - 1  非0 - 0
        fout << "\txori\t" << toString(tmp_op2_reg) << "," << toString(tmp_op2_reg) << ",1\n"; // 0 - 0  非0 - 1
        fout << "\tor\t" << toString(result) << "," << toString(result) << "," << toString(tmp_op2_reg) << "\n";
        save_int_operand(instr.des, result);
        free_int_reg(tmp_op1_reg);
        free_int_reg(tmp_op2_reg);
        free_int_reg(result);
    }
    else if (instr.op2.type == ir::Type::IntLiteral) // op2为常量
    {
        rv::rvREG tmp_op1_reg = alloc_and_load_int_reg(instr.op1);
        rv::rvREG tmp_op2_reg = alloc_int_reg();
        rv::rvREG result = alloc_int_reg();
        fout << "\tli\t" << toString(tmp_op2_reg) << "," << instr.op2.name << "\n";
        fout << "\tsltiu\t" << toString(result) << "," << toString(tmp_op1_reg) << ",1\n"; // 0 - 1  非0 - 0
        fout << "\txori\t" << toString(result) << "," << toString(result) << ",1\n"; // 0 - 0  非0 - 1
        fout << "\tsltiu\t" << toString(tmp_op2_reg) << "," << toString(tmp_op2_reg) << ",1\n"; // 0 - 1  非0 - 0
        fout << "\txori\t" << toString(tmp_op2_reg) << "," << toString(tmp_op2_reg) << ",1\n"; // 0 - 0  非0 - 1
        fout << "\tor\t" << toString(result) << "," << toString(result) << "," << toString(tmp_op2_reg) << "\n";
        save_int_operand(instr.des, result);
        free_int_reg(tmp_op1_reg);
        free_int_reg(tmp_op2_reg);
        free_int_reg(result);
    }
    else // 全变量
    {
        rv::rvREG tmp_op1_reg = alloc_and_load_int_reg(instr.op1);
        rv::rvREG tmp_op2_reg = alloc_and_load_int_reg(instr.op2);
        rv::rvREG result = alloc_int_reg();
        fout << "\tsltiu\t" << toString(result) << "," << toString(tmp_op1_reg) << ",1\n"; // 0 - 1  非0 - 0
        fout << "\txori\t" << toString(result) << "," << toString(result) << ",1\n"; // 0 - 0  非0 - 1
        fout << "\tsltiu\t" << toString(tmp_op2_reg) << "," << toString(tmp_op2_reg) << ",1\n"; // 0 - 1  非0 - 0
        fout << "\txori\t" << toString(tmp_op2_reg) << "," << toString(tmp_op2_reg) << ",1\n"; // 0 - 0  非0 - 1
        fout << "\tor\t" << toString(result) << "," << toString(result) << "," << toString(tmp_op2_reg) << "\n";
        save_int_operand(instr.des, result);
        free_int_reg(tmp_op1_reg);
        free_int_reg(tmp_op2_reg);
        free_int_reg(result);
    }
}

void backend::Generator::gen_instr_alloc(const ir::Instruction& instr)
{
    // op1为数组长度(常量IntLiteral), 目的操作数为数组名(存放一个指针)
    // 申请内存(直接增加stack_used_bytes)
    curr_stack_used_bytes += std::stoi(instr.op1.name) * 4;
    // 将申请到的内存地址存入目的操作数(使用addi)
    rv::rvREG result = alloc_int_reg();
    fout << "\taddi\t" << toString(result) << "," << "sp" << "," << -curr_stack_used_bytes << "\n";
    save_int_operand(instr.des, result);
    free_int_reg(result);
}

void backend::Generator::gen_instr_load(const ir::Instruction& instr)
{
    // op1为数组名, op2为数组下标, des为目标变量

    // op2为常量IntLiteral
    if (instr.op2.type == ir::Type::IntLiteral)
    {
        // 将数组名存入一个寄存器
        rv::rvREG tmp_op1_reg = alloc_and_load_int_reg(instr.op1);
        // 将数组下标存入一个寄存器
        rv::rvREG tmp_op2_reg = alloc_int_reg();
        int arr_offset = std::stoi(instr.op2.name) * 4; // 计算数组下标对应的地址
        // 计算数组下标对应的地址
        rv::rvREG result = alloc_int_reg();
        fout << "\tli\t" << toString(tmp_op2_reg) << "," << arr_offset << "\n";
        fout << "\tadd\t" << toString(tmp_op1_reg) << "," << toString(tmp_op1_reg) << "," << toString(tmp_op2_reg) << "\n";
        fout << "\tlw\t" << toString(result) << "," << "0("+toString(tmp_op1_reg)+")" << "\n";
        // 将数组下标对应的地址存入目标变量
        save_int_operand(instr.des, result);
        // 释放寄存器
        free_int_reg(tmp_op1_reg);
        free_int_reg(tmp_op2_reg);
        free_int_reg(result);
    }
    // op2为变量
    else
    {
        // 将数组名存入一个寄存器
        rv::rvREG tmp_op1_reg = alloc_and_load_int_reg(instr.op1);
        // 将数组下标存入一个寄存器
        rv::rvREG tmp_op2_reg = alloc_and_load_int_reg(instr.op2);
        // 计算数组下标对应的地址
        rv::rvREG result = alloc_int_reg();
        fout << "\tslli\t" << toString(tmp_op2_reg) << "," << toString(tmp_op2_reg) << ",2\n";
        fout << "\tadd\t" << toString(tmp_op1_reg) << "," << toString(tmp_op1_reg) << "," << toString(tmp_op2_reg) << "\n";
        fout << "\tlw\t" << toString(result) << "," << "0("+toString(tmp_op1_reg)+")" << "\n";
        // 将数组下标对应的地址存入目标变量
        save_int_operand(instr.des, result);
        // 释放寄存器
        free_int_reg(tmp_op1_reg);
        free_int_reg(tmp_op2_reg);
        free_int_reg(result);
    }
}

void backend::Generator::gen_instr_store(const ir::Instruction& instr)
{
    // op1为数组名, op2为数组下标, des为目标变量(可能常量)

    // op2为常量IntLiteral
    if (instr.op2.type == ir::Type::IntLiteral)
    {
        // 将数组名存入一个寄存器
        rv::rvREG tmp_op1_reg = alloc_and_load_int_reg(instr.op1);
        // 将数组下标存入一个寄存器
        rv::rvREG tmp_op2_reg = alloc_int_reg();
        int arr_offset = std::stoi(instr.op2.name) * 4; // 计算数组下标对应的地址
 
        
        rv::rvREG des;
        if (instr.des.type == ir::Type::IntLiteral)
        {
            des = alloc_int_reg();
            fout << "\tli\t" << toString(des) << "," << instr.des.name << "\n";
        }
        else
        {
            des = alloc_and_load_int_reg(instr.des);
        }
        fout << "\tli\t" << toString(tmp_op2_reg) << "," << arr_offset << "\n";
        fout << "\tadd\t" << toString(tmp_op1_reg) << "," << toString(tmp_op1_reg) << "," << toString(tmp_op2_reg) << "\n";
        fout << "\tsw\t" << toString(des) << "," << "0("+toString(tmp_op1_reg)+")" << "\n";
        // 释放寄存器
        free_int_reg(tmp_op1_reg);
        free_int_reg(tmp_op2_reg);
        free_int_reg(des);
    }
    // op2为变量
    else
    {
        // 将数组名存入一个寄存器
        rv::rvREG tmp_op1_reg = alloc_and_load_int_reg(instr.op1);
        // 将数组下标存入一个寄存器
        rv::rvREG tmp_op2_reg = alloc_and_load_int_reg(instr.op2);

        rv::rvREG des;
        if (instr.des.type == ir::Type::IntLiteral)
        {
            des = alloc_int_reg();
            fout << "\tli\t" << toString(des) << "," << instr.des.name << "\n";
        }
        else
        {
            des = alloc_and_load_int_reg(instr.des);
        }
        fout << "\tslli\t" << toString(tmp_op2_reg) << "," << toString(tmp_op2_reg) << ",2\n";
        fout << "\tadd\t" << toString(tmp_op1_reg) << "," << toString(tmp_op1_reg) << "," << toString(tmp_op2_reg) << "\n";
        fout << "\tsw\t" << toString(des) << "," << "0("+toString(tmp_op1_reg)+")" << "\n";
        // 释放寄存器
        free_int_reg(tmp_op1_reg);
        free_int_reg(tmp_op2_reg);
        free_int_reg(des);
    }
}

void backend::Generator::gen_instr_getptr(const ir::Instruction& instr)
{
    // 第一个操作数为数组名，第二个操作数为数组下标，运算结果仍为指针
    // op2为常量IntLiteral
    if (instr.op2.type == ir::Type::IntLiteral)
    {
        // 将数组名存入一个寄存器 (是否全局数组?)
        rv::rvREG tmp_op1_reg;
        if (!is_global(instr.op1.name))
            tmp_op1_reg = alloc_and_load_int_reg(instr.op1);
        else
        {
            tmp_op1_reg = alloc_int_reg();
            fout << "\tla\t" << toString(tmp_op1_reg) << "," << instr.op1.name << "\n";
        }
        // 将数组下标存入一个寄存器
        rv::rvREG tmp_op2_reg = alloc_int_reg();
        int arr_offset = std::stoi(instr.op2.name) * 4; // 计算数组下标对应的地址
        // 计算数组下标对应的地址
        rv::rvREG result = alloc_int_reg();
        fout << "\tli\t" << toString(tmp_op2_reg) << "," << arr_offset << "\n";
        fout << "\tadd\t" << toString(result) << "," << toString(tmp_op1_reg) << "," << toString(tmp_op2_reg) << "\n";
        // 将数组下标对应的地址存入目标变量
        save_int_operand(instr.des, result);
        // 释放寄存器
        free_int_reg(tmp_op1_reg);
        free_int_reg(tmp_op2_reg);
        free_int_reg(result);
    }
    // op2为变量
    else
    {
        // 将数组名存入一个寄存器 (是否全局数组?)
        rv::rvREG tmp_op1_reg;
        if (!is_global(instr.op1.name))
            tmp_op1_reg = alloc_and_load_int_reg(instr.op1);
        else
        {
            tmp_op1_reg = alloc_int_reg();
            fout << "\tla\t" << toString(tmp_op1_reg) << "," << instr.op1.name << "\n";
        }
        // 将数组下标存入一个寄存器
        rv::rvREG tmp_op2_reg = alloc_and_load_int_reg(instr.op2);
        // 计算数组下标对应的地址
        rv::rvREG result = alloc_int_reg();
        fout << "\tslli\t" << toString(tmp_op2_reg) << "," << toString(tmp_op2_reg) << ",2\n";
        fout << "\tadd\t" << toString(result) << "," << toString(tmp_op1_reg) << "," << toString(tmp_op2_reg) << "\n";
        // 将数组下标对应的地址存入目标变量
        save_int_operand(instr.des, result);
        // 释放寄存器
        free_int_reg(tmp_op1_reg);
        free_int_reg(tmp_op2_reg);
        free_int_reg(result);
    }
}

void backend::Generator::gen_instr_call(const ir::Instruction& instr)
{
    // 第一个操作数的name应为函数名，结果操作数为函数返回值
    const auto* instr_ptr = &instr;
    auto callinst_ptr = dynamic_cast<const ir::CallInst*>(instr_ptr);
    assert(callinst_ptr);

    if (instr.op1.name == "main" || instr.op1.name == "global")
    {
        return;
    }

    // 判断是否要多开栈空间
    if (callinst_ptr->argumentList.size() > 8)
    {
        // 开栈
        curr_stack_used_bytes += (callinst_ptr->argumentList.size() - 8) * 4;
    }

    // 首先将所有参数存入对应的寄存器
    std::vector<rv::rvREG> int_arg_regs {rv::rvREG::A0, rv::rvREG::A1, rv::rvREG::A2, rv::rvREG::A3, rv::rvREG::A4, rv::rvREG::A5, rv::rvREG::A6, rv::rvREG::A7};
    for (int i = 0; i < callinst_ptr->argumentList.size(); i++)
    {
        if (i <= 7)  // 放入a0~a7
        {
            // 判断是否为变量
            if (callinst_ptr->argumentList[i].type == ir::Type::IntLiteral)
            {
                fout << "\tli\t" << toString(int_arg_regs[i]) << "," << callinst_ptr->argumentList[i].name << "\n";
            }
            else
            {
                rv::rvREG tmp_reg = alloc_and_load_int_reg(callinst_ptr->argumentList[i]);
                fout << "\tmv\t" << toString(int_arg_regs[i]) << "," << toString(tmp_reg) << "\n";
                free_int_reg(tmp_reg);
            }
        }
        else // 放入栈中
        {
            // 判断是否为变量
            if (callinst_ptr->argumentList[i].type == ir::Type::IntLiteral)
            {
                rv::rvREG tmp = alloc_int_reg();
                rv::rvREG tmp_stack_addr = alloc_int_reg();
                fout << "\tli\t" << toString(tmp) << "," << callinst_ptr->argumentList[i].name << "\n";
                fout << "\taddi\t" << toString(tmp_stack_addr) << "," << toString(rv::rvREG::SP) << "," << -curr_stack_used_bytes << "\n";
                fout << "\tsw\t" << toString(tmp) << "," << (i-8)*4 << "(" << toString(tmp_stack_addr) << ")\n";
                free_int_reg(tmp);
                free_int_reg(tmp_stack_addr);
            }
            else
            {
                rv::rvREG tmp = alloc_and_load_int_reg(callinst_ptr->argumentList[i]);
                rv::rvREG tmp_stack_addr = alloc_int_reg();
                fout << "\taddi\t" << toString(tmp_stack_addr) << "," << toString(rv::rvREG::SP) << "," << -curr_stack_used_bytes << "\n";
                fout << "\tsw\t" << toString(tmp) << "," << (i-8)*4 << "(" << toString(tmp_stack_addr) << ")\n";
                free_int_reg(tmp);
                free_int_reg(tmp_stack_addr);
            }
        }
    }
    // 设置栈指针
    fout << "\taddi\t" << toString(rv::rvREG::SP) << "," << toString(rv::rvREG::SP) << "," << -curr_stack_used_bytes << "\n";
    // 然后CALL
    fout << "\tcall\t" << callinst_ptr->op1.name << "\n";
    // 恢复栈指针
    fout << "\taddi\t" << toString(rv::rvREG::SP) << "," << toString(rv::rvREG::SP) << "," << curr_stack_used_bytes << "\n";
    // 然后获取结果
    if (instr.des.type != ir::Type::null)
        save_int_operand(instr.des, rv::rvREG::A0);
}

void backend::Generator::gen_instr_goto(const ir::Instruction& instr)
{
    // 第一个操作数为跳转条件，其为整形变量或type = Type::null的变量，当为整形变量时表示条件跳转（值不等于0发生跳转），否则为无条件跳转。第二个操作数不使用，目的操作数应为整形(IntLiteral)，其值为跳转相对目前pc的偏移量
    int ir_jump_offset = std::stoi(instr.des.name);
    // 是有条件还是无条件?
    if (instr.op1.type == ir::Type::IntLiteral || instr.op1.type == ir::Type::Int)
    {
        // 有条件
        rv::rvREG tmp_reg;
        if (instr.op1.type == ir::Type::Int)
        {
            tmp_reg = alloc_and_load_int_reg(instr.op1);
        }
        else
        {
            tmp_reg = alloc_int_reg();
            fout << "\tli\t" << toString(tmp_reg) << "," << instr.op1.name << "\n";
        }
        // 分支到提前分配好的Label处
        fout << "\tbnez\t" << toString(tmp_reg) << "," << jump_label_map[curr_ir_addr+ir_jump_offset] << "\n";
        free_int_reg(tmp_reg);
    }
    else
    {
        // 无条件跳转到提前分配好的Label处
        fout << "\tj\t" << jump_label_map[curr_ir_addr+ir_jump_offset] << "\n";
    }
}

void backend::Generator::gen_instr_unuse(const ir::Instruction& instr)
{
    fout << "\tnop\n";
}