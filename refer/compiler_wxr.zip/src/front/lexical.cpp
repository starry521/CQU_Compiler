#include "front/lexical.h"

#include <map>
#include <cassert>
#include <string>

#define TODO assert(0 && "todo")

// #define DEBUG_DFA
// #define DEBUG_SCANNER

std::string preproccess(std::ifstream &fin)
{ // Scanner预处理函数, 传入ifstream, 返回读取一行的结果(去除注释)
    std::string result = "\n";
    while (!fin.eof())
    {
        char c;
        fin.get(c);
        if (fin.eof())
            break;

        static bool in_multiline_comment = false; // 是否进入多行注释状态的标志
        static bool in_line_comment = false; // 是否进入单行注释状态的标志

        // 判断是否进入单行注释状态
        if (!in_multiline_comment && c == '/')
        {
            char next_c = fin.peek();
            if (next_c == '/')
            {
                in_line_comment = true;
                fin.get(c);
                continue;
            }
        }

        // 判断是否退出单行注释状态
        if (in_line_comment && c == '\n')
        {
            in_line_comment = false;
            continue;
        }

        // 判断是否进入多行注释状态
        if (!in_line_comment && c == '/')
        {
            char next_c = fin.peek();
            if (next_c == '*')
            {
                in_multiline_comment = true;
                fin.get(c);
                continue;
            }
        }
        // 判断是否退出多行注释状态
        if (in_multiline_comment && c == '*')
        {
            char next_c = fin.peek();
            if (next_c == '/')
            {
                in_multiline_comment = false;
                fin.get(c);
                continue;
            }
        }
        
        // 若处于多行或单行注释状态，则跳过当前读取的字符
        if (in_multiline_comment || in_line_comment)
            continue;

        // 将当前读取的字符加入到结果中
        result += c;
    }
    result += "\n";
    std::cout << result << std::endl;
    return result;
}

std::string frontend::toString(State s)
{
    switch (s)
    {
    case State::Empty:
        return "Empty";
    case State::Ident:
        return "Ident";
    case State::IntLiteral:
        return "IntLiteral";
    case State::FloatLiteral:
        return "FloatLiteral";
    case State::op:
        return "op";
    default:
        assert(0 && "invalid State");
    }
    return "";
}

std::set<std::string> frontend::keywords = {
    "const", "int", "float", "if", "else", "while", "continue", "break", "return", "void"};

frontend::DFA::DFA() : cur_state(frontend::State::Empty), cur_str() {}

frontend::DFA::~DFA() {}

frontend::TokenType get_op_type(std::string s)
{
    if (s == "+")
        return frontend::TokenType::PLUS;
    if (s == "-")
        return frontend::TokenType::MINU;
    if (s == "*")
        return frontend::TokenType::MULT;
    if (s == "/")
        return frontend::TokenType::DIV;
    if (s == "%")
        return frontend::TokenType::MOD;
    if (s == "<")
        return frontend::TokenType::LSS;
    if (s == ">")
        return frontend::TokenType::GTR;
    if (s == ":")
        return frontend::TokenType::COLON;
    if (s == "=")
        return frontend::TokenType::ASSIGN;
    if (s == ";")
        return frontend::TokenType::SEMICN;
    if (s == ",")
        return frontend::TokenType::COMMA;
    if (s == "(")
        return frontend::TokenType::LPARENT;
    if (s == ")")
        return frontend::TokenType::RPARENT;
    if (s == "[")
        return frontend::TokenType::LBRACK;
    if (s == "]")
        return frontend::TokenType::RBRACK;
    if (s == "{")
        return frontend::TokenType::LBRACE;
    if (s == "}")
        return frontend::TokenType::RBRACE;
    if (s == "!")
        return frontend::TokenType::NOT;
    if (s == "<=")
        return frontend::TokenType::LEQ;
    if (s == ">=")
        return frontend::TokenType::GEQ;
    if (s == "==")
        return frontend::TokenType::EQL;
    if (s == "!=")
        return frontend::TokenType::NEQ;
    if (s == "&&")
        return frontend::TokenType::AND;
    if (s == "||")
        return frontend::TokenType::OR;

    std::cout << "Invalid Op:" << s << std::endl;

    assert(0 && "invalid  op");
}

frontend::TokenType get_ident_type(std::string s)
{
    // 关键字有单独的TOKENTYPE
    if (s == "const")
        return frontend::TokenType::CONSTTK;
    if (s == "int")
        return frontend::TokenType::INTTK;
    if (s == "float")
        return frontend::TokenType::FLOATTK;
    if (s == "if")
        return frontend::TokenType::IFTK;
    if (s == "else")
        return frontend::TokenType::ELSETK;
    if (s == "while")
        return frontend::TokenType::WHILETK;
    if (s == "continue")
        return frontend::TokenType::CONTINUETK;
    if (s == "break")
        return frontend::TokenType::BREAKTK;
    if (s == "return")
        return frontend::TokenType::RETURNTK;
    if (s == "void")
        return frontend::TokenType::VOIDTK;

    // 函数 or 变量名
    return frontend::TokenType::IDENFR;
}

// 所有运算符包含字符
std::set<char> char_ops = {'+', '-', '*', '/', '%', '<', '>', '=', ':', ';', '(', ')', '[', ']', '{', '}', '!', '&', '|', ','};

// 所有运算符
std::set<std::string> ops = {"+", "-", "*", "/", "%", "<", ">", "=", ":", ";", "(", ")", "[", "]", "{", "}", "!", "&", "|", ",", "<=", ">=", "==", "!=", "&&", "||"};

bool frontend::DFA::next(char input, Token &buf)
{
#ifdef DEBUG_DFA
#include <iostream>
    std::cout << "in state [" << toString(cur_state) << "], input = \'" << input << "\', str = " << cur_str << "\t";
#endif
    bool is_end = false;
    switch (cur_state)
    {
    case frontend::State::Empty:
        // 从Empty转换到Ident(标识符)状态
        if (isalpha(input) || input == '_')
        {
            cur_state = frontend::State::Ident;
            cur_str += input;
            break;
        }
        // 从Empty转换到IntLiteral(整数)状态
        if (isdigit(input))
        {
            cur_state = frontend::State::IntLiteral;
            cur_str += input;
            break;
        }
        // 从Empty转换到FloatLiteral(浮点数)状态
        if (input == '.')
        {
            cur_state = frontend::State::FloatLiteral;
            cur_str += input;
            break;
        }
        // 从Empty转换到Op(运算符)状态
        if (char_ops.count(input))
        {
            cur_state = frontend::State::op;
            cur_str += input;
            break;
        }
        // 从Empty转换到Empty状态
        if (isspace(input))
        {
            reset();
            break;
        }

    case frontend::State::Ident:
        // 从Ident转换到Ident状态
        if (isalpha(input) || isdigit(input) || input == '_')
        {
            cur_str += input;
            break;
        }
        // 从Ident转换到Op状态
        if (char_ops.count(input))
        {
            buf.type = get_ident_type(cur_str);
            buf.value = cur_str;
            cur_state = frontend::State::op;
            cur_str = input;
            is_end = true;
            break;
        }
        // 从Ident转换到Empty状态
        if (isspace(input))
        {
            buf.type = get_ident_type(cur_str);
            buf.value = cur_str;
            reset();
            is_end = true;
            break;
        }

    case frontend::State::op:
        // 从Op转换到Op状态
        if (char_ops.count(input))
        {
            if (ops.count(cur_str + input)) // 如果可以,则继续
            {
                cur_str += input;
                break;
            }
            else // 重新开始
            {
                buf.type = get_op_type(cur_str);
                buf.value = cur_str;
                cur_state = frontend::State::op;
                cur_str = input;
                is_end = true;
                break;
            }
        }
        // 从Op转换到Empty状态
        if (isspace(input))
        {
            buf.type = get_op_type(cur_str);
            buf.value = cur_str;
            reset();
            is_end = true;
            break;
        }
        // 从Op转换到Ident状态
        if (isalpha(input) || input == '_')
        {
            buf.type = get_op_type(cur_str);
            buf.value = cur_str;
            cur_state = frontend::State::Ident;
            cur_str = input;
            is_end = true;
            break;
        }
        // 从Op转换到IntLiteral状态
        if (isdigit(input))
        {
            buf.type = get_op_type(cur_str);
            buf.value = cur_str;
            cur_state = frontend::State::IntLiteral;
            cur_str = input;
            is_end = true;
            break;
        }
        // 从Op转换到FloatLiteral状态
        if (input == '.')
        {
            buf.type = get_op_type(cur_str);
            buf.value = cur_str;
            cur_state = frontend::State::FloatLiteral;
            cur_str = input;
            is_end = true;
            break;
        }

    case frontend::State::IntLiteral:
        // 从IntLiteral转换到IntLiteral状态
        if (isdigit(input) || (input >= 'a' && input <= 'f') || (input >= 'A' && input <= 'F') || input == 'x' || input == 'X') // 二进制,十六进制常量支持
        {
            cur_str += input;
            break;
        }
        // 从IntLiteral转换到FloatLiteral状态
        if (input == '.')
        {
            cur_state = frontend::State::FloatLiteral;
            cur_str += input;
            break;
        }
        // 从IntLiteral转换到Empty状态
        if (isspace(input))
        {
            buf.type = frontend::TokenType::INTLTR;
            buf.value = cur_str;
            reset();
            is_end = true;
            break;
        }
        // 从IntLiteral转换到Op状态
        if (char_ops.find(input) != char_ops.end())
        {
            buf.type = frontend::TokenType::INTLTR;
            buf.value = cur_str;
            cur_state = frontend::State::op;
            cur_str = input;
            is_end = true;
            break;
        }

    case frontend::State::FloatLiteral:
        // 从FloatLiteral转换到FloatLiteral状态
        if (isdigit(input))
        {
            cur_str += input;
            break;
        }
        // 从FloatLiteral转换到Empty状态
        if (isspace(input))
        {
            buf.type = frontend::TokenType::FLOATLTR;
            buf.value = cur_str;
            reset();
            is_end = true;
            break;
        }
        // 从FloatLiteral转换到Op状态
        if (char_ops.find(input) != char_ops.end())
        {
            buf.type = frontend::TokenType::FLOATLTR;
            buf.value = cur_str;
            cur_state = frontend::State::op;
            cur_str = input;
            is_end = true;
            break;
        }
    }
#ifdef DEBUG_DFA
    std::cout << "next state is [" << toString(cur_state) << "], next str = " << cur_str << "\t, ret = " << is_end << std::endl;
#endif
    return is_end;
}

void frontend::DFA::reset()
{
    cur_state = State::Empty;
    cur_str = "";
}

frontend::Scanner::Scanner(std::string filename) : fin(filename)
{
    if (!fin.is_open())
    {
        assert(0 && "in Scanner constructor, input file cannot open");
    }
}

frontend::Scanner::~Scanner()
{
    fin.close();
}

std::vector<frontend::Token> frontend::Scanner::run()
{
    std::vector<Token> ret;
    Token tk;
    DFA dfa;
    std::string s = preproccess(fin); // delete comments
    s += "\n";                        // 补上换行符
    for (auto c : s)
    {
        if (dfa.next(c, tk))
        {
#ifdef DEBUG_SCANNER
#include <iostream>
            std::cout << "token: " << toString(tk.type) << "\t" << tk.value << std::endl;
#endif
            ret.push_back(tk);
        }
    }

    return ret;
}