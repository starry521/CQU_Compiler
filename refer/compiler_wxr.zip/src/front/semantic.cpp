#include "front/semantic.h"

#include <cassert>
#include <iostream>

using ir::Function;
using ir::Instruction;
using ir::Operand;
using ir::Operator;

#define TODO assert(0 && "TODO");

#define GET_CHILD_PTR(node, type, index)                     \
    auto node = dynamic_cast<type *>(root->children[index]); \
    assert(node);
#define ANALYSIS(node, type, index)                          \
    auto node = dynamic_cast<type *>(root->children[index]); \
    assert(node);                                            \
    analysis##type(node, buffer);
#define COPY_EXP_NODE(from, to)              \
    to->is_computable = from->is_computable; \
    to->v = from->v;                         \
    to->t = from->t;

map<std::string, ir::Function *> *frontend::get_lib_funcs()
{
    static map<std::string, ir::Function *> lib_funcs = {
        {"getint", new Function("getint", Type::Int)},
        {"getch", new Function("getch", Type::Int)},
        {"getfloat", new Function("getfloat", Type::Float)},
        {"getarray", new Function("getarray", {Operand("arr", Type::IntPtr)}, Type::Int)},
        {"getfarray", new Function("getfarray", {Operand("arr", Type::FloatPtr)}, Type::Int)},
        {"putint", new Function("putint", {Operand("i", Type::Int)}, Type::null)},
        {"putch", new Function("putch", {Operand("i", Type::Int)}, Type::null)},
        {"putfloat", new Function("putfloat", {Operand("f", Type::Float)}, Type::null)},
        {"putarray", new Function("putarray", {Operand("n", Type::Int), Operand("arr", Type::IntPtr)}, Type::null)},
        {"putfarray", new Function("putfarray", {Operand("n", Type::Int), Operand("arr", Type::FloatPtr)}, Type::null)},
    };
    return &lib_funcs;
}

void frontend::SymbolTable::add_scope()
{
    ScopeInfo scope_info;
    scope_info.cnt = 0;
    scope_info.name = "block" + std::to_string(block_cnt++);
    scope_stack.push_back(scope_info);
}
void frontend::SymbolTable::exit_scope()
{
    scope_stack.pop_back();
}

void frontend::SymbolTable::add_ste(string id, frontend::STE ste)
{
    assert(!scope_stack.back().table.count(id)); // 不允许重复声明
    scope_stack.back().table[id] = ste;
}

string frontend::SymbolTable::get_scoped_name(string id) const
{
    // 从最近的作用域开始查找
    for (int i = scope_stack.size() - 1; i >= 0; i--)
    {
        auto find_result = scope_stack[i].table.find(id); // 避免const 报错没有与这些操作数匹配的 "[]" 运算符    （真是依托答辩）
        if (find_result != scope_stack[i].table.end())
            return id + "_" + scope_stack[i].name;
    }
    assert(0 && "Symbol Not Found");
}

Operand frontend::SymbolTable::get_operand(string id) const
{
    // 从最近的作用域开始查找
    for (int i = scope_stack.size() - 1; i >= 0; i--)
    {
        auto find_result = scope_stack[i].table.find(id); // 避免const 报错没有与这些操作数匹配的 "[]" 运算符    （真是依托答辩）
        if (find_result != scope_stack[i].table.end())
            return find_result->second.operand;
    }
    assert(0 && "Operand Not Found");
}

frontend::STE frontend::SymbolTable::get_ste(string id) const
{
    // 从最近的作用域开始查找
    for (int i = scope_stack.size() - 1; i >= 0; i--)
    {
        auto find_result = scope_stack[i].table.find(id); // 避免const 报错没有与这些操作数匹配的 "[]" 运算符    （真是依托答辩）
        if (find_result != scope_stack[i].table.end())
            return find_result->second;
    }
    assert(0 && "STE Not Found");
}

frontend::Analyzer::Analyzer() : tmp_cnt(0), symbol_table()
{
}

ir::Program frontend::Analyzer::get_ir_program(CompUnit *root)
{
    // 初始化一层作用域：全局作用域
    symbol_table.add_scope();
    // 初始化全局函数
    ir::Function *global_func = new ir::Function("global", ir::Type::null);
    symbol_table.functions["global"] = global_func;
    // 添加库函数
    auto lib_funcs = *get_lib_funcs();
    for (auto it = lib_funcs.begin(); it != lib_funcs.end(); it++)
        symbol_table.functions[it->first] = it->second;
    // 开始DFS遍历AST进行分析
    analyze_compunit(root);
    // 将全局作用域中的变量加入globalVars
    for (auto it = symbol_table.scope_stack[0].table.begin(); it != symbol_table.scope_stack[0].table.end(); it++)
    {
        if (it->second.dimension.size() != 0)
        {
            int arr_len = 1;
            for (int i = 0; i < it->second.dimension.size(); i++)
                arr_len *= it->second.dimension[i];
            // 执行IR变量重命名
            ir_program.globalVal.push_back({{symbol_table.get_scoped_name(it->second.operand.name),it->second.operand.type}, arr_len});
        }
        else
        {
            // 执行IR变量重命名, 并丢弃常量
            if (it->second.operand.type != Type::FloatLiteral && it->second.operand.type != Type::IntLiteral)
                ir_program.globalVal.push_back({{symbol_table.get_scoped_name(it->second.operand.name),it->second.operand.type}});
        }
    }
    // 为全局函数添加return
    ir::Instruction* globalreturn = new ir::Instruction(ir::Operand(),
                                 ir::Operand(),
                                 ir::Operand(), ir::Operator::_return);
    global_func->addInst(globalreturn);
    ir_program.addFunction(*global_func);
    return ir_program;
}

/*
CompUnit -> (Decl | FuncDef) [CompUnit]

Decl -> ConstDecl | VarDecl

ConstDecl -> 'const' BType ConstDef { ',' ConstDef } ';'

ConstDecl.t
BType -> 'int' | 'float'

BType.t
ConstDef -> Ident { '[' ConstExp ']' } '=' ConstInitVal

ConstDef.arr_name
ConstInitVal -> ConstExp | '{' [ ConstInitVal { ',' ConstInitVal } ] '}'

ConstInitVal.v
ConstInitVal.t
VarDecl -> BType VarDef { ',' VarDef } ';'

VarDecl.t
VarDef -> Ident { '[' ConstExp ']' } [ '=' InitVal ]

VarDef.arr_name
InitVal -> Exp | '{' [ InitVal { ',' InitVal } ] '}'

InitVal.is_computable
InitVal.v
InitVal.t
FuncDef -> FuncType Ident '(' [FuncFParams] ')' Block

FuncDef.t
FuncDef.n
FuncType -> 'void' | 'int' | 'float'

FuncFParam -> BType Ident ['[' ']' { '[' Exp ']' }]

FuncFParams -> FuncFParam { ',' FuncFParam }

Block -> '{' { BlockItem } '}'

BlockItem -> Decl | Stmt

Stmt -> LVal '=' Exp ';' | Block | 'if' '(' Cond ')' Stmt [ 'else' Stmt ] | 'while' '(' Cond ')' Stmt | 'break' ';' | 'continue' ';' | 'return' [Exp] ';' | [Exp] ';'

Exp -> AddExp

Exp.is_computable
Exp.v
Exp.t
Cond -> LOrExp

Cond.is_computable
Cond.v
Cond.t
LVal -> Ident {'[' Exp ']'}

LVal.is_computable
LVal.v
LVal.t
LVal.i
Number -> IntConst | floatConst

PrimaryExp -> '(' Exp ')' | LVal | Number

PrimaryExp.is_computable
PrimaryExp.v
PrimaryExp.t
UnaryExp -> PrimaryExp | Ident '(' [FuncRParams] ')' | UnaryOp UnaryExp

UnaryExp.is_computable
UnaryExp.v
UnaryExp.t
UnaryOp -> '+' | '-' | '!'

FuncRParams -> Exp { ',' Exp }

MulExp -> UnaryExp { ('*' | '/' | '%') UnaryExp }

MulExp.is_computable
MulExp.v
MulExp.t
AddExp -> MulExp { ('+' | '-') MulExp }

AddExp.is_computable
AddExp.v
AddExp.t
RelExp -> AddExp { ('<' | '>' | '<=' | '>=') AddExp }

RelExp.is_computable
RelExp.v
RelExp.t
EqExp -> RelExp { ('==' | '!=') RelExp }

EqExp.is_computable
EqExp.v
EqExp.t
LAndExp -> EqExp [ '&&' LAndExp ]

LAndExp.is_computable
LAndExp.v
LAndExp.t
LOrExp -> LAndExp [ '||' LOrExp ]

LOrExp.is_computable
LOrExp.v
LOrExp.t
ConstExp -> AddExp

ConstExp.is_computable: true
ConstExp.v
ConstExp.t
*/

void frontend::Analyzer::analyze_compunit(CompUnit *root)
{
    // 判断是变量声明还是函数声明
    if (Decl *decl = dynamic_cast<Decl *>(root->children[0])) // 全局变量声明, 需向globalVars中添加变量, 并将相应的初始化函数放入global函数中
    {
        vector<ir::Instruction *> decl_insts = analyze_decl(decl);
        for (auto inst : decl_insts)
            symbol_table.functions["global"]->addInst(inst);
    }
    else if (FuncDef *funcdef = dynamic_cast<FuncDef *>(root->children[0]))
    {
        analyze_funcdef(funcdef);
    }
    else
    {
        assert(0 && "Invalid CompUnit");
    }
    // 若children的长度为2,则继续分析
    if (root->children.size() == 2)
    {
        CompUnit *dcast_compunit = dynamic_cast<CompUnit *>(root->children[1]);
        assert(dcast_compunit != nullptr);
        analyze_compunit(dcast_compunit);
    }
}

vector<ir::Instruction *> frontend::Analyzer::analyze_decl(Decl *root)
{
    // 变量声明，生成相应的IR指令，并将变量加入符号表中(分别在对应的ConstDecl和VarDecl中实现)。 (? 全局变量的处理方法？ 是在全部程序编译完后，再在最外层函数处理吗？)

    // 分支判断ConstDecl | VarDecl
    if (ConstDecl *constdecl = dynamic_cast<ConstDecl *>(root->children[0]))
    {
        return analyze_constdecl(constdecl);
    }
    else if (VarDecl *vardecl = dynamic_cast<VarDecl *>(root->children[0]))
    {
        return analyze_vardecl(vardecl);
    }
    else
    {
        assert(0 && "Invalid Decl");
    }
}

vector<ir::Instruction *> frontend::Analyzer::analyze_constdecl(ConstDecl* root)
{
    vector<ir::Instruction *> result;
    // 解析BType，并解析ConstDef
    auto btype = dynamic_cast<BType*>(root->children[1]);
    assert(btype != nullptr);
    auto btype_token = dynamic_cast<Term*>(btype->children[0]);
    assert(btype_token != nullptr);
    ir::Type type; // 仅限于int和float
    if (btype_token->token.type == TokenType::INTTK)
    {
        type = ir::Type::Int;
    }
    else if (btype_token->token.type == TokenType::FLOATTK)
    {
        type = ir::Type::Float;
    }
    else
    {
        assert(0 && "Invalid BType");
    }
    for (int i = 2; i < root->children.size(); i += 2)
    {
        // 解析constdef
        ConstDef* constdef = dynamic_cast<ConstDef*>(root->children[i]);
        assert(constdef != nullptr);
        // 确定变量名
        Term* ident_term = dynamic_cast<Term*>(constdef->children[0]);
        assert(ident_term->token.type == TokenType::IDENFR);
        string var_name = ident_term->token.value;
        // 判断是否是数组类型变量
        if (constdef->children.size() == 6)
        {
            // 1维数组
            ConstExp* constexp = dynamic_cast<ConstExp*>(constdef->children[2]);
            assert(constexp != nullptr);
            // 计算数组形状
            calculate_constexp(constexp);
            assert(constexp->t == ir::Type::IntLiteral);
            int array_size = std::stoi(constexp->v);
            // 插入符号表
            STE arr_ste;
            arr_ste.dimension.push_back(array_size);
            ir::Type curr_type = type;
            if (curr_type == ir::Type::Int)
            {
                curr_type = ir::Type::IntPtr;
            }
            else if (curr_type == ir::Type::Float)
            {
                curr_type = ir::Type::FloatPtr;
            }
            else
            {
                assert(0 && "Invalid Type");
            }
            arr_ste.operand = ir::Operand(var_name, curr_type);
            symbol_table.scope_stack.back().table[var_name] = arr_ste;
            // 生成IR指令 (为全局数组时不用!!)
            if (symbol_table.scope_stack.size() > 1)
            {
                ir::Instruction* allocInst = new ir::Instruction(ir::Operand(std::to_string(array_size),ir::Type::IntLiteral),
                                ir::Operand(),
                                ir::Operand(symbol_table.get_scoped_name(var_name),curr_type),ir::Operator::alloc);
                result.push_back(allocInst);
            }
            // 一维数组的初始化，只能为{a,b,c...} ，从测试用例来看，二维的初始化，也为{a,b,c...}
            ConstInitVal* constinit = dynamic_cast<ConstInitVal*>(constdef->children.back());
            assert(constinit != nullptr);
            // 从1、3、5开始初始化
            int cnt = 0;
            for (int i = 1; i < constinit->children.size()-1; i += 2, cnt += 1)
            {
                ConstInitVal* child_constinit = dynamic_cast<ConstInitVal*>(constinit->children[i]);
                assert(child_constinit != nullptr);
                ConstExp* constexp = dynamic_cast<ConstExp*>(child_constinit->children[0]);
                assert(constexp != nullptr);
                // 计算值
                calculate_constexp(constexp);
                if (curr_type == ir::Type::IntPtr)
                {
                    assert(constexp->t == ir::Type::FloatLiteral || constexp->t == ir::Type::IntLiteral);
                    // 允许隐式类型转化 Float -> Int
                    int val;
                    if (constexp->t == ir::Type::Float)
                    {
                        val = std::stof(constexp->v);
                    }
                    else
                    {
                        val = std::stoi(constexp->v);
                    }
                    ir::Instruction* storeInst = new ir::Instruction(ir::Operand(symbol_table.get_scoped_name(var_name),ir::Type::IntPtr),
                            ir::Operand(std::to_string(cnt),ir::Type::IntLiteral),
                            ir::Operand(std::to_string(val),ir::Type::IntLiteral),ir::Operator::store);
                    result.push_back(storeInst);
                }
                else if (curr_type == ir::Type::FloatPtr)
                {
                    // 允许类型提升 Int --提升至--> Float
                    assert(constexp->t == ir::Type::FloatLiteral || constexp->t == ir::Type::IntLiteral);
                    float val = std::stof(constexp->v);
                    ir::Instruction* storeInst = new ir::Instruction(ir::Operand(symbol_table.get_scoped_name(var_name),ir::Type::FloatPtr),
                            ir::Operand(std::to_string(cnt),ir::Type::IntLiteral),
                            ir::Operand(std::to_string(val),ir::Type::FloatLiteral),ir::Operator::store);
                    result.push_back(storeInst);
                }
                else
                {
                    assert(0 && "Invalid Calculate Type");
                }
            }
            // 判断是否是全局数组的初始化，若为全局，则ir库会帮我自动将值初始化为0
            // 局部变量初始化, 注意此处为Const数组, 则其必须使用{}, 未指定值的元素一定会被置为0
            if (symbol_table.scope_stack.size() > 1)
            {
                // 局部变量, 未指定值置为0
                for (int i = cnt; i < array_size; i++)
                {
                    ir::Instruction* storeInst;
                    if (curr_type == ir::Type::FloatPtr)
                        storeInst = new ir::Instruction(ir::Operand(symbol_table.get_scoped_name(var_name),ir::Type::FloatPtr),
                            ir::Operand(std::to_string(i),ir::Type::IntLiteral),
                            ir::Operand("0.0",ir::Type::FloatLiteral),ir::Operator::store);
                    else if (curr_type == ir::Type::IntPtr)
                        storeInst = new ir::Instruction(ir::Operand(symbol_table.get_scoped_name(var_name),ir::Type::IntPtr),
                            ir::Operand(std::to_string(i),ir::Type::IntLiteral),
                            ir::Operand("0",ir::Type::IntLiteral),ir::Operator::store);
                    else
                        assert(0 && "Invalid Type");
                    result.push_back(storeInst);
                }
            }
        }
        else if (constdef->children.size() == 9)
        {
            // 2维数组
            ConstExp* constexp1 = dynamic_cast<ConstExp*>(constdef->children[2]);
            assert(constexp1 != nullptr);
            ConstExp* constexp2 = dynamic_cast<ConstExp*>(constdef->children[5]);
            assert(constexp2 != nullptr);
            // 计算数组形状
            calculate_constexp(constexp1);
            calculate_constexp(constexp2);
            assert(constexp1->t == ir::Type::IntLiteral && constexp2->t == ir::Type::IntLiteral);
            int array_dim1 = std::stoi(constexp1->v); // 第一维大小
            int array_dim2 = std::stoi(constexp2->v); // 第二维大小
            int array_size = array_dim1 * array_dim2;
            // 插入符号表
            STE arr_ste;
            arr_ste.dimension.push_back(array_dim1);
            arr_ste.dimension.push_back(array_dim2);
            ir::Type curr_type = type;
            if (curr_type == ir::Type::Int)
            {
                curr_type = ir::Type::IntPtr;
            }
            else if (curr_type == ir::Type::Float)
            {
                curr_type = ir::Type::FloatPtr;
            }
            else
            {
                assert(0 && "Invalid Type");
            }
            arr_ste.operand = ir::Operand(var_name, curr_type);
            symbol_table.scope_stack.back().table[var_name] = arr_ste;
            // 生成IR指令 (为全局数组时不用!!)
            if (symbol_table.scope_stack.size() > 1)
            {
                ir::Instruction* allocInst = new ir::Instruction(ir::Operand(std::to_string(array_size),ir::Type::IntLiteral),
                                ir::Operand(),
                                ir::Operand(symbol_table.get_scoped_name(var_name),curr_type),ir::Operator::alloc);
                result.push_back(allocInst);
            }
            // 从测试用例来看，二维的初始化，也为{a,b,c...}
            ConstInitVal* constinit = dynamic_cast<ConstInitVal*>(constdef->children.back());
            assert(constinit != nullptr);
            // 从1、3、5...开始初始化
            int cnt = 0;
            for (int i = 1; i < constinit->children.size()-1; i += 2, cnt += 1)
            {
                ConstInitVal* child_constinit = dynamic_cast<ConstInitVal*>(constinit->children[i]);
                assert(child_constinit != nullptr);
                ConstExp* constexp = dynamic_cast<ConstExp*>(child_constinit->children[0]);
                assert(constexp != nullptr);
                // 计算值
                calculate_constexp(constexp);
                if (curr_type == ir::Type::IntPtr)
                {
                    // 允许隐式类型转换 Float -> Int
                    assert(constexp->t == ir::Type::Float || constexp->t == ir::Type::Int);
                    int val;
                    if (constexp->t == ir::Type::Float)
                        val = std::stof(constexp->v);
                    else
                        val = std::stoi(constexp->v);
                    ir::Instruction* storeInst = new ir::Instruction(ir::Operand(symbol_table.get_scoped_name(var_name),ir::Type::IntPtr),
                            ir::Operand(std::to_string(cnt),ir::Type::IntLiteral),
                            ir::Operand(std::to_string(val),ir::Type::IntLiteral),ir::Operator::store);
                    result.push_back(storeInst);
                }
                else if (curr_type == ir::Type::FloatPtr)
                {
                    // 允许类型提升 Int --提升至--> Float
                    assert(constexp->t == ir::Type::Float || constexp->t == ir::Type::Int);
                    float val = std::stof(constexp->v);
                    ir::Instruction* storeInst = new ir::Instruction(ir::Operand(symbol_table.get_scoped_name(var_name),ir::Type::FloatPtr),
                            ir::Operand(std::to_string(cnt),ir::Type::IntLiteral),
                            ir::Operand(std::to_string(val),ir::Type::FloatLiteral),ir::Operator::store);
                    result.push_back(storeInst);
                }
                else
                {
                    assert(0 && "Invalid Calculate Type");
                }
            }
            // 判断是否是全局数组的初始化，若为全局，则ir库会帮我自动将值初始化为0
            // 局部变量初始化, 注意此处为Const数组, 则其必须使用{}, 未指定值的元素一定会被置为0
            if (symbol_table.scope_stack.size() > 1)
            {
                // 局部变量, 未指定值置为0
                for (int i = cnt; i < array_size; i++)
                {
                    ir::Instruction* storeInst;
                    if (curr_type == ir::Type::FloatPtr)
                        storeInst = new ir::Instruction(ir::Operand(symbol_table.get_scoped_name(var_name),ir::Type::FloatPtr),
                            ir::Operand(std::to_string(i),ir::Type::IntLiteral),
                            ir::Operand("0.0",ir::Type::FloatLiteral),ir::Operator::store);
                    else if (curr_type == ir::Type::IntPtr)
                        storeInst = new ir::Instruction(ir::Operand(symbol_table.get_scoped_name(var_name),ir::Type::IntPtr),
                            ir::Operand(std::to_string(i),ir::Type::IntLiteral),
                            ir::Operand("0",ir::Type::IntLiteral),ir::Operator::store);
                    else
                        assert(0 && "Invalid Type");
                    result.push_back(storeInst);
                }
            }
        }
        else if (constdef->children.size() == 3) // 只是定义一个非数组
        {
            // 插入符号表
            STE var_ste;
            if (type == ir::Type::Int)
            {
                var_ste.operand = ir::Operand(var_name, ir::Type::IntLiteral);
                // Literal值的计算放在后面
            }
            else if (type == ir::Type::Float)
            {
                var_ste.operand = ir::Operand(var_name, ir::Type::FloatLiteral);
                // Literal值的计算放在后面
            }
            else
            {
                assert(0 && "Invalid Type");
            }
            symbol_table.scope_stack.back().table[var_name] = var_ste;
            // 调用def or fdef指令, 且完成赋值

            ConstInitVal* constinit = dynamic_cast<ConstInitVal*>(constdef->children.back());
            assert(constinit != nullptr);
            ConstExp* constexp = dynamic_cast<ConstExp*>(constinit->children[0]);
            assert(constexp != nullptr);
            // 计算值
            calculate_constexp(constexp);
            // 符号表中存放Literal值
            symbol_table.scope_stack.back().table[var_name].literalVal = constexp->v;

            // 常量不用生成定义指令？
            
            // if (type == ir::Type::Int)
            // {
            //     // 允许Float -> Int
            //     int val;
            //     if (constexp->t == ir::Type::FloatLiteral)
            //         val = std::stof(constexp->v);
            //     else if (constexp->t == ir::Type::IntLiteral)
            //         val = std::stoi(constexp->v);
            //     else
            //         assert(0 && "Invalid Type");
            //     ir::Instruction* defInst = new ir::Instruction(ir::Operand(std::to_string(val),ir::Type::IntLiteral),
            //                          ir::Operand(),
            //                          ir::Operand(symbol_table.get_scoped_name(var_name),ir::Type::Int),ir::Operator::def);
            //     result.push_back(defInst);
            // }
            // else if (type == ir::Type::Float)
            // {
            //     // 允许Int -> Float
            //     float val = std::stof(constexp->v);
            //     ir::Instruction* defInst = new ir::Instruction(ir::Operand(std::to_string(val),ir::Type::FloatLiteral),
            //                          ir::Operand(),
            //                          ir::Operand(symbol_table.get_scoped_name(var_name),ir::Type::Float),ir::Operator::fdef);
            //     result.push_back(defInst);
            // }
            // else
            // {
            //     assert(0 && "Invalid Type");
            // }
        }
    }
    return result;
}

vector<ir::Instruction *> frontend::Analyzer::analyze_vardecl(VarDecl* root)
{
    vector<ir::Instruction *> result;
    // 解析BType，并解析ConstDef
    auto btype = dynamic_cast<BType*>(root->children[0]);
    assert(btype != nullptr);
    auto btype_token = dynamic_cast<Term*>(btype->children[0]);
    assert(btype_token != nullptr);
    ir::Type type; // 仅限于int和float
    if (btype_token->token.type == TokenType::INTTK)
    {
        type = ir::Type::Int;
    }
    else if (btype_token->token.type == TokenType::FLOATTK)
    {
        type = ir::Type::Float;
    }
    else
    {
        assert(0 && "Invalid BType");
    }
    for (int i = 1; i < root->children.size(); i += 2)
    {
        // 解析vardef
        VarDef* vardef = dynamic_cast<VarDef*>(root->children[i]);
        assert(vardef != nullptr);
        // 确定变量名
        Term* ident_term = dynamic_cast<Term*>(vardef->children[0]);
        assert(ident_term->token.type == TokenType::IDENFR);
        string var_name = ident_term->token.value;
        // 判断是否是数组类型变量
        if (vardef->children.size() >= 4 && dynamic_cast<Term*>(vardef->children[1])->token.type == TokenType::LBRACK)
        {
            if (vardef->children.size() < 7)
            {
                // 1维数组
                ConstExp* constexp = dynamic_cast<ConstExp*>(vardef->children[2]);
                assert(constexp != nullptr);
                // 计算数组形状
                calculate_constexp(constexp);
                assert(constexp->t == ir::Type::IntLiteral);
                int array_size = std::stoi(constexp->v);
                // 插入符号表
                STE arr_ste;
                arr_ste.dimension.push_back(array_size);
                ir::Type curr_type = type;
                if (curr_type == ir::Type::Int)
                {
                    curr_type = ir::Type::IntPtr;
                }
                else if (curr_type == ir::Type::Float)
                {
                    curr_type = ir::Type::FloatPtr;
                }
                else
                {
                    assert(0 && "Invalid Type");
                }
                arr_ste.operand = ir::Operand(var_name, curr_type);
                symbol_table.scope_stack.back().table[var_name] = arr_ste;
                // 生成IR指令 (为全局数组时不用!!)
                if (symbol_table.scope_stack.size() > 1)
                {
                    ir::Instruction* allocInst = new ir::Instruction(ir::Operand(std::to_string(array_size),ir::Type::IntLiteral),
                                    ir::Operand(),
                                    ir::Operand(symbol_table.get_scoped_name(var_name),curr_type),ir::Operator::alloc);
                    result.push_back(allocInst);
                }
                // 判断有没有进行初始化
                if (InitVal* initval = dynamic_cast<InitVal*>(vardef->children.back()))
                {
                    // 需要进行初始化
                    // 一维数组的初始化，只能为{a,b,c...} ，从测试用例来看，二维的初始化，也为{a,b,c...}
                    // 从1、3、5开始初始化
                    int cnt = 0;
                    for (int i = 1; i < initval ->children.size()-1; i += 2, cnt += 1)
                    {
                        InitVal* child_initval = dynamic_cast<InitVal*>(initval->children[i]);
                        assert(child_initval != nullptr);
                        Exp* exp = dynamic_cast<Exp*>(child_initval->children[0]);
                        assert(exp != nullptr);
                        // 计算值
                        // 目前，测试用例中出现的，函数数组参数与数组初始化中，都是常量表达式
                        vector<Instruction *> cal_insts = calculate_exp(exp);
                        result.insert(result.end(),cal_insts.begin(),cal_insts.end());
                        if (curr_type == ir::Type::IntPtr)
                        {
                            // 允许类型隐式转化 Float -> Int
                            assert(exp->t == ir::Type::Float || exp->t == ir::Type::Int || exp->t == ir::Type::IntLiteral || exp->t == ir::Type::FloatLiteral);
                            if (exp->t == Type::IntLiteral || exp->t == Type::Int)
                            {
                                ir::Instruction* storeInst = new ir::Instruction(ir::Operand(symbol_table.get_scoped_name(var_name),ir::Type::IntPtr),
                                        ir::Operand(std::to_string(cnt),ir::Type::IntLiteral),
                                        ir::Operand(exp->v,exp->t),ir::Operator::store);
                                result.push_back(storeInst);
                            }
                            else
                            {
                                if (exp->t == Type::FloatLiteral)
                                {
                                    int val = std::stof(exp->v);
                                    ir::Instruction* storeInst = new ir::Instruction(ir::Operand(symbol_table.get_scoped_name(var_name),ir::Type::IntPtr),
                                            ir::Operand(std::to_string(cnt),ir::Type::IntLiteral),
                                            ir::Operand(std::to_string(val),Type::IntLiteral),ir::Operator::store);
                                    result.push_back(storeInst);
                                }
                                else
                                {
                                    string tmp_floatcvt_name = "t";
                                    tmp_floatcvt_name += std::to_string(tmp_cnt++);
                                    ir::Instruction* cvtInst = new ir::Instruction(ir::Operand(exp->v,ir::Type::Float),
                                            ir::Operand(),
                                            ir::Operand(tmp_floatcvt_name,ir::Type::Int),ir::Operator::cvt_f2i);
                                    ir::Instruction* storeInst = new ir::Instruction(ir::Operand(symbol_table.get_scoped_name(var_name),ir::Type::IntPtr),
                                            ir::Operand(std::to_string(cnt),ir::Type::IntLiteral),
                                            ir::Operand(tmp_floatcvt_name,Type::Int),ir::Operator::store);
                                    result.push_back(cvtInst);
                                    result.push_back(storeInst);
                                }
                            }
                        }
                        else if (curr_type == ir::Type::FloatPtr)
                        {
                            // 允许类型提升 Int --提升至--> Float
                            assert(exp->t == ir::Type::Float || exp->t == ir::Type::Int || exp->t == ir::Type::IntLiteral || exp->t == ir::Type::FloatLiteral);
                            if (exp->t == Type::IntLiteral || exp->t == Type::FloatLiteral)
                            {
                                float val = std::stof(exp->v);
                                ir::Instruction* storeInst = new ir::Instruction(ir::Operand(symbol_table.get_scoped_name(var_name),ir::Type::FloatPtr),
                                        ir::Operand(std::to_string(cnt),ir::Type::IntLiteral),
                                        ir::Operand(std::to_string(val),ir::Type::FloatLiteral),ir::Operator::store);
                                result.push_back(storeInst);               
                            }
                            else if (exp->t == Type::Int)
                            {
                                // 需类型转换
                                string tmp_intcvt_name = "t";
                                tmp_intcvt_name += std::to_string(tmp_cnt++);
                                ir::Instruction* cvtInst = new ir::Instruction(ir::Operand(exp->v,ir::Type::Int),
                                        ir::Operand(),
                                        ir::Operand(tmp_intcvt_name,ir::Type::Float),ir::Operator::cvt_i2f);
                                ir::Instruction* storeInst = new ir::Instruction(ir::Operand(symbol_table.get_scoped_name(var_name),ir::Type::FloatPtr),
                                        ir::Operand(std::to_string(cnt),ir::Type::IntLiteral),
                                        ir::Operand(tmp_intcvt_name,ir::Type::Float),ir::Operator::store);
                                result.push_back(cvtInst);
                                result.push_back(storeInst); 
                            }
                            else if (exp->t == Type::Float)
                            {
                                ir::Instruction* storeInst = new ir::Instruction(ir::Operand(symbol_table.get_scoped_name(var_name),ir::Type::FloatPtr),
                                        ir::Operand(std::to_string(cnt),ir::Type::IntLiteral),
                                        ir::Operand(exp->v,ir::Type::Float),ir::Operator::store);
                                result.push_back(storeInst);
                            }
                        }
                        else
                        {
                            assert(0 && "Invalid Calculate Type");
                        }
                    }
                    // 判断是否是全局数组的初始化，若为全局，则ir库会帮我自动将值初始化为0
                    // 局部变量初始化, 注意此处为Const数组, 则其必须使用{}, 未指定值的元素一定会被置为0
                    if (symbol_table.scope_stack.size() > 1) 
                    {
                        // 局部变量, 未指定值置为0
                        for (int i = cnt; i < array_size; i++) // 理论上，测试代码运行该循环时，cnt一定为0
                        {
                            ir::Instruction* storeInst;
                            if (curr_type == ir::Type::FloatPtr)
                                storeInst = new ir::Instruction(ir::Operand(symbol_table.get_scoped_name(var_name),ir::Type::FloatPtr),
                                    ir::Operand(std::to_string(i),ir::Type::IntLiteral),
                                    ir::Operand("0.0",ir::Type::FloatLiteral),ir::Operator::store);
                            else if (curr_type == ir::Type::IntPtr)
                                storeInst = new ir::Instruction(ir::Operand(symbol_table.get_scoped_name(var_name),ir::Type::IntPtr),
                                    ir::Operand(std::to_string(i),ir::Type::IntLiteral),
                                    ir::Operand("0",ir::Type::IntLiteral),ir::Operator::store);
                            else
                                assert(0 && "Invalid Type");
                            result.push_back(storeInst);
                        }
                    }
                }
            }
            else 
            {
                // 二维数组
                // 1. 计算数组形状
                ConstExp* constexp1 = dynamic_cast<ConstExp*>(vardef->children[2]);
                assert(constexp1 != nullptr);
                ConstExp* constexp2 = dynamic_cast<ConstExp*>(vardef->children[5]);
                assert(constexp2 != nullptr);
                // 计算数组形状
                calculate_constexp(constexp1);
                calculate_constexp(constexp2);
                assert(constexp1->t == ir::Type::IntLiteral && constexp2->t == ir::Type::IntLiteral);
                int array_dim1 = std::stoi(constexp1->v); // 第一维大小
                int array_dim2 = std::stoi(constexp2->v); // 第二维大小
                int array_size = array_dim1 * array_dim2;
                // 插入符号表
                STE arr_ste;
                arr_ste.dimension.push_back(array_dim1);
                arr_ste.dimension.push_back(array_dim2);
                ir::Type curr_type = type;
                if (curr_type == ir::Type::Int)
                {
                    curr_type = ir::Type::IntPtr;
                }
                else if (curr_type == ir::Type::Float)
                {
                    curr_type = ir::Type::FloatPtr;
                }
                else
                {
                    assert(0 && "Invalid Type");
                }
                arr_ste.operand = ir::Operand(var_name, curr_type);
                symbol_table.scope_stack.back().table[var_name] = arr_ste;
                // 生成IR指令 (为全局数组时不用!!)
                if (symbol_table.scope_stack.size() > 1)
                {
                    ir::Instruction* allocInst = new ir::Instruction(ir::Operand(std::to_string(array_size),ir::Type::IntLiteral),
                                    ir::Operand(),
                                    ir::Operand(symbol_table.get_scoped_name(var_name),curr_type),ir::Operator::alloc);
                    result.push_back(allocInst);
                }
                // 判断是否有进行初始化
                if (InitVal* initval = dynamic_cast<InitVal*>(vardef->children.back()))
                {
                    // 从测试用例来看，二维的初始化，也为{a,b,c...}
                    // 从1、3、5...开始初始化
                    int cnt = 0;
                    for (int i = 1; i < initval ->children.size()-1; i += 2, cnt += 1)
                    {
                        InitVal* child_initval = dynamic_cast<InitVal*>(initval->children[i]);
                        assert(child_initval != nullptr);
                        Exp* exp = dynamic_cast<Exp*>(child_initval->children[0]);
                        assert(exp != nullptr);
                        // 计算值
                        // 目前，测试用例中出现的，函数数组参数与数组初始化中，都是常量表达式
                        vector<Instruction *> cal_insts = calculate_exp(exp);
                        result.insert(result.end(),cal_insts.begin(),cal_insts.end());
                        if (curr_type == ir::Type::IntPtr)
                        {
                            // 允许类型隐式转化 Float -> Int
                            assert(exp->t == ir::Type::Float || exp->t == ir::Type::Int || exp->t == ir::Type::IntLiteral || exp->t == ir::Type::FloatLiteral);
                            if (exp->t == Type::IntLiteral || exp->t == Type::Int)
                            {
                                ir::Instruction* storeInst = new ir::Instruction(ir::Operand(symbol_table.get_scoped_name(var_name),ir::Type::IntPtr),
                                        ir::Operand(std::to_string(cnt),ir::Type::IntLiteral),
                                        ir::Operand(exp->v,exp->t),ir::Operator::store);
                                result.push_back(storeInst);
                            }
                            else
                            {
                                if (exp->t == Type::FloatLiteral)
                                {
                                    int val = std::stof(exp->v);
                                    ir::Instruction* storeInst = new ir::Instruction(ir::Operand(symbol_table.get_scoped_name(var_name),ir::Type::IntPtr),
                                            ir::Operand(std::to_string(cnt),ir::Type::IntLiteral),
                                            ir::Operand(std::to_string(val),Type::IntLiteral),ir::Operator::store);
                                    result.push_back(storeInst);
                                }
                                else
                                {
                                    string tmp_floatcvt_name = "t";
                                    tmp_floatcvt_name += std::to_string(tmp_cnt++);
                                    ir::Instruction* cvtInst = new ir::Instruction(ir::Operand(exp->v,ir::Type::Float),
                                            ir::Operand(),
                                            ir::Operand(tmp_floatcvt_name,ir::Type::Int),ir::Operator::cvt_f2i);
                                    ir::Instruction* storeInst = new ir::Instruction(ir::Operand(symbol_table.get_scoped_name(var_name),ir::Type::IntPtr),
                                            ir::Operand(std::to_string(cnt),ir::Type::IntLiteral),
                                            ir::Operand(tmp_floatcvt_name,Type::Int),ir::Operator::store);
                                    result.push_back(cvtInst);
                                    result.push_back(storeInst);
                                }
                            }
                        }
                        else if (curr_type == ir::Type::FloatPtr)
                        {
                            // 允许类型提升 Int --提升至--> Float
                            assert(exp->t == ir::Type::Float || exp->t == ir::Type::Int || exp->t == ir::Type::IntLiteral || exp->t == ir::Type::FloatLiteral);
                            if (exp->t == Type::IntLiteral || exp->t == Type::FloatLiteral)
                            {
                                float val = std::stof(exp->v);
                                ir::Instruction* storeInst = new ir::Instruction(ir::Operand(symbol_table.get_scoped_name(var_name),ir::Type::FloatPtr),
                                        ir::Operand(std::to_string(cnt),ir::Type::IntLiteral),
                                        ir::Operand(std::to_string(val),ir::Type::FloatLiteral),ir::Operator::store);
                                result.push_back(storeInst);               
                            }
                            else if (exp->t == Type::Int)
                            {
                                // 需类型转换
                                string tmp_intcvt_name = "t";
                                tmp_intcvt_name += std::to_string(tmp_cnt++);
                                ir::Instruction* cvtInst = new ir::Instruction(ir::Operand(exp->v,ir::Type::Int),
                                        ir::Operand(),
                                        ir::Operand(tmp_intcvt_name,ir::Type::Float),ir::Operator::cvt_i2f);
                                ir::Instruction* storeInst = new ir::Instruction(ir::Operand(symbol_table.get_scoped_name(var_name),ir::Type::FloatPtr),
                                        ir::Operand(std::to_string(cnt),ir::Type::IntLiteral),
                                        ir::Operand(tmp_intcvt_name,ir::Type::Float),ir::Operator::store);
                                result.push_back(cvtInst);
                                result.push_back(storeInst); 
                            }
                            else if (exp->t == Type::Float)
                            {
                                ir::Instruction* storeInst = new ir::Instruction(ir::Operand(symbol_table.get_scoped_name(var_name),ir::Type::FloatPtr),
                                        ir::Operand(std::to_string(cnt),ir::Type::IntLiteral),
                                        ir::Operand(exp->v,ir::Type::Float),ir::Operator::store);
                                result.push_back(storeInst);
                            }
                        }
                        else
                        {
                            assert(0 && "Invalid Calculate Type");
                        }
                    }
                    // 判断是否是全局数组的初始化，若为全局，则ir库会帮我自动将值初始化为0
                    // 局部变量初始化, 注意此处为Const数组, 则其必须使用{}, 未指定值的元素一定会被置为0
                    if (symbol_table.scope_stack.size() > 1) 
                    {
                        // 局部变量, 未指定值置为0
                        for (int i = cnt; i < array_size; i++) // 理论上，测试代码运行该循环时，cnt一定为0
                        {
                            ir::Instruction* storeInst;
                            if (curr_type == ir::Type::FloatPtr)
                                storeInst = new ir::Instruction(ir::Operand(symbol_table.get_scoped_name(var_name),ir::Type::FloatPtr),
                                    ir::Operand(std::to_string(i),ir::Type::IntLiteral),
                                    ir::Operand("0.0",ir::Type::FloatLiteral),ir::Operator::store);
                            else if (curr_type == ir::Type::IntPtr)
                                storeInst = new ir::Instruction(ir::Operand(symbol_table.get_scoped_name(var_name),ir::Type::IntPtr),
                                    ir::Operand(std::to_string(i),ir::Type::IntLiteral),
                                    ir::Operand("0",ir::Type::IntLiteral),ir::Operator::store);
                            else
                                assert(0 && "Invalid Type");
                            result.push_back(storeInst);
                        }
                    }
                }
            }
        }
        else // 定义的是一个普通变量 // 此处似乎必须支持计算InitVal了
        {
            // 插入符号表
            STE var_ste;
            var_ste.operand = ir::Operand(var_name, type);
            symbol_table.scope_stack.back().table[var_name] = var_ste;
            // 调用def or fdef指令, 且完成定义、赋值
            // 判断有没有初始化
            if (InitVal* initval = dynamic_cast<InitVal*>(vardef->children.back()))
            {   // 有初始化值
                Exp* exp = dynamic_cast<Exp*>(initval->children[0]);
                assert(exp);
                // 计算值
                vector<Instruction*> cal_insts = calculate_exp(exp);
                result.insert(result.end(),cal_insts.begin(),cal_insts.end());
                // 判断exp的类型: Int or IntLiteral or Float or FloatLiteral
                // 根据当前声明的type 判断类型提升
                if (type == ir::Type::Int)
                {
                    // 允许 Float -> Int
                    assert(exp->t == ir::Type::Int || exp->t == ir::Type::IntLiteral || exp->t == ir::Type::Float || exp->t == ir::Type::FloatLiteral);
                    if (exp->t == ir::Type::Int || exp->t == ir::Type::IntLiteral)
                    {
                        ir::Instruction* defInst = new ir::Instruction(ir::Operand(exp->v,exp->t),
                                            ir::Operand(),
                                            ir::Operand(symbol_table.get_scoped_name(var_name),ir::Type::Int),ir::Operator::def);
                        result.push_back(defInst);
                    }
                    else if (exp->t == ir::Type::Float || exp->t == ir::Type::FloatLiteral)
                    {
                        // 需类型转换
                        string tmp_intcvt_name = "t";
                        tmp_intcvt_name += std::to_string(tmp_cnt++);
                        if (exp->t == ir::Type::Float)
                        {
                            ir::Instruction* cvtInst = new ir::Instruction(ir::Operand(exp->v,ir::Type::Float),
                                                ir::Operand(),
                                                ir::Operand(tmp_intcvt_name,ir::Type::Int),ir::Operator::cvt_f2i);
                            ir::Instruction* defInst = new ir::Instruction(ir::Operand(tmp_intcvt_name,ir::Type::Int),
                                                ir::Operand(),
                                                ir::Operand(symbol_table.get_scoped_name(var_name),ir::Type::Int),ir::Operator::def);
                            result.push_back(cvtInst);
                            result.push_back(defInst);
                        }
                        else
                        {
                            int val = std::stof(exp->v);
                            ir::Instruction* defInst = new ir::Instruction(ir::Operand(std::to_string(val),ir::Type::IntLiteral),
                                                ir::Operand(),
                                                ir::Operand(symbol_table.get_scoped_name(var_name),ir::Type::Int),ir::Operator::def);
                            result.push_back(defInst);
                        }
                    }
                    else
                    {
                        assert(0 && "Invalid Type");
                    }
                }
                else // 允许 Int -> Float
                {
                    // 判断是变量还是常量
                    if (exp->t == ir::Type::IntLiteral || exp->t == ir::Type::FloatLiteral)
                    {
                        float val = std::stof(exp->v);
                        ir::Instruction* defInst = new ir::Instruction(ir::Operand(std::to_string(val),ir::Type::FloatLiteral),
                                            ir::Operand(),
                                            ir::Operand(symbol_table.get_scoped_name(var_name),ir::Type::Float),ir::Operator::fdef);
                        result.push_back(defInst);
                    }
                    else if (exp->t == ir::Type::Int)
                    {
                        // 为了支持类型提升，需要将int转换为float
                        string curr_tmp_name = "t";
                        curr_tmp_name += std::to_string(tmp_cnt++);
                        ir::Instruction* cvtInst = new ir::Instruction(ir::Operand(exp->v,ir::Type::Int),
                                            ir::Operand(),
                                            ir::Operand(curr_tmp_name,ir::Type::Float),ir::Operator::cvt_i2f);                        
                        ir::Instruction* defInst = new ir::Instruction(ir::Operand(curr_tmp_name,ir::Type::Float),
                                            ir::Operand(),
                                            ir::Operand(symbol_table.get_scoped_name(var_name),ir::Type::Float),ir::Operator::fdef);
                        result.push_back(cvtInst);
                        result.push_back(defInst);
                    }
                    else if (exp->t == ir::Type::Float)
                    {
                        ir::Instruction* defInst = new ir::Instruction(ir::Operand(exp->v,ir::Type::Float),
                                            ir::Operand(),
                                            ir::Operand(symbol_table.get_scoped_name(var_name),ir::Type::Float),ir::Operator::fdef);
                        result.push_back(defInst);
                    }
                    else
                        assert(0 && "Invalid Type");
                }
            }
            else
            { // 没有初始化值，无论是局部还是全局，都初始化为0
                if (type == ir::Type::Int)
                {
                    ir::Instruction* defInst = new ir::Instruction(ir::Operand("0",ir::Type::IntLiteral),
                                        ir::Operand(),
                                        ir::Operand(symbol_table.get_scoped_name(var_name),ir::Type::Int),ir::Operator::def);
                    result.push_back(defInst);
                }
                else if (type == ir::Type::Float)
                {
                    ir::Instruction* defInst = new ir::Instruction(ir::Operand("0.0",ir::Type::FloatLiteral),
                                        ir::Operand(),
                                        ir::Operand(symbol_table.get_scoped_name(var_name),ir::Type::Float),ir::Operator::fdef);
                    result.push_back(defInst);
                }
                else
                {
                    assert(0 && "Invalid Type");
                }
            }
        }
    }
    return result;
}

ir::Type frontend::Analyzer::analyze_functype(FuncType *root)
{
    Term *term = dynamic_cast<Term *>(root->children[0]);
    // 读取Terminal中的关键字，转换为ir中的Type类型
    if (term->token.type == TokenType::VOIDTK)
    {
        return ir::Type::null;
    }
    else if (term->token.type == TokenType::INTTK)
    {
        return ir::Type::Int;
    }
    else if (term->token.type == TokenType::FLOATTK)
    {
        return ir::Type::Float;
    }
    else
    {
        assert(0 && "Invalid FuncType");
    }
}

string frontend::Analyzer::analyze_ident(Term *root)
{
    assert(root->token.type == TokenType::IDENFR);
    return root->token.value;
}

vector<ir::Operand> frontend::Analyzer::analyze_funcfparams(FuncFParams *root)
{
    vector<ir::Operand> func_params;
    for (int i = 0; i < root->children.size(); i += 2)
    {
        FuncFParam *funcfparam = dynamic_cast<FuncFParam *>(root->children[i]);
        assert(funcfparam != nullptr);
        // BType
        ir::Type param_type = analyze_btype(dynamic_cast<BType *>(funcfparam->children[0]));
        // Ident
        string param_name = analyze_ident(dynamic_cast<Term *>(funcfparam->children[1]));

        vector<int> dimension(1, -1); // [-1,]
        // 数组指针判断[]
        if (funcfparam->children.size() > 2)
        {
            // 修改param_type为指针
            if (param_type == ir::Type::Int)
            {
                param_type = ir::Type::IntPtr;
            }
            else if (param_type == ir::Type::Float)
            {
                param_type = ir::Type::FloatPtr;
            }
            else
            {
                assert(0 && "Invalid FuncFParam");
            }

            // 判断Dimensions(数组的形状) 注意利用文法的简化: 最多只有二维数组
            if (funcfparam->children.size() == 7)
            {
                // 二维数组, 需计算Exp的值 (children中下标为6)
                Exp *exp = dynamic_cast<Exp *>(funcfparam->children[6]);
                // Calculate Shit Here
                vector<Instruction*> cal_insts = calculate_exp(exp);
                assert(cal_insts.size() == 0);
                if (exp->t != Type::IntLiteral)
                    assert(0 && "ConstExp In Array Decl Must Be IntLiteral");
                int exp_result = std::stoi(exp->v);
                // push back to dimension
                dimension.push_back(exp_result);
            }
            else if (funcfparam->children.size() == 4)
            {
                // 一维数组, 无需计算
            }
            else
            {
                assert(0 && "Invalid FuncFParam");
            }
        }

        // 构造Operand
        ir::Operand param(param_name, param_type);

        // 加入到当前作用域,为接下来函数体的分析做准备
        symbol_table.scope_stack.back().table[param_name] = {param, dimension};
        std::cout << toString(param.type) << std::endl;
        // 函数参数重命名
        func_params.push_back({symbol_table.get_scoped_name(param.name),param.type});
    }
    return func_params;
}

ir::Type frontend::Analyzer::analyze_btype(BType *root)
{
    Term *term = dynamic_cast<Term *>(root->children[0]);
    assert(term != nullptr);
    if (term->token.type == TokenType::INTTK)
    {
        return ir::Type::Int;
    }
    else if (term->token.type == TokenType::FLOATTK)
    {
        return ir::Type::Float;
    }
    else
    {
        assert(0 && "Invalid BType");
    }
}

void frontend::Analyzer::analyze_funcdef(FuncDef *root)
{
    // 1. 分析函数返回值类型
    ir::Type func_type = analyze_functype(dynamic_cast<FuncType *>(root->children[0]));
    // 2. 分析函数名
    string func_name = analyze_ident(dynamic_cast<Term *>(root->children[1]));
    // 3. 分析函数参数 (可选, 因为函数可以没有参数)

    // 进入新作用域 (函数参数默认在函数的作用域中)
    symbol_table.add_scope();
    vector<ir::Operand> func_params;
    bool has_param = true;
    if (dynamic_cast<Term *>(root->children[3]) != nullptr)
    {
        has_param = false;
    }
    if (has_param)
    {
        func_params = analyze_funcfparams(dynamic_cast<FuncFParams *>(root->children[3]));
    }
    // 4. 构造函数
    ir::Function *func = new ir::Function(func_name, func_params, func_type);
    // 如果函数为main函数，则在其中增加全局函数调用
    if (func_name == "main")
    {
        ir::CallInst *callGlobal = new ir::CallInst(ir::Operand("global", ir::Type::null),
                                                    ir::Operand("t"+std::to_string(tmp_cnt++), ir::Type::null));
        func->addInst(callGlobal);
    }
    // 加入符号表中
    symbol_table.functions[func_name] = func;
    // 5. 分析函数体
    curr_function = func;
    vector<ir::Instruction *> func_body = analyze_block(dynamic_cast<Block *>(root->children.back()), true);

    // 函数作用域结束
    symbol_table.exit_scope();

    // 填充编译出的函数体
    for (auto inst : func_body)
    {
        func->addInst(inst);
    }

    // PC执行越界PATCH:如果是main函数, 则加一条return 0
    if (func_name == "main")
    {
        Instruction *retInst = new ir::Instruction(ir::Operand("0",ir::Type::IntLiteral),
                                                ir::Operand(),
                                                ir::Operand(),ir::Operator::_return);
        func->addInst(retInst);
    } 

    // VOID函数不需要return (语法上), 但在IR程序中, 必须添加return null指令
    if (func_type == ir::Type::null)
    {
        Instruction *retInst = new ir::Instruction(ir::Operand(),
                                                ir::Operand(),
                                                ir::Operand(),ir::Operator::_return);
        func->addInst(retInst);
    }

    // 6. 将函数加入到IR程序中
    ir_program.addFunction(*func);
}

vector<ir::Instruction *> frontend::Analyzer::analyze_block(Block *root, bool is_func_block)
{
    if (!is_func_block)
        symbol_table.add_scope();

    // 将所有BlockItem生成出的IR合成为一段
    vector<ir::Instruction *> block_body;
    for (int i = 1; i < int(root->children.size()) - 1; i++)
    {
        BlockItem *blockitem = dynamic_cast<BlockItem *>(root->children[i]);
        assert(blockitem != nullptr);
        vector<ir::Instruction *> blockitem_body = analyze_blockitem(blockitem);
        block_body.insert(block_body.end(), blockitem_body.begin(), blockitem_body.end());
    }

    if (!is_func_block)
        symbol_table.exit_scope();
    return block_body;
}

vector<ir::Instruction *> frontend::Analyzer::analyze_blockitem(BlockItem *root)
{
    if (dynamic_cast<Decl *>(root->children[0]) != nullptr)
    {
        return analyze_decl(dynamic_cast<Decl *>(root->children[0]));
    }
    else if (dynamic_cast<Stmt *>(root->children[0]) != nullptr)
    {
        return analyze_stmt(dynamic_cast<Stmt *>(root->children[0]));
    }
    else
    {
        assert(0 && "Invalid BlockItem");
    }
}

vector<ir::Instruction *> frontend::Analyzer::analyze_stmt(Stmt* root)
{
    vector<ir::Instruction *> result;
    // LVal分支
    if (LVal* lval = dynamic_cast<LVal*>(root->children[0]))
    {
        // 生成赋值IR指令

        // 计算Exp的值
        Exp* exp = dynamic_cast<Exp*>(root->children[2]);
        assert(exp);
        vector<ir::Instruction *> cal_insts = calculate_exp(exp);
        result.insert(result.end(),cal_insts.begin(),cal_insts.end());
        // 根据LVal的类型与Exp结果类型 生成赋值指令
        // 获取变量名
        string var_name = analyze_ident(dynamic_cast<Term*>(lval->children[0]));
        STE ident_ste = symbol_table.get_ste(var_name);
        if (lval->children.size() == 1) // Int or Float变量赋值
        {
            if (ident_ste.operand.type == Type::Int)
            {
                // Float or Int -> Int
                if (exp->t == Type::Int)
                {
                    ir::Instruction* movInst = new ir::Instruction(ir::Operand(exp->v,ir::Type::Int),
                                        ir::Operand(),
                                        ir::Operand(symbol_table.get_scoped_name(var_name),ir::Type::Int),ir::Operator::mov);
                    result.push_back(movInst);
                }
                else if (exp->t == Type::IntLiteral)
                {
                    ir::Instruction* movInst = new ir::Instruction(ir::Operand(exp->v,ir::Type::IntLiteral),
                                        ir::Operand(),
                                        ir::Operand(symbol_table.get_scoped_name(var_name),ir::Type::Int),ir::Operator::mov);
                    result.push_back(movInst);
                }
                else if (exp->t == Type::Float)
                {
                    ir::Instruction* f2iInst = new ir::Instruction(ir::Operand(exp->v,ir::Type::Float),
                                        ir::Operand(),
                                        ir::Operand(symbol_table.get_scoped_name(var_name),ir::Type::Int),ir::Operator::cvt_f2i);
                    result.push_back(f2iInst);
                }
                else if (exp->t == Type::FloatLiteral)
                {
                    int val = std::stof(exp->v);
                    ir::Instruction* movInst = new ir::Instruction(ir::Operand(std::to_string(val),ir::Type::IntLiteral),
                                        ir::Operand(),
                                        ir::Operand(symbol_table.get_scoped_name(var_name),ir::Type::Int),ir::Operator::mov);
                    result.push_back(movInst);
                }
            }
            else if (ident_ste.operand.type == Type::Float)
            {
                if (exp->t == Type::Int)
                {
                    ir::Instruction* i2fInst = new ir::Instruction(ir::Operand(exp->v,ir::Type::Int),
                                        ir::Operand(),
                                        ir::Operand(symbol_table.get_scoped_name(var_name),ir::Type::Float),ir::Operator::cvt_i2f);
                    result.push_back(i2fInst);
                }
                else if (exp->t == Type::IntLiteral)
                {
                    float val = std::stoi(exp->v);
                    ir::Instruction* movInst = new ir::Instruction(ir::Operand(std::to_string(val),ir::Type::FloatLiteral),
                                        ir::Operand(),
                                        ir::Operand(symbol_table.get_scoped_name(var_name),ir::Type::Float),ir::Operator::fmov);
                    result.push_back(movInst);
                }
                else if (exp->t == Type::Float)
                {
                    ir::Instruction* movInst = new ir::Instruction(ir::Operand(exp->v,ir::Type::Float),
                                        ir::Operand(),
                                        ir::Operand(symbol_table.get_scoped_name(var_name),ir::Type::Float),ir::Operator::fmov);
                    result.push_back(movInst);
                }
                else if (exp->t == Type::FloatLiteral)
                {
                    ir::Instruction* movInst = new ir::Instruction(ir::Operand(exp->v,ir::Type::FloatLiteral),
                                        ir::Operand(),
                                        ir::Operand(symbol_table.get_scoped_name(var_name),ir::Type::Float),ir::Operator::fmov);
                    result.push_back(movInst);
                }
            }
            else
                assert(0 && "Error Type");
        }
        else if (lval->children.size() == 4) // 一维数组赋值, 禁止指针赋值 (不存在)
        {
            assert(ident_ste.dimension.size() == 1);
            // 计算偏移量
            Exp* offset_exp = dynamic_cast<Exp*>(lval->children[2]);
            assert(offset_exp);
            vector<ir::Instruction *> cal_insts = calculate_exp(offset_exp);
            assert(offset_exp->t == Type::Int || offset_exp->t == Type::IntLiteral);
            result.insert(result.end(),cal_insts.begin(),cal_insts.end());
            // Int or Float变量赋值
            if (ident_ste.operand.type == Type::IntPtr)
            {
                // Float or Int -> Int
                if (exp->t == Type::Int || exp->t == Type::IntLiteral)
                {
                    ir::Instruction* storeInst = new ir::Instruction(ir::Operand(symbol_table.get_scoped_name(var_name),ir::Type::IntPtr),
                                        ir::Operand(offset_exp->v,offset_exp->t),
                                        ir::Operand(exp->v,exp->t),ir::Operator::store);
                    result.push_back(storeInst);
                }
                else if (exp->t == Type::Float)
                {
                    string tmp_float_to_int_name = "t";
                    tmp_float_to_int_name += std::to_string(tmp_cnt++);
                    ir::Instruction* f2iInst = new ir::Instruction(ir::Operand(exp->v,ir::Type::Float),
                                        ir::Operand(),
                                        ir::Operand(tmp_float_to_int_name,ir::Type::Int),ir::Operator::cvt_f2i);
                    ir::Instruction* storeInst = new ir::Instruction(ir::Operand(symbol_table.get_scoped_name(var_name),ir::Type::IntPtr),
                                        ir::Operand(offset_exp->v,offset_exp->t),
                                        ir::Operand(tmp_float_to_int_name,Type::Int),ir::Operator::store);
                    result.push_back(f2iInst);
                    result.push_back(storeInst);
                }
                else if (exp->t == Type::FloatLiteral)
                {
                    int val = std::stof(exp->v);
                    ir::Instruction* storeInst = new ir::Instruction(ir::Operand(symbol_table.get_scoped_name(var_name),ir::Type::IntPtr),
                                        ir::Operand(offset_exp->v,offset_exp->t),
                                        ir::Operand(std::to_string(val),Type::IntLiteral),ir::Operator::store);
                    result.push_back(storeInst);
                }
            }
            else if (ident_ste.operand.type == Type::FloatPtr)
            {
                if (exp->t == Type::Int)
                {
                    string tmp_int_to_float_name = "t";
                    tmp_int_to_float_name += std::to_string(tmp_cnt++);
                    ir::Instruction* i2fInst = new ir::Instruction(ir::Operand(exp->v,ir::Type::Int),
                                        ir::Operand(),
                                        ir::Operand(tmp_int_to_float_name,ir::Type::Float),ir::Operator::cvt_i2f);
                    ir::Instruction* storeInst = new ir::Instruction(ir::Operand(symbol_table.get_scoped_name(var_name),ir::Type::FloatPtr),
                                        ir::Operand(offset_exp->v,offset_exp->t),
                                        ir::Operand(tmp_int_to_float_name,Type::Float),ir::Operator::store);
                    result.push_back(i2fInst);
                    result.push_back(storeInst);
                }
                else if (exp->t == Type::IntLiteral)
                {
                    float val = std::stoi(exp->v);
                    ir::Instruction* storeInst = new ir::Instruction(ir::Operand(symbol_table.get_scoped_name(var_name),ir::Type::FloatPtr),
                                        ir::Operand(offset_exp->v,offset_exp->t),
                                        ir::Operand(std::to_string(val),Type::FloatLiteral),ir::Operator::store);
                    result.push_back(storeInst);
                }
                else if (exp->t == Type::Float || exp->t == Type::FloatLiteral)
                {
                    ir::Instruction* storeInst = new ir::Instruction(ir::Operand(symbol_table.get_scoped_name(var_name),ir::Type::FloatPtr),
                                        ir::Operand(offset_exp->v,offset_exp->t),
                                        ir::Operand(exp->v,exp->t),ir::Operator::store);
                    result.push_back(storeInst);
                }
            }
            else
                assert(0 && "Error Type");
        }
        else if (lval->children.size() == 7) // 二维数组赋值
        {
            assert(ident_ste.dimension.size() == 2);
            // 计算偏移量
            Exp* dim1_exp = dynamic_cast<Exp*>(lval->children[2]);
            assert(dim1_exp);
            vector<ir::Instruction *> cal1_insts = calculate_exp(dim1_exp);
            assert(dim1_exp->t == Type::Int || dim1_exp->t == Type::IntLiteral);
            result.insert(result.end(),cal1_insts.begin(),cal1_insts.end());
            Exp* dim2_exp = dynamic_cast<Exp*>(lval->children[5]);
            assert(dim2_exp);
            vector<ir::Instruction *> cal2_insts = calculate_exp(dim2_exp);
            assert(dim2_exp->t == Type::Int || dim2_exp->t == Type::IntLiteral);
            result.insert(result.end(),cal2_insts.begin(),cal2_insts.end());
            // 为了从二维数组中取值, 需计算偏移
            // 为了简单实现, 此处可先直接将两个exp1和exp2计算的结果都放入临时变量中
            string tmp_dim1_name = "t";
            tmp_dim1_name += std::to_string(tmp_cnt++);
            string tmp_dim2_name = "t";
            tmp_dim2_name += std::to_string(tmp_cnt++);
            Instruction *def1Inst = new ir::Instruction(ir::Operand(dim1_exp->v, dim1_exp->t),
                                                        ir::Operand(),
                                                        ir::Operand(tmp_dim1_name, Type::Int), ir::Operator::def);
            Instruction *def2Inst = new ir::Instruction(ir::Operand(dim2_exp->v, dim2_exp->t),
                                                        ir::Operand(),
                                                        ir::Operand(tmp_dim2_name, Type::Int), ir::Operator::def);
            string tmp_col_len_name = "t";
            tmp_col_len_name += std::to_string(tmp_cnt++);
            Instruction *def3Inst = new ir::Instruction(ir::Operand(std::to_string(ident_ste.dimension[1]), Type::IntLiteral),
                                                        ir::Operand(),
                                                        ir::Operand(tmp_col_len_name, Type::Int), ir::Operator::def);
            string tmp_lineoffset_name = "t";
            tmp_lineoffset_name += std::to_string(tmp_cnt++);
            // 计算行偏移
            Instruction *mulOffsetInst = new ir::Instruction(ir::Operand(tmp_dim1_name, Type::Int),
                                                            ir::Operand(tmp_col_len_name, Type::Int),
                                                            ir::Operand(tmp_lineoffset_name, Type::Int), ir::Operator::mul);
            // 计算总偏移
            string tmp_totaloffset_name = "t";
            tmp_totaloffset_name += std::to_string(tmp_cnt++);
            Instruction *addOffsetInst = new ir::Instruction(ir::Operand(tmp_lineoffset_name, Type::Int),
                                                            ir::Operand(tmp_dim2_name, Type::Int),
                                                            ir::Operand(tmp_totaloffset_name, Type::Int), ir::Operator::add);
            result.push_back(def1Inst);
            result.push_back(def2Inst);
            result.push_back(def3Inst);
            result.push_back(mulOffsetInst);
            result.push_back(addOffsetInst);
            // Int or Float变量赋值
            if (ident_ste.operand.type == Type::IntPtr)
            {
                // Float or Int -> Int
                if (exp->t == Type::Int || exp->t == Type::IntLiteral)
                {
                    ir::Instruction* storeInst = new ir::Instruction(ir::Operand(symbol_table.get_scoped_name(var_name),ir::Type::IntPtr),
                                        ir::Operand(tmp_totaloffset_name,Type::Int),
                                        ir::Operand(exp->v,exp->t),ir::Operator::store);
                    result.push_back(storeInst);
                }
                else if (exp->t == Type::Float)
                {
                    string tmp_float_to_int_name = "t";
                    tmp_float_to_int_name += std::to_string(tmp_cnt++);
                    ir::Instruction* f2iInst = new ir::Instruction(ir::Operand(exp->v,ir::Type::Float),
                                        ir::Operand(),
                                        ir::Operand(tmp_float_to_int_name,ir::Type::Int),ir::Operator::cvt_f2i);
                    ir::Instruction* storeInst = new ir::Instruction(ir::Operand(symbol_table.get_scoped_name(var_name),ir::Type::IntPtr),
                                        ir::Operand(tmp_totaloffset_name,Type::Int),
                                        ir::Operand(tmp_float_to_int_name,Type::Int),ir::Operator::store);
                    result.push_back(f2iInst);
                    result.push_back(storeInst);
                }
                else if (exp->t == Type::FloatLiteral)
                {
                    int val = std::stof(exp->v);
                    ir::Instruction* storeInst = new ir::Instruction(ir::Operand(symbol_table.get_scoped_name(var_name),ir::Type::IntPtr),
                                        ir::Operand(tmp_totaloffset_name,Type::Int),
                                        ir::Operand(std::to_string(val),Type::IntLiteral),ir::Operator::store);
                    result.push_back(storeInst);
                }
            }
            else if (ident_ste.operand.type == Type::FloatPtr)
            {
                if (exp->t == Type::Int)
                {
                    string tmp_int_to_float_name = "t";
                    tmp_int_to_float_name += std::to_string(tmp_cnt++);
                    ir::Instruction* i2fInst = new ir::Instruction(ir::Operand(exp->v,ir::Type::Int),
                                        ir::Operand(),
                                        ir::Operand(tmp_int_to_float_name,ir::Type::Float),ir::Operator::cvt_i2f);
                    ir::Instruction* storeInst = new ir::Instruction(ir::Operand(symbol_table.get_scoped_name(var_name),ir::Type::FloatPtr),
                                        ir::Operand(tmp_totaloffset_name,Type::Int),
                                        ir::Operand(tmp_int_to_float_name,Type::Float),ir::Operator::store);
                    result.push_back(i2fInst);
                    result.push_back(storeInst);
                }
                else if (exp->t == Type::IntLiteral)
                {
                    float val = std::stoi(exp->v);
                    ir::Instruction* storeInst = new ir::Instruction(ir::Operand(symbol_table.get_scoped_name(var_name),ir::Type::FloatPtr),
                                        ir::Operand(tmp_totaloffset_name,Type::Int),
                                        ir::Operand(std::to_string(val),Type::FloatLiteral),ir::Operator::store);
                    result.push_back(storeInst);
                }
                else if (exp->t == Type::Float || exp->t == Type::FloatLiteral)
                {
                    ir::Instruction* storeInst = new ir::Instruction(ir::Operand(symbol_table.get_scoped_name(var_name),ir::Type::FloatPtr),
                                        ir::Operand(tmp_totaloffset_name,Type::Int),
                                        ir::Operand(exp->v,exp->t),ir::Operator::store);
                    result.push_back(storeInst);
                }
            }
            else
                assert(0 && "Error Type");
        }
        return result;
    }
    // Block分支
    if (Block* block = dynamic_cast<Block*>(root->children[0]))
    {
        return analyze_block(block,false);
    }
    Term* term = dynamic_cast<Term*>(root->children[0]);
    // [Exp] ';'
    if (term == nullptr)
    {
        Exp* exp = dynamic_cast<Exp*>(root->children[0]);
        assert(exp);
        return calculate_exp(exp);
    }
    if (term->token.type == TokenType::SEMICN)
        return result;
    // 'return' [Exp] ';'
    if (term->token.type == TokenType::RETURNTK)
    {
        // [Exp]
        if (root->children.size() == 3)
        {
            Exp* exp = dynamic_cast<Exp*>(root->children[1]);
            assert(exp);
            vector<ir::Instruction*> exp_insts = calculate_exp(exp);
            result.insert(result.end(),exp_insts.begin(),exp_insts.end());
            // 根据函数返回类型进行返回
            if (curr_function->returnType == Type::Int)
            {
                // Int or IntLiteral
                if (exp->t == Type::Int || exp->t == Type::IntLiteral)
                {
                    ir::Instruction* retInst = new ir::Instruction(ir::Operand(exp->v,exp->t),
                                            ir::Operand(),
                                            ir::Operand(),ir::Operator::_return);
                    result.push_back(retInst);
                }
                // Float or FloatLiteral
                else if (exp->t == Type::FloatLiteral)
                {
                    int val = std::stof(exp->v);
                    ir::Instruction* retInst = new ir::Instruction(ir::Operand(std::to_string(val),Type::IntLiteral),
                                            ir::Operand(),
                                            ir::Operand(),ir::Operator::_return);
                    result.push_back(retInst);
                }
                else if (exp->t == Type::Float)
                {
                    string tmp_float_to_int_name = "t";
                    tmp_float_to_int_name += std::to_string(tmp_cnt++);
                    ir::Instruction* cvtInst = new ir::Instruction(ir::Operand(exp->v,Type::Float),
                                            ir::Operand(),
                                            ir::Operand(tmp_float_to_int_name,Type::Int),ir::Operator::cvt_f2i);
                    ir::Instruction* retInst = new ir::Instruction(ir::Operand(tmp_float_to_int_name,Type::Int),
                                            ir::Operand(),
                                            ir::Operand(),ir::Operator::_return);
                    result.push_back(cvtInst);
                    result.push_back(retInst);
                }
                else
                    assert(0 && "Error Type");
            }
            else if (curr_function->returnType == Type::Float)
            {
                // Float or FloatLiteral
                if (exp->t == Type::Float || exp->t == Type::FloatLiteral)
                {
                    ir::Instruction* retInst = new ir::Instruction(ir::Operand(exp->v,exp->t),
                                            ir::Operand(),
                                            ir::Operand(),ir::Operator::_return);
                    result.push_back(retInst);
                }
                // Int or IntLiteral
                else if (exp->t == Type::IntLiteral)
                {
                    float val = std::stoi(exp->v);
                    ir::Instruction* retInst = new ir::Instruction(ir::Operand(std::to_string(val),Type::FloatLiteral),
                                            ir::Operand(),
                                            ir::Operand(),ir::Operator::_return);
                    result.push_back(retInst);
                }
                else if (exp->t == Type::Int)
                {
                    string tmp_int_to_float_name = "t";
                    tmp_int_to_float_name += std::to_string(tmp_cnt++);
                    ir::Instruction* cvtInst = new ir::Instruction(ir::Operand(exp->v,Type::Int),
                                            ir::Operand(),
                                            ir::Operand(tmp_int_to_float_name,Type::Float),ir::Operator::cvt_i2f);
                    ir::Instruction* retInst = new ir::Instruction(ir::Operand(tmp_int_to_float_name,Type::Float),
                                            ir::Operand(),
                                            ir::Operand(),ir::Operator::_return);
                    result.push_back(cvtInst);
                    result.push_back(retInst);
                }
                else
                    assert(0 && "Error Type");
            }
            else
                assert(0 && "Invalid Return Type");
        }
        // ;
        else
        {
            ir::Instruction* retInst = new ir::Instruction(ir::Operand(),
                                        ir::Operand(),
                                        ir::Operand(),ir::Operator::_return);
            result.push_back(retInst);
        }
        return result;
    }
    // 'if' '(' Cond ')' Stmt [ 'else' Stmt ]
    if (term->token.type == TokenType::IFTK)
    {
        // 判断Cond的值
        Cond* cond = dynamic_cast<Cond*>(root->children[2]);
        assert(cond);
        vector<ir::Instruction*> cal_insts = calculate_cond(cond);
        // 若Cond为Float或FloatLiteral则需转换为Int或IntLiteral (IR机的GOTO是否实现有误？只支持整数？)
        if (cond->t == Type::Float || cond->t == Type::FloatLiteral)
        {
            if (cond->t == Type::FloatLiteral)
            {
                float val = std::stof(cond->v);
                cond->v = std::to_string(val != 0);
                cond->t = Type::IntLiteral;
            }
            else
            {
                string tmp1_name = "t";
                tmp1_name += std::to_string(tmp_cnt++);
                ir::Instruction* cvt1Inst = new ir::Instruction(ir::Operand(cond->v,Type::Float),
                                        ir::Operand("0.0",Type::FloatLiteral),
                                        ir::Operand(tmp1_name,Type::Float),ir::Operator::fneq);
                string tmp2_name = "t";
                tmp2_name += std::to_string(tmp_cnt++);
                ir::Instruction* cvt2Inst = new ir::Instruction(ir::Operand(tmp1_name,Type::Float),
                                        ir::Operand(),
                                        ir::Operand(tmp2_name,Type::Int),ir::Operator::cvt_f2i);
                cal_insts.push_back(cvt1Inst);
                cal_insts.push_back(cvt2Inst);
                cond->v = tmp2_name;
                cond->t = Type::Int;
            }
        }
        result.insert(result.end(),cal_insts.begin(),cal_insts.end());
        // 生成跳转指令

        // if情况的跳转
        ir::Instruction* goto_if_Inst = new ir::Instruction(ir::Operand(cond->v,cond->t),
                                            ir::Operand(),
                                            ir::Operand("2",Type::IntLiteral),ir::Operator::_goto);
        result.push_back(goto_if_Inst);

        symbol_table.add_scope();
        // 先分析if后的stmt
        vector<ir::Instruction *> stmt_after_if_insts = analyze_stmt(dynamic_cast<Stmt*>(root->children[4]));
        symbol_table.exit_scope();

        // 判断有没有else
        if (root->children.size() == 7)
        {   // 有else

            symbol_table.add_scope();
            // 先分析else后的stmt
            vector<ir::Instruction *> stmt_after_else_insts = analyze_stmt(dynamic_cast<Stmt*>(root->children[6]));
            symbol_table.exit_scope();

            // if情况执行完毕的跳转(跳过整个else)
            ir::Instruction* goto_if_last_Inst = new ir::Instruction(ir::Operand(),
                                                ir::Operand(),
                                                ir::Operand(std::to_string(stmt_after_else_insts.size()+1),Type::IntLiteral),ir::Operator::_goto);
            stmt_after_if_insts.push_back(goto_if_last_Inst);

            // else情况的跳转(跳转到else后的Stmt)
            ir::Instruction* goto_else_Inst = new ir::Instruction(ir::Operand(),
                                                ir::Operand(),
                                                ir::Operand(std::to_string(stmt_after_if_insts.size()+1),Type::IntLiteral),ir::Operator::_goto);
            result.push_back(goto_else_Inst);
            // 合并if后Stmt
            result.insert(result.end(),stmt_after_if_insts.begin(),stmt_after_if_insts.end());
            // 合并else后Stmt
            result.insert(result.end(),stmt_after_else_insts.begin(),stmt_after_else_insts.end());
            // 增加unuse
            Instruction* unuse_Inst = new ir::Instruction(ir::Operand(),
                                                          ir::Operand(),
                                                          ir::Operand(),ir::Operator::__unuse__);
            result.push_back(unuse_Inst);
        }
        else
        {   // 没有else
            // 非if情况的跳转
            ir::Instruction* goto_else_Inst = new ir::Instruction(ir::Operand(),
                                                ir::Operand(),
                                                ir::Operand(std::to_string(stmt_after_if_insts.size()+1),Type::IntLiteral),ir::Operator::_goto);
            result.push_back(goto_else_Inst);
            // 合并if后的stmt
            result.insert(result.end(),stmt_after_if_insts.begin(),stmt_after_if_insts.end());
            // 增加unuse
            Instruction* unuse_Inst = new ir::Instruction(ir::Operand(),
                                                          ir::Operand(),
                                                          ir::Operand(),ir::Operator::__unuse__);
            result.push_back(unuse_Inst);
        }
        return result;
    }
    // 'while' '(' Cond ')' Stmt | 'break' ';' | 'continue' ';'
    if (term->token.type == TokenType::WHILETK)
    {
        // 分析出计算Cond值的指令
        Cond* cond = dynamic_cast<Cond*>(root->children[2]);
        assert(cond);
        vector<Instruction *> cal_insts = calculate_cond(cond);
        // 若Cond为Float或FloatLiteral则需转换为Int或IntLiteral (IR机的GOTO是否实现有误？只支持整数？)
        if (cond->t == Type::Float || cond->t == Type::FloatLiteral)
        {
            if (cond->t == Type::FloatLiteral)
            {
                float val = std::stof(cond->v);
                cond->v = std::to_string(val != 0);
                cond->t = Type::IntLiteral;
            }
            else
            {
                string tmp1_name = "t";
                tmp1_name += std::to_string(tmp_cnt++);
                ir::Instruction* cvt1Inst = new ir::Instruction(ir::Operand(cond->v,Type::Float),
                                        ir::Operand("0.0",Type::FloatLiteral),
                                        ir::Operand(tmp1_name,Type::Float),ir::Operator::fneq);
                string tmp2_name = "t";
                tmp2_name += std::to_string(tmp_cnt++);
                ir::Instruction* cvt2Inst = new ir::Instruction(ir::Operand(tmp1_name,Type::Float),
                                        ir::Operand(),
                                        ir::Operand(tmp2_name,Type::Int),ir::Operator::cvt_f2i);
                cal_insts.push_back(cvt1Inst);
                cal_insts.push_back(cvt2Inst);
                cond->v = tmp2_name;
                cond->t = Type::Int;
            }
        }
        symbol_table.add_scope();
        // 分析Stmt的指令, 便于给出While跳转指令(PC值)
        vector<Instruction *> stmt_insts = analyze_stmt(dynamic_cast<Stmt*>(root->children[4]));
        symbol_table.exit_scope();
        // 满足条件, 则进入While体内
        Instruction* goto_while_Inst = new ir::Instruction(ir::Operand(cond->v,cond->t),
                                                            ir::Operand(),
                                                            ir::Operand("2",Type::IntLiteral),ir::Operator::_goto);
        // 每轮WHILE结束都要返回到开头
        Instruction* goto_return_begin_mark = new ir::Instruction(ir::Operand("continue",Type::null), // 为了实现简单, 直接添加一个标记指令
                                                    ir::Operand(),
                                                    ir::Operand(),ir::Operator::__unuse__);
        stmt_insts.push_back(goto_return_begin_mark);
        // 不满足条件, 则跳出While
        Instruction* goto_exit_while_Inst = new ir::Instruction(ir::Operand(),
                                                            ir::Operand(),
                                                            ir::Operand(std::to_string(stmt_insts.size()+1),Type::IntLiteral),ir::Operator::_goto);
        for (int i = 0; i < stmt_insts.size(); i++) // 遍历WHILE体中的BREAK与CONTINUE标记指令, 修改为_goto
        {
            if (stmt_insts[i]->op == Operator::__unuse__ && stmt_insts[i]->op1.type == Type::null)
            {
                if (stmt_insts[i]->op1.name == "break")
                {
                    Instruction *replace_break_inst = new ir::Instruction(ir::Operand(),
                                                            ir::Operand(),
                                                            ir::Operand(std::to_string(int(stmt_insts.size())-i),Type::IntLiteral),ir::Operator::_goto);
                    stmt_insts[i] = replace_break_inst;
                }
                else if (stmt_insts[i]->op1.name == "continue")
                {
                    Instruction *replace_continue_inst = new ir::Instruction(ir::Operand(),
                                                            ir::Operand(),
                                                            ir::Operand(std::to_string(-(2+i+int(cal_insts.size()))),Type::IntLiteral),ir::Operator::_goto);
                    stmt_insts[i] = replace_continue_inst;
                }
            }
        }
        // 合并所有指令到result
        result.insert(result.end(),cal_insts.begin(),cal_insts.end());
        result.push_back(goto_while_Inst);
        result.push_back(goto_exit_while_Inst);
        result.insert(result.end(),stmt_insts.begin(),stmt_insts.end());
        // Unuse
        Instruction * unuse_Inst = new ir::Instruction(ir::Operand(),
                                                        ir::Operand(),
                                                        ir::Operand(),ir::Operator::__unuse__);
        result.push_back(unuse_Inst);
        return result;
    }
    if (term->token.type == TokenType::BREAKTK)
    {
        Instruction *mark_break_inst = new Instruction(Operand("break",Type::null), Operand(), Operand(), Operator::__unuse__);
        result.push_back(mark_break_inst); // 添加标记指令, 在WHILE中解析完全部STMT指令后, 遍历指令寻找标记指令, 并替换为goto指令
        return result;
    }
    if (term->token.type == TokenType::CONTINUETK)
    {
        Instruction *mark_continue_inst = new Instruction(Operand("continue",Type::null), Operand(), Operand(), Operator::__unuse__);
        result.push_back(mark_continue_inst); // 添加标记指令, 在WHILE中解析完全部STMT指令后, 遍历指令寻找标记指令, 并替换为goto指令
        return result;
    }
}

vector<ir::Instruction *> frontend::Analyzer::calculate_exp(Exp* root)
{
    // 计算AddExp
    AddExp *addexp = dynamic_cast<AddExp *>(root->children[0]);
    assert(addexp);
    vector<ir::Instruction *> cal_insts = calculate_addexp(addexp);
    root->v = addexp->v;
    root->t = addexp->t;
    return cal_insts;
}

void frontend::Analyzer::calculate_constexp(ConstExp *root) // 此时, AddExp的结果应是整数字面量或浮点数字面量
{
    // 计算AddExp
    AddExp *addexp = dynamic_cast<AddExp *>(root->children[0]);
    assert(addexp);
    vector<ir::Instruction *> cal_insts = calculate_addexp(addexp);
    assert(cal_insts.size() == 0);
    root->v = addexp->v;
    root->t = addexp->t;
}

vector<ir::Instruction *> frontend::Analyzer::calculate_addexp(AddExp *root)
{
    vector<Instruction *> result;
    // 根据所有MulExp确定当前AddExp的类型 (类型提升: 整数 + - 浮点 -> 浮点) 只要有浮点数出现, 就会让当前表达式的结果类型提升为浮点, 变量 + - 常量 -> 变量，只要有变量， 就会类型提升为常量

    // 默认类型为整数,常量
    Type target_type = Type::IntLiteral;

    // 深度优先遍历, 先计算其所有子MulExp
    for (int i = 0; i < root->children.size(); i += 2)
    {
        MulExp *mulexp = dynamic_cast<MulExp *>(root->children[i]);
        assert(mulexp);
        vector<Instruction *> cal_insts = calculate_mulexp(mulexp);
        result.insert(result.end(),cal_insts.begin(),cal_insts.end());

        // 确定类型提升
        if (mulexp->t == ir::Type::Float)
            target_type = ir::Type::Float;
        else if (mulexp->t == ir::Type::Int && target_type == ir::Type::IntLiteral)
            target_type = ir::Type::Int;
        else if (mulexp->t == ir::Type::FloatLiteral && target_type == ir::Type::IntLiteral)
            target_type = ir::Type::FloatLiteral;
        else if ((mulexp->t == ir::Type::FloatLiteral && target_type == ir::Type::Int) || (target_type == ir::Type::FloatLiteral && mulexp->t == ir::Type::Int)) // 提升没有顺序
            target_type = ir::Type::Float;
    }

    // 计算表达式的结果
    // 默认为第一个MulExp的值
    MulExp* firstMulExp = dynamic_cast<MulExp*>(root->children[0]);
    assert(firstMulExp);
    root->t = firstMulExp->t;
    root->v = firstMulExp->v;

    if (root->children.size() == 1)
        return result; // 结果只有一个时，无视类型提升
    
    // 否则，进行进行计算，并遵从类型提升
    // 将第一个MulExp的值进行类型转换
    if (target_type != root->t)
    {
        if (target_type == Type::Int) // IntLiteral -> Int
        {
            assert(root->t == Type::IntLiteral);
            string tmp_intcvt_name = "t";
            tmp_intcvt_name += std::to_string(tmp_cnt++);
            Instruction * cvtInst = new Instruction(ir::Operand(root->v,ir::Type::IntLiteral),
                                    ir::Operand(),
                                    ir::Operand(tmp_intcvt_name,ir::Type::Int),ir::Operator::def);
            result.push_back(cvtInst);
            root->v = tmp_intcvt_name;
            root->t = Type::Int;
        }
        else if (target_type == Type::FloatLiteral) // IntLiteral -> FloatLiteral
        {
            assert(root->t == Type::IntLiteral);
            float val = std::stoi(root->v);
            root->v = std::to_string(val);
            root->t = Type::FloatLiteral;
        }
        else if (target_type == Type::Float) // IntLiteral -> Float, Int -> Float, FloatLiteral -> Float
        {
            if (root->t == Type::IntLiteral)
            {
                float val = std::stof(root->v);
                string tmp_intcvt_name = "t";
                tmp_intcvt_name += std::to_string(tmp_cnt++);
                Instruction * cvtInst = new Instruction(ir::Operand(std::to_string(val),ir::Type::FloatLiteral),
                                    ir::Operand(),
                                    ir::Operand(tmp_intcvt_name,ir::Type::Float),ir::Operator::fdef);
                result.push_back(cvtInst);
                root->v = tmp_intcvt_name;
                root->t = Type::Float;
            }
            else if (root->t == Type::Int)
            {
                string tmp_intcvt_name = "t";
                tmp_intcvt_name += std::to_string(tmp_cnt++);
                Instruction * cvtInst = new Instruction(ir::Operand(root->v,ir::Type::Int),
                                    ir::Operand(),
                                    ir::Operand(tmp_intcvt_name,ir::Type::Float),ir::Operator::cvt_i2f);
                result.push_back(cvtInst);
                root->v = tmp_intcvt_name;
                root->t = Type::Float; 
            }
            else if (root->t == Type::FloatLiteral)
            {
                string tmp_floatcvt_name = "t";
                tmp_floatcvt_name += std::to_string(tmp_cnt++);
                Instruction * cvtInst = new Instruction(ir::Operand(root->v,ir::Type::FloatLiteral),
                                    ir::Operand(),
                                    ir::Operand(tmp_floatcvt_name,ir::Type::Float),ir::Operator::fdef);
                result.push_back(cvtInst);
                root->v = tmp_floatcvt_name;
                root->t = Type::Float;
            }
            else
                assert(0 && "Error");
        }
        else
            assert(0 && "Error");
    }

    // 开始对2,4,6等进行计算
    for (int i = 2; i < root->children.size(); i += 2)
    {
        // 注意，此时root->t已为正确的类型
        MulExp *mulexp = dynamic_cast<MulExp *>(root->children[i]);

        // 符号
        Term* op_term  = dynamic_cast<Term*>(root->children[i-1]);

        // 在计算之前，先将两个操作数的类型变为相同的
        // 复用之前第一个MulExp类型提升的代码， 是不是写在一起有点重复？
        if (target_type != mulexp->t)
        {
            if (target_type == Type::Int) // IntLiteral -> Int
            {
                assert(mulexp->t == Type::IntLiteral);
                string tmp_intcvt_name = "t";
                tmp_intcvt_name += std::to_string(tmp_cnt++);
                Instruction * cvtInst = new Instruction(ir::Operand(mulexp->v,ir::Type::IntLiteral),
                                        ir::Operand(),
                                        ir::Operand(tmp_intcvt_name,ir::Type::Int),ir::Operator::def);
                result.push_back(cvtInst);
                mulexp->v = tmp_intcvt_name;
                mulexp->t = Type::Int;
            }
            else if (target_type == Type::FloatLiteral) // IntLiteral -> FloatLiteral
            {
                assert(mulexp->t == Type::IntLiteral);
                float val = std::stoi(mulexp->v);
                mulexp->v = std::to_string(val);
                mulexp->t = Type::FloatLiteral;
            }
            else if (target_type == Type::Float) // IntLiteral -> Float, Int -> Float, FloatLiteral -> Float
            {
                if (mulexp->t == Type::IntLiteral)
                {
                    float val = std::stof(mulexp->v);
                    string tmp_intcvt_name = "t";
                    tmp_intcvt_name += std::to_string(tmp_cnt++);
                    Instruction * cvtInst = new Instruction(ir::Operand(std::to_string(val),ir::Type::FloatLiteral),
                                        ir::Operand(),
                                        ir::Operand(tmp_intcvt_name,ir::Type::Float),ir::Operator::fdef);
                    result.push_back(cvtInst);
                    mulexp->v = tmp_intcvt_name;
                    mulexp->t = Type::Float;
                }
                else if (mulexp->t == Type::Int)
                {
                    string tmp_intcvt_name = "t";
                    tmp_intcvt_name += std::to_string(tmp_cnt++);
                    Instruction * cvtInst = new Instruction(ir::Operand(mulexp->v,ir::Type::Int),
                                        ir::Operand(),
                                        ir::Operand(tmp_intcvt_name,ir::Type::Float),ir::Operator::cvt_i2f);
                    result.push_back(cvtInst);
                    mulexp->v = tmp_intcvt_name;
                    mulexp->t = Type::Float; 
                }
                else if (mulexp->t == Type::FloatLiteral)
                {
                    string tmp_floatcvt_name = "t";
                    tmp_floatcvt_name += std::to_string(tmp_cnt++);
                    Instruction * cvtInst = new Instruction(ir::Operand(mulexp->v,ir::Type::FloatLiteral),
                                        ir::Operand(),
                                        ir::Operand(tmp_floatcvt_name,ir::Type::Float),ir::Operator::fdef);
                    result.push_back(cvtInst);
                    mulexp->v = tmp_floatcvt_name;
                    mulexp->t = Type::Float;
                }
                else
                    assert(0 && "Error");
            }
            else
                assert(0 && "Error");
        }
        // 已经化为相同类型
        // 开始计算
        if (target_type == Type::IntLiteral)
        {
            int val1 = std::stoi(root->v);
            int val2 = std::stoi(mulexp->v);
            if (op_term->token.type == TokenType::PLUS)
                root->v = std::to_string(val1+val2);
            else if (op_term->token.type == TokenType::MINU)
                root->v = std::to_string(val1-val2);
            else
                assert(0 && "Invalid Op");
        }
        else if (target_type == Type::FloatLiteral)
        {
            float val1 = std::stof(root->v);
            float val2 = std::stof(mulexp->v);
            if (op_term->token.type == TokenType::PLUS)
                root->v = std::to_string(val1+val2);
            else if (op_term->token.type == TokenType::MINU)
                root->v = std::to_string(val1-val2);
            else
                assert(0 && "Invalid Op");
        }
        else if (target_type == Type::Int)
        {
            string tmp_cal_name = "t";
            tmp_cal_name += std::to_string(tmp_cnt++);
            Instruction * calInst;
            if (op_term->token.type == TokenType::PLUS)
                calInst = new Instruction(ir::Operand(root->v,ir::Type::Int),
                                ir::Operand(mulexp->v,ir::Type::Int),
                                ir::Operand(tmp_cal_name,ir::Type::Int),ir::Operator::add);
            else if (op_term->token.type == TokenType::MINU)
                calInst = new Instruction(ir::Operand(root->v,ir::Type::Int),
                                ir::Operand(mulexp->v,ir::Type::Int),
                                ir::Operand(tmp_cal_name,ir::Type::Int),ir::Operator::sub);
            else
                assert(0 && "Invalid Op");
            result.push_back(calInst);
            root->v = tmp_cal_name;
        }
        else if (target_type == Type::Float)
        {
            string tmp_cal_name = "t";
            tmp_cal_name += std::to_string(tmp_cnt++);
            Instruction * calInst;
            if (op_term->token.type == TokenType::PLUS)
                calInst = new Instruction(ir::Operand(root->v,ir::Type::Float),
                                ir::Operand(mulexp->v,ir::Type::Float),
                                ir::Operand(tmp_cal_name,ir::Type::Float),ir::Operator::fadd);
            else if (op_term->token.type == TokenType::MINU)
                calInst = new Instruction(ir::Operand(root->v,ir::Type::Float),
                                ir::Operand(mulexp->v,ir::Type::Float),
                                ir::Operand(tmp_cal_name,ir::Type::Float),ir::Operator::fsub);
            else
                assert(0 && "Invalid Op");
            result.push_back(calInst);
            root->v = tmp_cal_name;
        }
        else
            assert(0 && "Error");
    }
    return result;

}

vector<ir::Instruction *> frontend::Analyzer::calculate_mulexp(MulExp *root)
{
    vector<Instruction *> result;
    // 根据所有UnaryExp确定当前MulExp的类型 (类型提升: 整数 * / 浮点 -> 浮点) 只要有浮点数出现, 就会让当前表达式的结果类型提升为浮点, 变量 * / % 常量 -> 变量，只要有变量， 就会类型提升为常量

    // 默认类型为整数,常量
    Type target_type = Type::IntLiteral;

    // 深度优先遍历, 先计算其所有子UnaryExp
    for (int i = 0; i < root->children.size(); i += 2)
    {
        UnaryExp *unaryexp = dynamic_cast<UnaryExp *>(root->children[i]);
        assert(unaryexp);
        vector<Instruction *> cal_insts = calculate_unaryexp(unaryexp);
        result.insert(result.end(),cal_insts.begin(),cal_insts.end());

        // 确定类型提升
        if (unaryexp->t == ir::Type::Float)
            target_type = ir::Type::Float;
        else if (unaryexp->t == ir::Type::Int && target_type == ir::Type::IntLiteral)
            target_type = ir::Type::Int;
        else if (unaryexp->t == ir::Type::FloatLiteral && target_type == ir::Type::IntLiteral)
            target_type = ir::Type::FloatLiteral;
        else if ((unaryexp->t == ir::Type::FloatLiteral && target_type == ir::Type::Int) || (target_type == ir::Type::FloatLiteral && unaryexp->t == ir::Type::Int)) // 提升没有顺序
            target_type = ir::Type::Float;
    }

    // 计算表达式的结果
    // 默认为第一个UnaryExp的值
    UnaryExp* firstUnaryExp = dynamic_cast<UnaryExp*>(root->children[0]);
    assert(firstUnaryExp);
    root->t = firstUnaryExp->t;
    root->v = firstUnaryExp->v;

    if (root->children.size() == 1)
        return result; // 结果只有一个时，无视类型提升

    // 否则，进行进行计算，并遵从类型提升
    // 将第一个UnaryExp的值进行类型转换
    if (target_type != root->t)
    {
        if (target_type == Type::Int) // IntLiteral -> Int
        {
            assert(root->t == Type::IntLiteral);
            string tmp_intcvt_name = "t";
            tmp_intcvt_name += std::to_string(tmp_cnt++);
            Instruction * cvtInst = new Instruction(ir::Operand(root->v,ir::Type::IntLiteral),
                                    ir::Operand(),
                                    ir::Operand(tmp_intcvt_name,ir::Type::Int),ir::Operator::def);
            result.push_back(cvtInst);
            root->v = tmp_intcvt_name;
            root->t = Type::Int;
        }
        else if (target_type == Type::FloatLiteral) // IntLiteral -> FloatLiteral
        {
            assert(root->t == Type::IntLiteral);
            float val = std::stoi(root->v);
            root->v = std::to_string(val);
            root->t = Type::FloatLiteral;
        }
        else if (target_type == Type::Float) // IntLiteral -> Float, Int -> Float, FloatLiteral -> Float
        {
            if (root->t == Type::IntLiteral)
            {
                float val = std::stof(root->v);
                string tmp_intcvt_name = "t";
                tmp_intcvt_name += std::to_string(tmp_cnt++);
                Instruction * cvtInst = new Instruction(ir::Operand(std::to_string(val),ir::Type::FloatLiteral),
                                    ir::Operand(),
                                    ir::Operand(tmp_intcvt_name,ir::Type::Float),ir::Operator::fdef);
                result.push_back(cvtInst);
                root->v = tmp_intcvt_name;
                root->t = Type::Float;
            }
            else if (root->t == Type::Int)
            {
                string tmp_intcvt_name = "t";
                tmp_intcvt_name += std::to_string(tmp_cnt++);
                Instruction * cvtInst = new Instruction(ir::Operand(root->v,ir::Type::Int),
                                    ir::Operand(),
                                    ir::Operand(tmp_intcvt_name,ir::Type::Float),ir::Operator::cvt_i2f);
                result.push_back(cvtInst);
                root->v = tmp_intcvt_name;
                root->t = Type::Float; 
            }
            else if (root->t == Type::FloatLiteral)
            {
                string tmp_floatcvt_name = "t";
                tmp_floatcvt_name += std::to_string(tmp_cnt++);
                Instruction * cvtInst = new Instruction(ir::Operand(root->v,ir::Type::FloatLiteral),
                                    ir::Operand(),
                                    ir::Operand(tmp_floatcvt_name,ir::Type::Float),ir::Operator::fdef);
                result.push_back(cvtInst);
                root->v = tmp_floatcvt_name;
                root->t = Type::Float;
            }
            else
                assert(0 && "Error");
        }
        else
            assert(0 && "Error");
    }

    // 开始对2,4,6等进行计算
    for (int i = 2; i < root->children.size(); i += 2)
    {
        // 注意，此时root->t已为正确的类型
        UnaryExp *unaryexp = dynamic_cast<UnaryExp *>(root->children[i]);

        // 符号
        Term* op_term  = dynamic_cast<Term*>(root->children[i-1]);

        // 在计算之前，先将两个操作数的类型变为相同的
        // 复用之前第一个UnaryExp类型提升的代码， 是不是写在一起有点重复？
        if (target_type != unaryexp->t)
        {
            if (target_type == Type::Int) // IntLiteral -> Int
            {
                assert(unaryexp->t == Type::IntLiteral);
                string tmp_intcvt_name = "t";
                tmp_intcvt_name += std::to_string(tmp_cnt++);
                Instruction * cvtInst = new Instruction(ir::Operand(unaryexp->v,ir::Type::IntLiteral),
                                        ir::Operand(),
                                        ir::Operand(tmp_intcvt_name,ir::Type::Int),ir::Operator::def);
                result.push_back(cvtInst);
                unaryexp->v = tmp_intcvt_name;
                unaryexp->t = Type::Int;
            }
            else if (target_type == Type::FloatLiteral) // IntLiteral -> FloatLiteral
            {
                assert(unaryexp->t == Type::IntLiteral);
                float val = std::stoi(unaryexp->v);
                unaryexp->v = std::to_string(val);
                unaryexp->t = Type::FloatLiteral;
            }
            else if (target_type == Type::Float) // IntLiteral -> Float, Int -> Float, FloatLiteral -> Float
            {
                if (unaryexp->t == Type::IntLiteral)
                {
                    float val = std::stof(unaryexp->v);
                    string tmp_intcvt_name = "t";
                    tmp_intcvt_name += std::to_string(tmp_cnt++);
                    Instruction * cvtInst = new Instruction(ir::Operand(std::to_string(val),ir::Type::FloatLiteral),
                                        ir::Operand(),
                                        ir::Operand(tmp_intcvt_name,ir::Type::Float),ir::Operator::fdef);
                    result.push_back(cvtInst);
                    unaryexp->v = tmp_intcvt_name;
                    unaryexp->t = Type::Float;
                }
                else if (unaryexp->t == Type::Int)
                {
                    string tmp_intcvt_name = "t";
                    tmp_intcvt_name += std::to_string(tmp_cnt++);
                    Instruction * cvtInst = new Instruction(ir::Operand(unaryexp->v,ir::Type::Int),
                                        ir::Operand(),
                                        ir::Operand(tmp_intcvt_name,ir::Type::Float),ir::Operator::cvt_i2f);
                    result.push_back(cvtInst);
                    unaryexp->v = tmp_intcvt_name;
                    unaryexp->t = Type::Float; 
                }
                else if (unaryexp->t == Type::FloatLiteral)
                {
                    string tmp_floatcvt_name = "t";
                    tmp_floatcvt_name += std::to_string(tmp_cnt++);
                    Instruction * cvtInst = new Instruction(ir::Operand(unaryexp->v,ir::Type::FloatLiteral),
                                        ir::Operand(),
                                        ir::Operand(tmp_floatcvt_name,ir::Type::Float),ir::Operator::fdef);
                    result.push_back(cvtInst);
                    unaryexp->v = tmp_floatcvt_name;
                    unaryexp->t = Type::Float;
                }
                else
                    assert(0 && "Error");
            }
            else
                assert(0 && "Error");
        }
        // 已经化为相同类型
        // 开始计算
        if (target_type == Type::IntLiteral)
        {
            int val1 = std::stoi(root->v);
            int val2 = std::stoi(unaryexp->v);
            if (op_term->token.type == TokenType::MULT)
                root->v = std::to_string(val1*val2);
            else if (op_term->token.type == TokenType::DIV)
                root->v = std::to_string(val1/val2);
            else if (op_term->token.type == TokenType::MOD)
                root->v = std::to_string(val1%val2);
            else
                assert(0 && "Invalid Op");
        }
        else if (target_type == Type::FloatLiteral)
        {
            float val1 = std::stof(root->v);
            float val2 = std::stof(unaryexp->v);
            if (op_term->token.type == TokenType::MULT)
                root->v = std::to_string(val1*val2);
            else if (op_term->token.type == TokenType::DIV)
                root->v = std::to_string(val1/val2);
            else
                assert(0 && "Invalid Op");
        }
        else if (target_type == Type::Int)
        {
            string tmp_cal_name = "t";
            tmp_cal_name += std::to_string(tmp_cnt++);
            Instruction * calInst;
            if (op_term->token.type == TokenType::MULT)
                calInst = new Instruction(ir::Operand(root->v,ir::Type::Int),
                                ir::Operand(unaryexp->v,ir::Type::Int),
                                ir::Operand(tmp_cal_name,ir::Type::Int),ir::Operator::mul);
            else if (op_term->token.type == TokenType::DIV)
                calInst = new Instruction(ir::Operand(root->v,ir::Type::Int),
                                ir::Operand(unaryexp->v,ir::Type::Int),
                                ir::Operand(tmp_cal_name,ir::Type::Int),ir::Operator::div);
            else if (op_term->token.type == TokenType::MOD)
                calInst = new Instruction(ir::Operand(root->v,ir::Type::Int),
                                ir::Operand(unaryexp->v,ir::Type::Int),
                                ir::Operand(tmp_cal_name,ir::Type::Int),ir::Operator::mod);
            else
                assert(0 && "Invalid Op");
            result.push_back(calInst);
            root->v = tmp_cal_name;
        }
        else if (target_type == Type::Float)
        {
            string tmp_cal_name = "t";
            tmp_cal_name += std::to_string(tmp_cnt++);
            Instruction * calInst;
            if (op_term->token.type == TokenType::MULT)
                calInst = new Instruction(ir::Operand(root->v,ir::Type::Float),
                                ir::Operand(unaryexp->v,ir::Type::Float),
                                ir::Operand(tmp_cal_name,ir::Type::Float),ir::Operator::fmul);
            else if (op_term->token.type == TokenType::DIV)
                calInst = new Instruction(ir::Operand(root->v,ir::Type::Float),
                                ir::Operand(unaryexp->v,ir::Type::Float),
                                ir::Operand(tmp_cal_name,ir::Type::Float),ir::Operator::fdiv);
            else
                assert(0 && "Invalid Op");
            result.push_back(calInst);
            root->v = tmp_cal_name;
        }
        else
            assert(0 && "Error");
    }
    return result;
}

vector<ir::Instruction *> frontend::Analyzer::calculate_unaryexp(UnaryExp *root)
{
    vector<ir::Instruction *> result;
    // Ident '(' [FuncRParams] ')'分支，调用函数
    Term *term = dynamic_cast<Term *>(root->children[0]);
    if (term != nullptr && term->token.type == TokenType::IDENFR)
    {
        string func_name = term->token.value;
        // 分析 FuncRParams, 函数调用时传递的参数
        vector<Operand> paraVec;
        FuncRParams *funcrparams = dynamic_cast<FuncRParams *>(root->children[2]);
        Function* call_func = symbol_table.functions[func_name];
        // 如果有函数参数, 则进行分析
        if (funcrparams != nullptr)
        {
            // 获取函数的参数列表， 用于判断类型提升 Int -> Float, 与Float -> Int
            vector<Operand> func_para_type = call_func->ParameterList;
            // 分析FuncRParams, 将参数写入paraVec
            for (int i = 0, cnt = 0; i < funcrparams->children.size(); i += 2, cnt += 1)
            {
                Exp *exp = dynamic_cast<Exp *>(funcrparams->children[i]);
                vector<ir::Instruction *> cal_insts = calculate_exp(exp);
                result.insert(result.end(),cal_insts.begin(),cal_insts.end());
                // 根据func_para_type[i]的类型进行类型提升
                if (func_para_type[cnt].type == ir::Type::Float)
                {
                    if (exp->t == Type::Int)
                    {
                        string tmp_type_cvt_name = "t";
                        tmp_type_cvt_name += std::to_string(tmp_cnt++);
                        ir::Instruction* cvtInst = new Instruction(ir::Operand(exp->v,ir::Type::Int),
                                                    ir::Operand(),
                                                    ir::Operand(tmp_type_cvt_name,ir::Type::Float),ir::Operator::cvt_i2f);
                        result.push_back(cvtInst);
                        paraVec.push_back(Operand(tmp_type_cvt_name, ir::Type::Float));
                    }
                    else if (exp->t == Type::IntLiteral)
                    {
                        float val = std::stoi(exp->v);
                        paraVec.push_back(Operand(std::to_string(val), ir::Type::FloatLiteral));
                    }
                    else
                    {
                        assert(exp->t == Type::Float || exp->t == Type::FloatLiteral);
                        paraVec.push_back(Operand(exp->v, exp->t));
                    }
                }
                else if (func_para_type[cnt].type == ir::Type::Int)
                {
                    if (exp->t == Type::Float)
                    {
                        string tmp_type_cvt_name = "t";
                        tmp_type_cvt_name += std::to_string(tmp_cnt++);
                        ir::Instruction* cvtInst = new Instruction(ir::Operand(exp->v,ir::Type::Float),
                                                    ir::Operand(),
                                                    ir::Operand(tmp_type_cvt_name,ir::Type::Int),ir::Operator::cvt_f2i);
                        result.push_back(cvtInst);
                        paraVec.push_back(Operand(tmp_type_cvt_name, ir::Type::Int));
                    }
                    else if (exp->t == Type::FloatLiteral)
                    {
                        int val = std::stoi(exp->v);
                        paraVec.push_back(Operand(std::to_string(val), ir::Type::IntLiteral));
                    }
                    else
                    {
                        assert(exp->t == Type::Int || exp->t == Type::IntLiteral);
                        paraVec.push_back(Operand(exp->v, exp->t));
                    }
                }
                else // 不需要类型提升
                {
                    paraVec.push_back(Operand(exp->v, exp->t));
                }
            }
        }
        // 保存结果的临时变量
        string tmp_func_result_name = "t";
        tmp_func_result_name += std::to_string(tmp_cnt++);
        // 生成函数调用指令
        ir::CallInst* callInst = new ir::CallInst(ir::Operand(call_func->name,call_func->returnType),
                                            paraVec,
                                            ir::Operand(tmp_func_result_name,call_func->returnType));
        result.push_back(callInst);
        // 将结果写入root
        root->v = tmp_func_result_name;
        root->t = call_func->returnType;
        return result;
    }
    // UnaryOp分支 : UnaryOp UnaryExp
    UnaryOp *unaryop = dynamic_cast<UnaryOp *>(root->children[0]);
    if (unaryop != nullptr)
    {
        // 深度优先
        UnaryExp *unaryexp = dynamic_cast<UnaryExp *>(root->children[1]);
        vector<ir::Instruction *> cal_insts = calculate_unaryexp(unaryexp);
        result.insert(result.end(),cal_insts.begin(),cal_insts.end());
        // 根据unaryop的类型进行计算
        Term *unaryop_term = dynamic_cast<Term *>(unaryop->children[0]);
        if (unaryop_term->token.type == TokenType::PLUS)
        {
            // 根据UnaryExp的值,设置当前表达式的值，以及类型
            root->v = unaryexp->v;
            root->t = unaryexp->t;
        }
        else if (unaryop_term->token.type == TokenType::MINU)
        {
            // 根据UnaryExp的值,设置当前表达式的值，以及类型
            if (unaryexp->t == Type::FloatLiteral)
            {
                float tmp_result = -std::stof(unaryexp->v);
                root->v = std::to_string(tmp_result);
                root->t = Type::FloatLiteral;
            }
            else if (unaryexp->t == Type::IntLiteral)
            {
                int tmp_result = -std::stoi(unaryexp->v);
                root->v = std::to_string(tmp_result);
                root->t = Type::IntLiteral;
            }
            else if (unaryexp->t == Type::Int)
            {
                // 使用sub取反

                // 0临时变量
                string tmp_zero_name = "t";
                tmp_zero_name += std::to_string(tmp_cnt++);
                ir::Instruction* defInst = new ir::Instruction(ir::Operand("0",ir::Type::IntLiteral),
                                                    ir::Operand(),
                                                    ir::Operand(tmp_zero_name,ir::Type::Int),ir::Operator::def);
                // 结果临时变量
                string tmp_minu_name = "t";
                tmp_minu_name += std::to_string(tmp_cnt++);
                ir::Instruction* minuInst = new ir::Instruction(ir::Operand(tmp_zero_name,ir::Type::Int),
                                                    ir::Operand(unaryexp->v,ir::Type::Int),
                                                    ir::Operand(tmp_minu_name,ir::Type::Int),ir::Operator::sub);
                result.push_back(defInst);
                result.push_back(minuInst);
                root->v = tmp_minu_name;
                root->t = Type::Int;
            }
            else if (unaryexp->t == Type::Float)
            {
                // 使用fsub取反

                // 0临时变量
                string tmp_zero_name = "t";
                tmp_zero_name += std::to_string(tmp_cnt++);
                ir::Instruction* defInst = new ir::Instruction(ir::Operand("0.0",ir::Type::FloatLiteral),
                                                    ir::Operand(),
                                                    ir::Operand(tmp_zero_name,ir::Type::Float),ir::Operator::fdef);
                // 结果临时变量
                string tmp_minu_name = "t";
                tmp_minu_name += std::to_string(tmp_cnt++);
                ir::Instruction* minuInst = new ir::Instruction(ir::Operand(tmp_zero_name,ir::Type::Float),
                                                    ir::Operand(unaryexp->v,ir::Type::Float),
                                                    ir::Operand(tmp_minu_name,ir::Type::Float),ir::Operator::fsub);
                result.push_back(defInst);
                result.push_back(minuInst);
                root->v = tmp_minu_name;
                root->t = Type::Float;
            }
            else
                assert(0 && "Error");
        }
        else if (unaryop_term->token.type == TokenType::NOT)
        {
            // 根据UnaryExp的值,设置当前表达式的值，以及类型
            if (unaryexp->t == Type::FloatLiteral)
            {
                int tmp_result = !std::stof(unaryexp->v);
                root->v = std::to_string(tmp_result);
                root->t = Type::IntLiteral;
            }
            else if (unaryexp->t == Type::IntLiteral)
            {
                int tmp_result = !std::stoi(unaryexp->v);
                root->v = std::to_string(tmp_result);
                root->t = Type::IntLiteral;
            }
            else if (unaryexp->t == Type::Int)
            {
                // 使用not进行转换
                string tmp_not_name = "t";
                tmp_not_name += std::to_string(tmp_cnt++);
                ir::Instruction* notInst = new ir::Instruction(ir::Operand(unaryexp->v,ir::Type::Int),
                                                    ir::Operand(),
                                                    ir::Operand(tmp_not_name,ir::Type::Int),ir::Operator::_not);
                result.push_back(notInst);
                root->v = tmp_not_name;
                root->t = Type::Int;
            }
            else if (unaryexp->t == Type::Float)
            {
                // 使用not进行转换
                string tmp_not_name = "t";
                tmp_not_name += std::to_string(tmp_cnt++);
                ir::Instruction* notInst = new ir::Instruction(ir::Operand(unaryexp->v,ir::Type::Float),
                                                    ir::Operand(),
                                                    ir::Operand(tmp_not_name,ir::Type::Int),ir::Operator::_not);
                result.push_back(notInst);
                root->v = tmp_not_name;
                root->t = Type::Int;
            }
            else
                assert(0 && "Error");
        }
        else
            assert(0 && "Unknown UnaryOp");
        return result;
    }
    else // PrimaryExp分支 : PrimaryExp
    {
        PrimaryExp *primaryexp = dynamic_cast<PrimaryExp *>(root->children[0]);
        assert(primaryexp);
        vector<Instruction *> cal_insts = calculate_primaryexp(primaryexp);
        result.insert(result.end(),cal_insts.begin(),cal_insts.end());
        // 根据primaryexp的值,设置当前表达式的值，以及类型
        root->v = primaryexp->v;
        root->t = primaryexp->t;
        return result;
    }
    assert(0 && "Error");
}

vector<Instruction *> frontend::Analyzer::calculate_primaryexp(PrimaryExp *root)
{
    vector<Instruction *> result;
    // Number分支
    if (Number *number = dynamic_cast<Number *>(root->children[0]))
    {
        // DFS
        calculate_number(number);
        root->v = number->v;
        root->t = number->t;
        return result;
    }
    // LVal分支
    if (LVal *lval = dynamic_cast<LVal *>(root->children[0]))
    {
        result = calculate_lval(lval);
        root->v = lval->v;
        root->t = lval->t;
        return result;
    }
    // Exp分支
    if (root->children.size() == 3)
    {
        Exp *exp = dynamic_cast<Exp *>(root->children[1]);
        // 深度优先
        result = calculate_exp(exp);
        root->t = exp->t;
        root->v = exp->v;
        return result;
    }
    assert(0 && "Error In Calculate PrimaryExp");
}

vector<Instruction *> frontend::Analyzer::calculate_lval(LVal *root)
{
    vector<Instruction *> result;
    Term* term = dynamic_cast<Term*>(root->children[0]);
    assert(term && term->token.type == TokenType::IDENFR);
    string var_name = term->token.value;
    if (root->children.size() == 1)
    {
        // 直接返回变量
        // 可能的类型: Int, IntLiteral, Float, FloatLiteral, IntPtr, FloatPtr
        // 通过符号表获取变量类型
        STE operand_ste = symbol_table.get_ste(var_name);
        root->t = operand_ste.operand.type;
        if (root->t == Type::IntLiteral || root->t == Type::FloatLiteral)
        {
            root->v = operand_ste.literalVal;
        }
        else
            root->v = symbol_table.get_scoped_name(var_name); // 在此处返回重命名后的变量名, 后续计算时, 会在IR指令生成中使用重命名后的变量名
        return result;
    }
    else if (root->children.size() == 4) // 数组取值, 需要使用指令
    {
        Exp* exp = dynamic_cast<Exp*>(root->children[2]);
        assert(exp);
        // 计算数组下标
        vector<Instruction *> exp_result = calculate_exp(exp);
        assert(exp->t == Type::Int || exp->t == Type::IntLiteral);
        // 合并计算指令
        result.insert(result.end(), exp_result.begin(), exp_result.end());
        // 判断当前返回类型: Int, Float, IntPtr, FloatPtr
        STE operand_ste = symbol_table.get_ste(var_name);
        assert(operand_ste.operand.type == Type::IntPtr || operand_ste.operand.type == Type::FloatPtr);
        // 判断是一维数组, 还是二维数组?
        if (operand_ste.dimension.size() == 1) // 一维数组
        {
            // 返回类型: Int or Float
            Type target_type = operand_ste.operand.type == Type::IntPtr ? Type::Int : Type::Float;

            // 从基址 + 偏移 从内存中LOAD出值
            string tmp_var_name = "t";
            tmp_var_name += std::to_string(tmp_cnt++);
            Instruction* loadInst = new ir::Instruction(ir::Operand(symbol_table.get_scoped_name(var_name),operand_ste.operand.type),
                                        ir::Operand(exp->v,exp->t),
                                        ir::Operand(tmp_var_name,target_type),ir::Operator::load);
            result.push_back(loadInst);
            root->t = target_type;
            root->v = tmp_var_name;
            return result;
        }
        else // 二维数组
        {
            // 返回类型 IntPtr or FloatPtr
            Type target_type = operand_ste.operand.type; // 与原类型相同

            // 利用基址 + 偏移 计算出一维数组的基址
            string tmp_var_name = "t";
            tmp_var_name += std::to_string(tmp_cnt++);
            // 偏移需要 乘上 数组列长度
            if (exp->t == Type::IntLiteral)
            {
                int val = std::stoi(exp->v);
                val *= operand_ste.dimension[1];
                Instruction* getptrInst = new ir::Instruction(ir::Operand(symbol_table.get_scoped_name(var_name),operand_ste.operand.type),
                                            ir::Operand(std::to_string(val),Type::IntLiteral),
                                            ir::Operand(tmp_var_name,target_type),ir::Operator::getptr);
                result.push_back(getptrInst);
            }
            else // 否则, 需要生成指令, 计算变量中的下标对应的偏移量
            {
                // 需要新增一个临时变量
                string tmp_offset_name = "t";
                tmp_offset_name += std::to_string(tmp_cnt++);
                // 由于建议mul指令全为变量, 先将exp->v存入一个临时变量
                string tmp_mul_name = "t";
                tmp_mul_name += std::to_string(tmp_cnt++);
                Instruction* defInst = new ir::Instruction(ir::Operand(std::to_string(operand_ste.dimension[1]),Type::IntLiteral),
                                            ir::Operand(),
                                            ir::Operand(tmp_mul_name,Type::Int),ir::Operator::def);
                Instruction* mulInst = new ir::Instruction(ir::Operand(exp->v,Type::Int),
                                            ir::Operand(tmp_mul_name,Type::Int),
                                            ir::Operand(tmp_offset_name,Type::Int),ir::Operator::mul);
                Instruction* getptrInst = new ir::Instruction(ir::Operand(symbol_table.get_scoped_name(var_name),operand_ste.operand.type),
                                            ir::Operand(tmp_offset_name,Type::Int),
                                            ir::Operand(tmp_var_name,target_type),ir::Operator::getptr);
                result.push_back(defInst);
                result.push_back(mulInst);
                result.push_back(getptrInst);
            }
            root->t = target_type;
            root->v = tmp_var_name;
            return result;
        }
        assert(0 && "Error");
    }
    else if (root->children.size() == 7) // 数组取值, 需要使用指令
    {
        Exp* exp1 = dynamic_cast<Exp*>(root->children[2]);
        assert(exp1);
        Exp* exp2 = dynamic_cast<Exp*>(root->children[5]);
        assert(exp2);
        // 计算数组下标
        vector<Instruction *> exp1_result = calculate_exp(exp1);
        vector<Instruction *> exp2_result = calculate_exp(exp2);
        assert(exp1->t == Type::Int || exp1->t == Type::IntLiteral);
        assert(exp2->t == Type::Int || exp2->t == Type::IntLiteral);
        // 合并计算指令
        result.insert(result.end(), exp1_result.begin(), exp1_result.end());
        result.insert(result.end(), exp2_result.begin(), exp2_result.end());
        // 判断当前返回类型: Int, Float
        STE operand_ste = symbol_table.get_ste(var_name);
        assert(operand_ste.dimension.size() == 2);
        assert(operand_ste.operand.type == Type::IntPtr || operand_ste.operand.type == Type::FloatPtr);

        // 返回类型 Int or Float
        Type target_type = operand_ste.operand.type == Type::IntPtr ? Type::Int : Type::Float;

        // 为了从二维数组中取值, 需计算偏移
        // 为了简单实现, 此处可先直接将两个exp1和exp2计算的结果都放入临时变量中
        string tmp_dim1_name = "t";
        tmp_dim1_name += std::to_string(tmp_cnt++);
        string tmp_dim2_name = "t";
        tmp_dim2_name += std::to_string(tmp_cnt++);
        Instruction *def1Inst = new ir::Instruction(ir::Operand(exp1->v, exp1->t),
                                                    ir::Operand(),
                                                    ir::Operand(tmp_dim1_name, Type::Int), ir::Operator::def);
        Instruction *def2Inst = new ir::Instruction(ir::Operand(exp2->v, exp2->t),
                                                    ir::Operand(),
                                                    ir::Operand(tmp_dim2_name, Type::Int), ir::Operator::def);
        string tmp_col_len_name = "t";
        tmp_col_len_name += std::to_string(tmp_cnt++);
        Instruction *def3Inst = new ir::Instruction(ir::Operand(std::to_string(operand_ste.dimension[1]), Type::IntLiteral),
                                                    ir::Operand(),
                                                    ir::Operand(tmp_col_len_name, Type::Int), ir::Operator::def);
        string tmp_lineoffset_name = "t";
        tmp_lineoffset_name += std::to_string(tmp_cnt++);
        // 计算行偏移
        Instruction *mulOffsetInst = new ir::Instruction(ir::Operand(tmp_dim1_name, Type::Int),
                                                          ir::Operand(tmp_col_len_name, Type::Int),
                                                          ir::Operand(tmp_lineoffset_name, Type::Int), ir::Operator::mul);
        // 计算总偏移
        string tmp_totaloffset_name = "t";
        tmp_totaloffset_name += std::to_string(tmp_cnt++);
        Instruction *addOffsetInst = new ir::Instruction(ir::Operand(tmp_lineoffset_name, Type::Int),
                                                          ir::Operand(tmp_dim2_name, Type::Int),
                                                          ir::Operand(tmp_totaloffset_name, Type::Int), ir::Operator::add);
        // 取值
        string tmp_loadval_name = "t";
        tmp_loadval_name += std::to_string(tmp_cnt++);
        Instruction *loadInst = new ir::Instruction(ir::Operand(symbol_table.get_scoped_name(var_name), operand_ste.operand.type),
                                                    ir::Operand(tmp_totaloffset_name, Type::Int),
                                                    ir::Operand(tmp_loadval_name, target_type), ir::Operator::load);
        result.push_back(def1Inst);
        result.push_back(def2Inst);
        result.push_back(def3Inst);
        result.push_back(mulOffsetInst);
        result.push_back(addOffsetInst);
        result.push_back(loadInst);
        root->v = tmp_loadval_name;
        root->t = target_type;
        return result;
    }
}

void frontend::Analyzer::calculate_number(Number *root)
{
    // 判断是Int还是Float字面量
    Term *term = dynamic_cast<Term *>(root->children[0]);
    if (term->token.type == TokenType::INTLTR)
    {
        root->t = Type::IntLiteral;
        // 针对二进制、八进制、十六进制的特殊转换处理
        const string &token_val = term->token.value;
        // 十六进制
        if (token_val.length() >= 3 && token_val[0] == '0' && (token_val[1] == 'x' || token_val[1] == 'X'))
        {
            root->v = std::to_string(std::stoi(token_val, nullptr, 16));
        }
        // 二进制
        else if (token_val.length() >= 3 && token_val[0] == '0' && (token_val[1] == 'b' || token_val[1] == 'B'))
        {
            root->v = std::to_string(std::stoi(token_val.substr(2), nullptr, 2));
        }
        // 八进制
        else if (token_val.length() >= 2 && token_val[0] == '0')
        {
            root->v = std::to_string(std::stoi(token_val, nullptr, 8));
        }
        // 十进制
        else
            root->v = token_val;
    }
    else if (term->token.type == TokenType::FLOATLTR)
    {
        root->t = Type::FloatLiteral;
        root->v = term->token.value;
    }
    else
        assert(0 && "Unknown Number Type");
}

vector<ir::Instruction *> frontend::Analyzer::calculate_cond(Cond* root)
{
    // 可能的类型: Int or IntLiteral or Float or FloatLiteral

    LOrExp* lorexp = dynamic_cast<LOrExp*>(root->children[0]);
    assert(lorexp);
    vector<ir::Instruction *> cal_insts = calculate_lorexp(lorexp);
    root->v = lorexp->v;
    root->t = lorexp->t;
    return cal_insts;
}

vector<ir::Instruction *> frontend::Analyzer::calculate_lorexp(LOrExp* root)
{
    // 注意! LOrExp与LAndExp不需要同类型!!!!!

    vector<ir::Instruction *> result;

    LAndExp* landexp = dynamic_cast<LAndExp*>(root->children[0]);
    assert(landexp);
    vector<ir::Instruction *> cal_insts = calculate_landexp(landexp);
    result.insert(result.end(),cal_insts.begin(),cal_insts.end());
    root->v = landexp->v;
    root->t = landexp->t;
    if (root->children.size() == 1)
    {
        return result;
    }
    else
    {
        LOrExp* lorexp = dynamic_cast<LOrExp*>(root->children[2]);
        assert(lorexp);
        vector<ir::Instruction *> cal_insts = calculate_lorexp(lorexp); // 不立刻加入results中

        // 处理操作数1 (计算其是否为真 or 假)
        if (root->t == Type::Float)
        {
            string tmp_name = "t";
            tmp_name += std::to_string(tmp_cnt++);
            ir::Instruction* cvtInst = new ir::Instruction(ir::Operand(root->v,Type::Float),
                                    ir::Operand("0.0",Type::FloatLiteral),
                                    ir::Operand(tmp_name,Type::Int),ir::Operator::fneq);
            result.push_back(cvtInst);
            root->v = tmp_name;
            root->t = Type::Int;
        }
        else if (root->t == Type::FloatLiteral)
        {
            float val = std::stof(root->v);
            root->t = Type::IntLiteral;
            root->v = std::to_string(val != 0);
        }

        // 处理操作数2 (计算其是否为真 or 假)
        if (lorexp->t == Type::Float)
        {
            string tmp_name = "t";
            tmp_name += std::to_string(tmp_cnt++);
            ir::Instruction* cvtInst = new ir::Instruction(ir::Operand(lorexp->v,Type::Float),
                                    ir::Operand("0.0",Type::FloatLiteral),
                                    ir::Operand(tmp_name,Type::Int),ir::Operator::fneq);
            cal_insts.push_back(cvtInst);
            lorexp->v = tmp_name;
            lorexp->t = Type::Int;
        }
        else if (lorexp->t == Type::FloatLiteral)
        {
            float val = std::stof(lorexp->v);
            lorexp->t = Type::IntLiteral;
            lorexp->v = std::to_string(val != 0);
        }

        // 开始计算
        if (root->t == Type::IntLiteral && lorexp->t == Type::IntLiteral)
        {
            root->v = std::to_string(std::stoi(root->v) || std::stoi(lorexp->v));
        }
        else
        {
            // 注意短路规则: 左侧为真则不计算右侧
            string tmp_cal_name = "t";
            tmp_cal_name += std::to_string(tmp_cnt++);


            // 真逻辑: 跳转PC+2,tmp_cal_name赋为1, 然后跳转至结束
            Instruction * root_true_goto = new Instruction(ir::Operand(root->v,root->t),
                                ir::Operand(),
                                ir::Operand("2",Type::IntLiteral),ir::Operator::_goto);
            Instruction * root_true_assign = new Instruction(ir::Operand("1",Type::IntLiteral),
                                            ir::Operand(),
                                            ir::Operand(tmp_cal_name,ir::Type::Int),ir::Operator::mov);

            // 假逻辑: 跳转PC+(1+2)
            Instruction * root_false_goto = new Instruction(ir::Operand(),
                                ir::Operand(),
                                ir::Operand("3",Type::IntLiteral),ir::Operator::_goto);

            // 假逻辑中需要使用的or指令
            Instruction * calInst = new Instruction(ir::Operand(root->v,root->t),
                                ir::Operand(lorexp->v,lorexp->t),
                                ir::Operand(tmp_cal_name,ir::Type::Int),ir::Operator::_or);
            cal_insts.push_back(calInst);

            Instruction * true_logic_goto = new Instruction(ir::Operand(),
                                            ir::Operand(),
                                            ir::Operand(std::to_string(cal_insts.size()+1),Type::IntLiteral),ir::Operator::_goto);

            result.push_back(root_true_goto);
            result.push_back(root_false_goto);
            result.push_back(root_true_assign);
            result.push_back(true_logic_goto);
            result.insert(result.end(),cal_insts.begin(),cal_insts.end());

            root->v = tmp_cal_name;
            root->t = Type::Int;
        }
        
        return result;
    }
}

vector<ir::Instruction *> frontend::Analyzer::calculate_landexp(LAndExp* root)
{
    // 注意! LOrExp与LAndExp不需要同类型!!!!!
    vector<ir::Instruction *> result;

    EqExp* eqexp = dynamic_cast<EqExp*>(root->children[0]);
    assert(eqexp);
    vector<ir::Instruction *> cal_insts = calculate_eqexp(eqexp);
    result.insert(result.end(),cal_insts.begin(),cal_insts.end());
    root->v = eqexp->v;
    root->t = eqexp->t;
    if (root->children.size() == 1)
    {
        return result;
    }
    else
    {
        LAndExp* landexp = dynamic_cast<LAndExp*>(root->children[2]);
        assert(landexp);
        vector<ir::Instruction *> cal_insts = calculate_landexp(landexp); // 并不立即加入到result中, 在确定跳转后再加入
        // 处理操作数1 (计算其是否为真 or 假)
        if (root->t == Type::Float)
        {
            string tmp_name = "t";
            tmp_name += std::to_string(tmp_cnt++);
            ir::Instruction* cvtInst = new ir::Instruction(ir::Operand(root->v,Type::Float),
                                    ir::Operand("0.0",Type::FloatLiteral),
                                    ir::Operand(tmp_name,Type::Int),ir::Operator::fneq);
            result.push_back(cvtInst);
            root->v = tmp_name;
            root->t = Type::Int;
        }
        else if (root->t == Type::FloatLiteral)
        {
            float val = std::stof(root->v);
            root->t = Type::IntLiteral;
            root->v = std::to_string(val != 0);
        }

        // 处理操作数2 (计算其是否为真 or 假)
        if (landexp->t == Type::Float)
        {
            string tmp_name = "t";
            tmp_name += std::to_string(tmp_cnt++);
            ir::Instruction* cvtInst = new ir::Instruction(ir::Operand(landexp->v,Type::Float),
                                    ir::Operand("0.0",Type::FloatLiteral),
                                    ir::Operand(tmp_name,Type::Int),ir::Operator::fneq);
            cal_insts.push_back(cvtInst);
            landexp->v = tmp_name;
            landexp->t = Type::Int;
        }
        else if (landexp->t == Type::FloatLiteral)
        {
            float val = std::stof(landexp->v);
            landexp->t = Type::IntLiteral;
            landexp->v = std::to_string(val != 0);
        }

        // 开始计算
        if (root->t == Type::IntLiteral && landexp->t == Type::IntLiteral)
        {
            root->v = std::to_string(std::stoi(root->v) && std::stoi(landexp->v));
        }
        else
        {
            // 注意短路规则: 左侧为假, 则不计算右侧
            string tmp_cal_name = "t";
            tmp_cal_name += std::to_string(tmp_cnt++);
            Instruction * root_true_goto = new Instruction(ir::Operand(root->v,root->t),
                                ir::Operand(),
                                ir::Operand("2",Type::IntLiteral),ir::Operator::_goto);
            result.push_back(root_true_goto);
            // 真逻辑部分, 此时不短路, 开始计算右侧, 并赋值
            vector<Instruction *> true_logic_inst = cal_insts;
            Instruction * calInst = new Instruction(ir::Operand(root->v,root->t),
                                ir::Operand(landexp->v,landexp->t),
                                ir::Operand(tmp_cal_name,ir::Type::Int),ir::Operator::_and);
            true_logic_inst.push_back(calInst);
            // 真逻辑结束后, 需跳出假逻辑部分
            Instruction * true_logic_goto = new Instruction(ir::Operand(),
                                ir::Operand(),
                                ir::Operand("2",Type::IntLiteral),ir::Operator::_goto);
            true_logic_inst.push_back(true_logic_goto);
            // 如果root为假, 则不进行右侧计算, 直接跳转出结束
            Instruction * root_false_goto = new Instruction(ir::Operand(),
                                ir::Operand(),
                                ir::Operand(std::to_string(true_logic_inst.size()+1),Type::IntLiteral),ir::Operator::_goto);
            // root为假时, tmp_cal_name为0
            Instruction * root_false_assign = new Instruction(ir::Operand("0",Type::IntLiteral),
                                ir::Operand(),
                                ir::Operand(tmp_cal_name,ir::Type::Int),ir::Operator::mov);
            result.push_back(root_false_goto);
            result.insert(result.end(),true_logic_inst.begin(),true_logic_inst.end());
            result.push_back(root_false_assign);
            root->v = tmp_cal_name;
            root->t = Type::Int;
        }
        
        return result;
    }
}

vector<ir::Instruction *> frontend::Analyzer::calculate_eqexp(EqExp* root)
{
    // 可能的类型: Int or IntLiteral or Float or FloatLiteral (Float or FloatLiteral: 仅有一个RelExp, 不进行关系运算)

    // 类似RelExp与MulExp, 需要将所有参与计算的值统一才可以进行计算
    vector<Instruction *> result;

    // 复用代码

    // 深度优先遍历, 先计算其所有子RelExp
    for (int i = 0; i < root->children.size(); i += 2)
    {
        RelExp *relexp = dynamic_cast<RelExp *>(root->children[i]);
        assert(relexp);
        vector<Instruction *> cal_insts = calculate_relexp(relexp);
        result.insert(result.end(),cal_insts.begin(),cal_insts.end());
    }

    // 计算表达式的结果
    // 默认为第一个RelExp的值
    RelExp* firstRelExp = dynamic_cast<RelExp*>(root->children[0]);
    assert(firstRelExp);
    root->t = firstRelExp->t;
    root->v = firstRelExp->v;

    if (root->children.size() == 1)
    {
        // 结果只有一个时，无视类型提升
        return result;
    }

    // 开始计算

    // 将第一个RelExp的值进行类型转换没有意义, 在多个RelExp运算的情况下, 始终会变为Int or IntLiteral

    // 开始对2,4,6等进行计算
    for (int i = 2; i < root->children.size(); i += 2)
    {
        // 注意，此时root->t可能与RelExp不同
        RelExp *relexp = dynamic_cast<RelExp *>(root->children[i]);

        // 符号
        Term* op_term  = dynamic_cast<Term*>(root->children[i-1]);

        Type target_type = root->t;

        // 在计算之前，先将两个操作数的类型变为相同的
        // 复用之前第一个MulExp大部分类型提升的代码,是不是写在一起有点重复？
        if (root->t != relexp->t)
        {
            // 确定类型提升
            if (relexp->t == ir::Type::Float)
                target_type = ir::Type::Float;
            else if (relexp->t == ir::Type::Int && target_type == ir::Type::IntLiteral)
                target_type = ir::Type::Int;
            else if (relexp->t == ir::Type::FloatLiteral && target_type == ir::Type::IntLiteral)
                target_type = ir::Type::FloatLiteral;
            else if ((relexp->t == ir::Type::FloatLiteral && target_type == ir::Type::Int) || (target_type == ir::Type::FloatLiteral && relexp->t == ir::Type::Int)) // 提升没有顺序
                target_type = ir::Type::Float;
            
            // 执行类型转换
            if (target_type == Type::Int) // IntLiteral -> Int
            {
                if (relexp->t == Type::IntLiteral)
                {
                    string tmp_intcvt_name = "t";
                    tmp_intcvt_name += std::to_string(tmp_cnt++);
                    Instruction * cvtInst = new Instruction(ir::Operand(relexp->v,ir::Type::IntLiteral),
                                            ir::Operand(),
                                            ir::Operand(tmp_intcvt_name,ir::Type::Int),ir::Operator::def);
                    result.push_back(cvtInst);
                    relexp->v = tmp_intcvt_name;
                    relexp->t = Type::Int;
                }
                if (root->t == Type::IntLiteral)
                {
                    string tmp_intcvt_name = "t";
                    tmp_intcvt_name += std::to_string(tmp_cnt++);
                    Instruction * cvtInst = new Instruction(ir::Operand(root->v,ir::Type::IntLiteral),
                                            ir::Operand(),
                                            ir::Operand(tmp_intcvt_name,ir::Type::Int),ir::Operator::def);
                    result.push_back(cvtInst);
                    root->v = tmp_intcvt_name;
                    root->t = Type::Int;
                }
            }
            else if (target_type == Type::FloatLiteral) // IntLiteral -> FloatLiteral
            {
                if (relexp->t == Type::IntLiteral)
                {
                    float val = std::stoi(relexp->v);
                    relexp->v = std::to_string(val);
                    relexp->t = Type::FloatLiteral;
                }
                if (root->t == Type::IntLiteral)
                {
                    float val = std::stoi(root->v);
                    root->v = std::to_string(val);
                    root->t = Type::FloatLiteral;
                }
            }
            else if (target_type == Type::Float) // IntLiteral -> Float, Int -> Float, FloatLiteral -> Float
            {
                if (relexp->t == Type::IntLiteral)
                {
                    float val = std::stof(relexp->v);
                    string tmp_intcvt_name = "t";
                    tmp_intcvt_name += std::to_string(tmp_cnt++);
                    Instruction * cvtInst = new Instruction(ir::Operand(std::to_string(val),ir::Type::FloatLiteral),
                                        ir::Operand(),
                                        ir::Operand(tmp_intcvt_name,ir::Type::Float),ir::Operator::fdef);
                    result.push_back(cvtInst);
                    relexp->v = tmp_intcvt_name;
                    relexp->t = Type::Float;
                }
                if (relexp->t == Type::Int)
                {
                    string tmp_intcvt_name = "t";
                    tmp_intcvt_name += std::to_string(tmp_cnt++);
                    Instruction * cvtInst = new Instruction(ir::Operand(relexp->v,ir::Type::Int),
                                        ir::Operand(),
                                        ir::Operand(tmp_intcvt_name,ir::Type::Float),ir::Operator::cvt_i2f);
                    result.push_back(cvtInst);
                    relexp->v = tmp_intcvt_name;
                    relexp->t = Type::Float; 
                }
                if (relexp->t == Type::FloatLiteral)
                {
                    string tmp_floatcvt_name = "t";
                    tmp_floatcvt_name += std::to_string(tmp_cnt++);
                    Instruction * cvtInst = new Instruction(ir::Operand(relexp->v,ir::Type::FloatLiteral),
                                        ir::Operand(),
                                        ir::Operand(tmp_floatcvt_name,ir::Type::Float),ir::Operator::fdef);
                    result.push_back(cvtInst);
                    relexp->v = tmp_floatcvt_name;
                    relexp->t = Type::Float;
                }
                if (root->t == Type::IntLiteral)
                {
                    float val = std::stof(root->v);
                    string tmp_intcvt_name = "t";
                    tmp_intcvt_name += std::to_string(tmp_cnt++);
                    Instruction * cvtInst = new Instruction(ir::Operand(std::to_string(val),ir::Type::FloatLiteral),
                                        ir::Operand(),
                                        ir::Operand(tmp_intcvt_name,ir::Type::Float),ir::Operator::fdef);
                    result.push_back(cvtInst);
                    root->v = tmp_intcvt_name;
                    root->t = Type::Float;
                }
                if (root->t == Type::Int)
                {
                    string tmp_intcvt_name = "t";
                    tmp_intcvt_name += std::to_string(tmp_cnt++);
                    Instruction * cvtInst = new Instruction(ir::Operand(root->v,ir::Type::Int),
                                        ir::Operand(),
                                        ir::Operand(tmp_intcvt_name,ir::Type::Float),ir::Operator::cvt_i2f);
                    result.push_back(cvtInst);
                    root->v = tmp_intcvt_name;
                    root->t = Type::Float; 
                }
                if (root->t == Type::FloatLiteral)
                {
                    string tmp_floatcvt_name = "t";
                    tmp_floatcvt_name += std::to_string(tmp_cnt++);
                    Instruction * cvtInst = new Instruction(ir::Operand(root->v,ir::Type::FloatLiteral),
                                        ir::Operand(),
                                        ir::Operand(tmp_floatcvt_name,ir::Type::Float),ir::Operator::fdef);
                    result.push_back(cvtInst);
                    root->v = tmp_floatcvt_name;
                    root->t = Type::Float;
                }
            }
            else
                assert(0 && "Error");
        }
        // 已经化为相同类型
        // 开始计算
        if (target_type == Type::IntLiteral)
        {
            // 在编译期确定结果
            int val1 = std::stoi(root->v);
            int val2 = std::stoi(relexp->v);
            if (op_term->token.type == TokenType::EQL)
                root->v = std::to_string(val1 == val2);
            else if (op_term->token.type == TokenType::NEQ)
                root->v = std::to_string(val1 != val2);
            else
                assert(0 && "Invalid Op");
        }
        else if (target_type == Type::FloatLiteral)
        {
            // 在编译期确定结果
            float val1 = std::stof(root->v);
            float val2 = std::stof(relexp->v);
            if (op_term->token.type == TokenType::EQL)
                root->v = std::to_string(val1 == val2);
            else if (op_term->token.type == TokenType::NEQ)
                root->v = std::to_string(val1 != val2);
            else
                assert(0 && "Invalid Op");
            
            root->t = Type::IntLiteral;
        }
        else if (target_type == Type::Int)
        {
            // 无法在编译期确定结果, 生成指令
            string tmp_cal_name = "t";
            tmp_cal_name += std::to_string(tmp_cnt++);
            Instruction * calInst;
            if (op_term->token.type == TokenType::EQL)
                calInst = new Instruction(ir::Operand(root->v,ir::Type::Int),
                                ir::Operand(relexp->v,ir::Type::Int),
                                ir::Operand(tmp_cal_name,ir::Type::Int),ir::Operator::eq);
            else if (op_term->token.type == TokenType::NEQ)
                calInst = new Instruction(ir::Operand(root->v,ir::Type::Int),
                                ir::Operand(relexp->v,ir::Type::Int),
                                ir::Operand(tmp_cal_name,ir::Type::Int),ir::Operator::neq);
            else
                assert(0 && "Invalid Op");
            result.push_back(calInst);
            root->v = tmp_cal_name;
            root->t = Type::Int;
        }
        else if (target_type == Type::Float)
        {
            // 无法在编译期确定结果, 生成指令
            string tmp_cal_name = "t";
            tmp_cal_name += std::to_string(tmp_cnt++);
            Instruction * calInst;
            if (op_term->token.type == TokenType::LSS)
                calInst = new Instruction(ir::Operand(root->v,ir::Type::Float),
                                ir::Operand(relexp->v,ir::Type::Float),
                                ir::Operand(tmp_cal_name,ir::Type::Float),ir::Operator::feq);
            else if (op_term->token.type == TokenType::GTR)
                calInst = new Instruction(ir::Operand(root->v,ir::Type::Float),
                                ir::Operand(relexp->v,ir::Type::Float),
                                ir::Operand(tmp_cal_name,ir::Type::Float),ir::Operator::fneq);
            else
                assert(0 && "Invalid Op");
            result.push_back(calInst);
            root->v = tmp_cal_name;
            root->t = Type::Float;
        }
        else
            assert(0 && "Error");
    }

    return result;

}

vector<ir::Instruction *> frontend::Analyzer::calculate_relexp(RelExp* root)
{
    // 可能的类型: Int or IntLiteral or Float or FloatLiteral (Float or FloatLiteral: 仅有一个AddExp, 不进行关系运算)

    // 类似AddExp与MulExp, 需要将所有参与计算的值统一才可以进行计算
    vector<Instruction *> result;

    // 复用代码

    // 深度优先遍历, 先计算其所有子AddExp
    for (int i = 0; i < root->children.size(); i += 2)
    {
        AddExp *addexp = dynamic_cast<AddExp *>(root->children[i]);
        assert(addexp);
        vector<Instruction *> cal_insts = calculate_addexp(addexp);
        result.insert(result.end(),cal_insts.begin(),cal_insts.end());
    }

    // 计算表达式的结果
    // 默认为第一个AddExp的值
    AddExp* firstAddExp = dynamic_cast<AddExp*>(root->children[0]);
    assert(firstAddExp);
    root->t = firstAddExp->t;
    root->v = firstAddExp->v;

    if (root->children.size() == 1)
    {
        // 结果只有一个时，无视类型提升
        return result;
    }

    // 开始计算

    // 将第一个AddExp的值进行类型转换没有意义, 在多个AddExp运算的情况下, 始终会变为Int or IntLiteral

    // 开始对2,4,6等进行计算
    for (int i = 2; i < root->children.size(); i += 2)
    {
        // 注意，此时root->t可能与AddExp不同
        AddExp *addexp = dynamic_cast<AddExp *>(root->children[i]);

        // 符号
        Term* op_term  = dynamic_cast<Term*>(root->children[i-1]);

        Type target_type = root->t;

        // 在计算之前，先将两个操作数的类型变为相同的
        // 复用之前第一个MulExp大部分类型提升的代码,是不是写在一起有点重复？
        if (root->t != addexp->t)
        {
            // 确定类型提升
            if (addexp->t == ir::Type::Float)
                target_type = ir::Type::Float;
            else if (addexp->t == ir::Type::Int && target_type == ir::Type::IntLiteral)
                target_type = ir::Type::Int;
            else if (addexp->t == ir::Type::FloatLiteral && target_type == ir::Type::IntLiteral)
                target_type = ir::Type::FloatLiteral;
            else if ((addexp->t == ir::Type::FloatLiteral && target_type == ir::Type::Int) || (target_type == ir::Type::FloatLiteral && addexp->t == ir::Type::Int)) // 提升没有顺序
                target_type = ir::Type::Float;
            
            // 执行类型转换
            if (target_type == Type::Int) // IntLiteral -> Int
            {
                if (addexp->t == Type::IntLiteral)
                {
                    string tmp_intcvt_name = "t";
                    tmp_intcvt_name += std::to_string(tmp_cnt++);
                    Instruction * cvtInst = new Instruction(ir::Operand(addexp->v,ir::Type::IntLiteral),
                                            ir::Operand(),
                                            ir::Operand(tmp_intcvt_name,ir::Type::Int),ir::Operator::def);
                    result.push_back(cvtInst);
                    addexp->v = tmp_intcvt_name;
                    addexp->t = Type::Int;
                }
                if (root->t == Type::IntLiteral)
                {
                    string tmp_intcvt_name = "t";
                    tmp_intcvt_name += std::to_string(tmp_cnt++);
                    Instruction * cvtInst = new Instruction(ir::Operand(root->v,ir::Type::IntLiteral),
                                            ir::Operand(),
                                            ir::Operand(tmp_intcvt_name,ir::Type::Int),ir::Operator::def);
                    result.push_back(cvtInst);
                    root->v = tmp_intcvt_name;
                    root->t = Type::Int;
                }
            }
            else if (target_type == Type::FloatLiteral) // IntLiteral -> FloatLiteral
            {
                if (addexp->t == Type::IntLiteral)
                {
                    float val = std::stoi(addexp->v);
                    addexp->v = std::to_string(val);
                    addexp->t = Type::FloatLiteral;
                }
                if (root->t == Type::IntLiteral)
                {
                    float val = std::stoi(root->v);
                    root->v = std::to_string(val);
                    root->t = Type::FloatLiteral;
                }
            }
            else if (target_type == Type::Float) // IntLiteral -> Float, Int -> Float, FloatLiteral -> Float
            {
                if (addexp->t == Type::IntLiteral)
                {
                    float val = std::stof(addexp->v);
                    string tmp_intcvt_name = "t";
                    tmp_intcvt_name += std::to_string(tmp_cnt++);
                    Instruction * cvtInst = new Instruction(ir::Operand(std::to_string(val),ir::Type::FloatLiteral),
                                        ir::Operand(),
                                        ir::Operand(tmp_intcvt_name,ir::Type::Float),ir::Operator::fdef);
                    result.push_back(cvtInst);
                    addexp->v = tmp_intcvt_name;
                    addexp->t = Type::Float;
                }
                if (addexp->t == Type::Int)
                {
                    string tmp_intcvt_name = "t";
                    tmp_intcvt_name += std::to_string(tmp_cnt++);
                    Instruction * cvtInst = new Instruction(ir::Operand(addexp->v,ir::Type::Int),
                                        ir::Operand(),
                                        ir::Operand(tmp_intcvt_name,ir::Type::Float),ir::Operator::cvt_i2f);
                    result.push_back(cvtInst);
                    addexp->v = tmp_intcvt_name;
                    addexp->t = Type::Float; 
                }
                if (addexp->t == Type::FloatLiteral)
                {
                    string tmp_floatcvt_name = "t";
                    tmp_floatcvt_name += std::to_string(tmp_cnt++);
                    Instruction * cvtInst = new Instruction(ir::Operand(addexp->v,ir::Type::FloatLiteral),
                                        ir::Operand(),
                                        ir::Operand(tmp_floatcvt_name,ir::Type::Float),ir::Operator::fdef);
                    result.push_back(cvtInst);
                    addexp->v = tmp_floatcvt_name;
                    addexp->t = Type::Float;
                }
                if (root->t == Type::IntLiteral)
                {
                    float val = std::stof(root->v);
                    string tmp_intcvt_name = "t";
                    tmp_intcvt_name += std::to_string(tmp_cnt++);
                    Instruction * cvtInst = new Instruction(ir::Operand(std::to_string(val),ir::Type::FloatLiteral),
                                        ir::Operand(),
                                        ir::Operand(tmp_intcvt_name,ir::Type::Float),ir::Operator::fdef);
                    result.push_back(cvtInst);
                    root->v = tmp_intcvt_name;
                    root->t = Type::Float;
                }
                if (root->t == Type::Int)
                {
                    string tmp_intcvt_name = "t";
                    tmp_intcvt_name += std::to_string(tmp_cnt++);
                    Instruction * cvtInst = new Instruction(ir::Operand(root->v,ir::Type::Int),
                                        ir::Operand(),
                                        ir::Operand(tmp_intcvt_name,ir::Type::Float),ir::Operator::cvt_i2f);
                    result.push_back(cvtInst);
                    root->v = tmp_intcvt_name;
                    root->t = Type::Float; 
                }
                if (root->t == Type::FloatLiteral)
                {
                    string tmp_floatcvt_name = "t";
                    tmp_floatcvt_name += std::to_string(tmp_cnt++);
                    Instruction * cvtInst = new Instruction(ir::Operand(root->v,ir::Type::FloatLiteral),
                                        ir::Operand(),
                                        ir::Operand(tmp_floatcvt_name,ir::Type::Float),ir::Operator::fdef);
                    result.push_back(cvtInst);
                    root->v = tmp_floatcvt_name;
                    root->t = Type::Float;
                }
            }
            else
                assert(0 && "Error");
        }
        // 已经化为相同类型
        // 开始计算
        if (target_type == Type::IntLiteral)
        {
            // 在编译期确定结果
            int val1 = std::stoi(root->v);
            int val2 = std::stoi(addexp->v);
            if (op_term->token.type == TokenType::LSS)
                root->v = std::to_string(val1 < val2);
            else if (op_term->token.type == TokenType::GTR)
                root->v = std::to_string(val1 > val2);
            else if (op_term->token.type == TokenType::LEQ)
                root->v = std::to_string(val1 <= val2);
            else if (op_term->token.type == TokenType::GEQ)
                root->v = std::to_string(val1 >= val2);
            else
                assert(0 && "Invalid Op");
        }
        else if (target_type == Type::FloatLiteral)
        {
            // 在编译期确定结果
            float val1 = std::stof(root->v);
            float val2 = std::stof(addexp->v);
            if (op_term->token.type == TokenType::LSS)
                root->v = std::to_string(val1 < val2);
            else if (op_term->token.type == TokenType::GTR)
                root->v = std::to_string(val1 > val2);
            else if (op_term->token.type == TokenType::LEQ)
                root->v = std::to_string(val1 <= val2);
            else if (op_term->token.type == TokenType::GEQ)
                root->v = std::to_string(val1 >= val2);
            else
                assert(0 && "Invalid Op");
            
            root->t = Type::IntLiteral;
        }
        else if (target_type == Type::Int)
        {
            // 无法在编译期确定结果, 生成指令
            string tmp_cal_name = "t";
            tmp_cal_name += std::to_string(tmp_cnt++);
            Instruction * calInst;
            if (op_term->token.type == TokenType::LSS)
                calInst = new Instruction(ir::Operand(root->v,ir::Type::Int),
                                ir::Operand(addexp->v,ir::Type::Int),
                                ir::Operand(tmp_cal_name,ir::Type::Int),ir::Operator::lss);
            else if (op_term->token.type == TokenType::GTR)
                calInst = new Instruction(ir::Operand(root->v,ir::Type::Int),
                                ir::Operand(addexp->v,ir::Type::Int),
                                ir::Operand(tmp_cal_name,ir::Type::Int),ir::Operator::gtr);
            else if (op_term->token.type == TokenType::LEQ)
                calInst = new Instruction(ir::Operand(root->v,ir::Type::Int),
                                ir::Operand(addexp->v,ir::Type::Int),
                                ir::Operand(tmp_cal_name,ir::Type::Int),ir::Operator::leq);
            else if (op_term->token.type == TokenType::GEQ)
                calInst = new Instruction(ir::Operand(root->v,ir::Type::Int),
                                ir::Operand(addexp->v,ir::Type::Int),
                                ir::Operand(tmp_cal_name,ir::Type::Int),ir::Operator::geq);
            else
                assert(0 && "Invalid Op");
            result.push_back(calInst);
            root->v = tmp_cal_name;
            root->t = Type::Int;
        }
        else if (target_type == Type::Float)
        {
            // 无法在编译期确定结果, 生成指令
            string tmp_cal_name = "t";
            tmp_cal_name += std::to_string(tmp_cnt++);
            Instruction * calInst;
            if (op_term->token.type == TokenType::LSS)
                calInst = new Instruction(ir::Operand(root->v,ir::Type::Float),
                                ir::Operand(addexp->v,ir::Type::Float),
                                ir::Operand(tmp_cal_name,ir::Type::Float),ir::Operator::flss);
            else if (op_term->token.type == TokenType::GTR)
                calInst = new Instruction(ir::Operand(root->v,ir::Type::Float),
                                ir::Operand(addexp->v,ir::Type::Float),
                                ir::Operand(tmp_cal_name,ir::Type::Float),ir::Operator::fgtr);
            else if (op_term->token.type == TokenType::LEQ)
                calInst = new Instruction(ir::Operand(root->v,ir::Type::Float),
                                ir::Operand(addexp->v,ir::Type::Float),
                                ir::Operand(tmp_cal_name,ir::Type::Float),ir::Operator::fleq);
            else if (op_term->token.type == TokenType::GEQ)
                calInst = new Instruction(ir::Operand(root->v,ir::Type::Float),
                                ir::Operand(addexp->v,ir::Type::Float),
                                ir::Operand(tmp_cal_name,ir::Type::Float),ir::Operator::fgeq);
            else
                assert(0 && "Invalid Op");
            result.push_back(calInst);
            root->v = tmp_cal_name;
            root->t = Type::Float;
        }
        else
            assert(0 && "Error");
    }

    return result;
}