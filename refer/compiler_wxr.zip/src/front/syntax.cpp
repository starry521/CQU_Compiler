#include "front/syntax.h"

#include <iostream>
#include <cassert>

using frontend::Parser;

// #define DEBUG_PARSER
#define TODO assert(0 && "todo")
#define CUR_TOKEN_IS(tk_type) (token_stream[index].type == TokenType::tk_type)
#define PARSE_TOKEN(tk_type) root->children.push_back(parseTerm(root, TokenType::tk_type))
#define PARSE(name, type)       \
    auto name = new type(root); \
    assert(parse##type(name));  \
    root->children.push_back(name);

Parser::Parser(const std::vector<frontend::Token> &tokens) : index(0), token_stream(tokens)
{
}

Parser::~Parser() {}

/*
CompUnit -> (Decl | FuncDef) [CompUnit]

Decl -> ConstDecl | VarDecl

ConstDecl -> 'const' BType ConstDef { ',' ConstDef } ';'

BType -> 'int' | 'float'

ConstDef -> Ident { '[' ConstExp ']' } '=' ConstInitVal

ConstInitVal -> ConstExp | '{' [ ConstInitVal { ',' ConstInitVal } ] '}'

VarDecl -> BType VarDef { ',' VarDef } ';'

VarDef -> Ident { '[' ConstExp ']' } [ '=' InitVal ]

InitVal -> Exp | '{' [ InitVal { ',' InitVal } ] '}'

FuncDef -> FuncType Ident '(' [FuncFParams] ')' Block

FuncType -> 'void' | 'int' | 'float'

FuncFParam -> BType Ident ['[' ']' { '[' Exp ']' }]

FuncFParams -> FuncFParam { ',' FuncFParam }

Block -> '{' { BlockItem } '}'

BlockItem -> Decl | Stmt

Stmt -> LVal '=' Exp ';' | Block | 'if' '(' Cond ')' Stmt [ 'else' Stmt ] | 'while' '(' Cond ')' Stmt | 'break' ';' | 'continue' ';' | 'return' [Exp] ';' | [Exp] ';'

Exp -> AddExp

Cond -> LOrExp

LVal -> Ident {'[' Exp ']'}

Number -> IntConst | floatConst

PrimaryExp -> '(' Exp ')' | LVal | Number

UnaryExp -> PrimaryExp | Ident '(' [FuncRParams] ')' | UnaryOp UnaryExp

UnaryOp -> '+' | '-' | '!'

FuncRParams -> Exp { ',' Exp }

MulExp -> UnaryExp { ('*' | '/' | '%') UnaryExp }

AddExp -> MulExp { ('+' | '-') MulExp }

RelExp -> AddExp { ('<' | '>' | '<=' | '>=') AddExp }

EqExp -> RelExp { ('==' | '!=') RelExp }

LAndExp -> EqExp [ '&&' LAndExp ]

LOrExp -> LAndExp [ '||' LOrExp ]

ConstExp -> AddExp
*/

std::unordered_set<frontend::TokenType> Parser::get_first_Compunit()
{
    auto first_decl = get_first_Decl();
    auto first_funcdef = get_first_FuncDef();
    first_decl.insert(first_funcdef.begin(), first_funcdef.end());
    return first_decl;
}

std::unordered_set<frontend::TokenType> Parser::get_first_Decl()
{
    auto first_constdecl = get_first_ConstDecl();
    auto first_vardecl = get_first_VarDecl();
    first_constdecl.insert(first_vardecl.begin(), first_vardecl.end());
    return first_constdecl;
}

std::unordered_set<frontend::TokenType> Parser::get_first_ConstDecl()
{
    return {frontend::TokenType::CONSTTK};
}

std::unordered_set<frontend::TokenType> Parser::get_first_BType()
{
    return {frontend::TokenType::INTTK, frontend::TokenType::FLOATTK};
}

std::unordered_set<frontend::TokenType> Parser::get_first_ConstDef()
{
    return {frontend::TokenType::IDENFR};
}

std::unordered_set<frontend::TokenType> Parser::get_first_ConstInitVal()
{
    auto first_constexp = get_first_ConstExp();
    first_constexp.insert(frontend::TokenType::LBRACE);
    return first_constexp;
}

std::unordered_set<frontend::TokenType> Parser::get_first_VarDecl()
{
    return get_first_BType();
}

std::unordered_set<frontend::TokenType> Parser::get_first_VarDef()
{
    return {frontend::TokenType::IDENFR};
}

std::unordered_set<frontend::TokenType> Parser::get_first_InitVal()
{
    auto first_exp = get_first_Exp();
    first_exp.insert(frontend::TokenType::LBRACE);
    return first_exp;
}

std::unordered_set<frontend::TokenType> Parser::get_first_FuncDef()
{
    return get_first_FuncType();
}

std::unordered_set<frontend::TokenType> Parser::get_first_FuncType()
{
    return {frontend::TokenType::VOIDTK, frontend::TokenType::INTTK, frontend::TokenType::FLOATTK};
}

std::unordered_set<frontend::TokenType> Parser::get_first_FuncFParam()
{
    return get_first_BType();
}

std::unordered_set<frontend::TokenType> Parser::get_first_FuncFParams()
{
    return get_first_FuncFParam();
}

std::unordered_set<frontend::TokenType> Parser::get_first_Block()
{
    return {frontend::TokenType::LBRACE};
}

std::unordered_set<frontend::TokenType> Parser::get_first_BlockItem()
{
    auto first_decl = get_first_Decl();
    auto first_stmt = get_first_Stmt();
    first_decl.insert(first_stmt.begin(), first_stmt.end());
    return first_decl;
}

std::unordered_set<frontend::TokenType> Parser::get_first_Stmt()
{
    // Stmt -> LVal '=' Exp ';' | Block | 'if' '(' Cond ')' Stmt [ 'else' Stmt ] | 'while' '(' Cond ')' Stmt | 'break' ';' | 'continue' ';' | 'return' [Exp] ';' | [Exp] ';'
    auto first_lval = get_first_LVal();
    auto first_block = get_first_Block();
    first_lval.insert(first_block.begin(), first_block.end());
    first_lval.insert(frontend::TokenType::IFTK);
    first_lval.insert(frontend::TokenType::WHILETK);
    first_lval.insert(frontend::TokenType::BREAKTK);
    first_lval.insert(frontend::TokenType::CONTINUETK);
    first_lval.insert(frontend::TokenType::RETURNTK);
    auto first_exp = get_first_Exp();
    first_lval.insert(first_exp.begin(), first_exp.end());
    first_lval.insert(frontend::TokenType::SEMICN);
    return first_lval;
}

std::unordered_set<frontend::TokenType> Parser::get_first_Exp()
{
    return get_first_AddExp();
}

std::unordered_set<frontend::TokenType> Parser::get_first_Cond()
{
    return get_first_LOrExp();
}

std::unordered_set<frontend::TokenType> Parser::get_first_LVal()
{
    return {frontend::TokenType::IDENFR};
}

std::unordered_set<frontend::TokenType> Parser::get_first_Number()
{
    return {frontend::TokenType::INTLTR, frontend::TokenType::FLOATLTR};
}

std::unordered_set<frontend::TokenType> Parser::get_first_PrimaryExp()
{
    auto first_lval = get_first_LVal();
    auto first_number = get_first_Number();
    first_lval.insert(first_number.begin(), first_number.end());
    first_lval.insert(frontend::TokenType::LPARENT);
    return first_lval;
}

std::unordered_set<frontend::TokenType> Parser::get_first_UnaryExp()
{
    auto first_primaryexp = get_first_PrimaryExp();
    first_primaryexp.insert(frontend::TokenType::IDENFR);
    auto first_unaryop = get_first_UnaryOp();
    first_primaryexp.insert(first_unaryop.begin(), first_unaryop.end());
    return first_primaryexp;
}

std::unordered_set<frontend::TokenType> Parser::get_first_UnaryOp()
{
    return {frontend::TokenType::PLUS, frontend::TokenType::MINU, frontend::TokenType::NOT};
}

std::unordered_set<frontend::TokenType> Parser::get_first_FuncRParams()
{
    return get_first_Exp();
}

std::unordered_set<frontend::TokenType> Parser::get_first_MulExp()
{
    return get_first_UnaryExp();
}

std::unordered_set<frontend::TokenType> Parser::get_first_AddExp()
{
    return get_first_MulExp();
}

std::unordered_set<frontend::TokenType> Parser::get_first_RelExp()
{
    return get_first_AddExp();
}

std::unordered_set<frontend::TokenType> Parser::get_first_EqExp()
{
    return get_first_RelExp();
}

std::unordered_set<frontend::TokenType> Parser::get_first_LAndExp()
{
    return get_first_EqExp();
}

std::unordered_set<frontend::TokenType> Parser::get_first_LOrExp()
{
    return get_first_LAndExp();
}

std::unordered_set<frontend::TokenType> Parser::get_first_ConstExp()
{
    return get_first_AddExp();
}

frontend::CompUnit *Parser::get_abstract_syntax_tree()
{
    return parseCompUnit(nullptr);
}

void Parser::revert(int saved_index, AstNode *curr_result, int target_child_nums)
{
    index = saved_index;
    while (int(curr_result->children.size()) > target_child_nums)
    {
        // delete curr_result->children.back();
        curr_result->children.pop_back();
    }
}

// CompUnit -> (Decl | FuncDef) [CompUnit]
frontend::CompUnit *Parser::parseCompUnit(AstNode *parent)
{
    level++;
    CompUnit *result = new CompUnit(parent);

    log(result);

    bool decl_success = false;
    bool funcdef_success = false;

    int saved_index = index;
    int target_child_nums = result->children.size();

    // 分支Decl | FuncDef
    if (get_first_Decl().count(token_stream[index].type))
    {
        decl_success = parseDecl(result);
        if (!decl_success)
        {
            revert(saved_index, result, target_child_nums);
        }
    }
    if (!decl_success && get_first_FuncDef().count(token_stream[index].type))
    {
        funcdef_success = parseFuncDef(result);
    }

    if (!decl_success && !funcdef_success)
    {
        // error
        assert(0 && "error in parseCompUnit");
    }
    // 可选CompUnit
    if (get_first_Compunit().count(token_stream[index].type))
    {
        parseCompUnit(result);
    }
    level--;
    return result;
}

// Decl -> ConstDecl | VarDecl
bool Parser::parseDecl(AstNode *parent)
{
    level++;
    Decl *result = new Decl(parent);

    log(result);

    bool constdecl_success = false;
    bool vardecl_success = false;

    int saved_index = index;
    int target_child_nums = result->children.size();

    // 分支ConstDecl | VarDecl
    if (get_first_ConstDecl().count(token_stream[index].type))
    {
        constdecl_success = parseConstDecl(result);
        if (!constdecl_success)
        {
            revert(saved_index, result, target_child_nums);
        }
    }
    if (!constdecl_success && get_first_VarDecl().count(token_stream[index].type))
    {
        vardecl_success = parseVarDecl(result);
    }

    level--;

    if (!constdecl_success && !vardecl_success)
    {
        // error
        return false;
    }
    return true;
}

// ConstDecl -> 'const' BType ConstDef { ',' ConstDef } ';'
bool Parser::parseConstDecl(AstNode *parent)
{
    level++;
    ConstDecl *result = new ConstDecl(parent);
    log(result);
    // 'const' BType ConstDef {',' ConstDef} ';'
    // 'const'
    if (token_stream[index].type != frontend::TokenType::CONSTTK)
    {
        level--;
        return false;
    }
    new Term(token_stream[index++], result);

    if (!parseBType(result))
    {
        level--;
        return false;
    }
    if (!parseConstDef(result))
    {
        level--;
        return false;
    }
    // 0~n次 ',' ConstDef
    while (token_stream[index].type == frontend::TokenType::COMMA)
    {
        new Term(token_stream[index++], result);
        if (!parseConstDef(result))
        {
            level--;
            return false;
        }
    }
    // ';'
    if (token_stream[index].type != frontend::TokenType::SEMICN)
    {
        level--;
        return false;
    }
    new Term(token_stream[index++], result);
    level--;
    return true;
}

// BType -> 'int' | 'float'
bool Parser::parseBType(AstNode *parent)
{
    level++;
    BType *result = new BType(parent);
    log(result);
    // 分支Int | Float
    if (token_stream[index].type == frontend::TokenType::INTTK)
    {
        new Term(token_stream[index++], result);
    }
    else if (token_stream[index].type == frontend::TokenType::FLOATTK)
    {
        new Term(token_stream[index++], result);
    }
    else
    {
        // error
        level--;
        return false;
    }
    level--;
    return true;
}

// ConstDef -> Ident { '[' ConstExp ']' } '=' ConstInitVal
bool Parser::parseConstDef(AstNode *parent)
{
    level++;
    ConstDef *result = new ConstDef(parent);
    log(result);
    // Ident
    if (token_stream[index].type != frontend::TokenType::IDENFR)
    {
        level--;
        return false;
    }
    new Term(token_stream[index++], result);
    // 0~n次 '[' ConstExp ']'
    while (token_stream[index].type == frontend::TokenType::LBRACK)
    {
        new Term(token_stream[index++], result);
        if (!parseConstExp(result))
        {
            level--;
            return false;
        }
        if (token_stream[index].type != frontend::TokenType::RBRACK)
        {
            level--;
            return false;
        }
        new Term(token_stream[index++], result);
    }
    // '='
    if (token_stream[index].type != frontend::TokenType::ASSIGN)
    {
        level--;
        return false;
    }
    new Term(token_stream[index++], result);
    // ConstInitVal
    if (!parseConstInitVal(result))
    {
        level--;
        return false;
    }
    level--;
    return true;
}

// ConstInitVal -> ConstExp | '{' [ ConstInitVal { ',' ConstInitVal } ] '}'
bool Parser::parseConstInitVal(AstNode *parent)
{
    level++;
    ConstInitVal *result = new ConstInitVal(parent);
    log(result);

    bool constexp_success = false;
    bool lbrace_success = false;

    int saved_index = index;
    int target_child_nums = result->children.size();

    constexp_success = true;
    if (!parseConstExp(result))
    {
        constexp_success = false;
        revert(saved_index, result, target_child_nums);
    }
    // 分支'{' [ ConstInitVal { ',' ConstInitVal } ] '}'
    if (!constexp_success && token_stream[index].type == frontend::TokenType::LBRACE)
    {
        new Term(token_stream[index++], result);
        // 可选ConstInitVal
        if (get_first_ConstInitVal().count(token_stream[index].type))
        {
            if (!parseConstInitVal(result))
            {
                level--;
                return false;
            }
            // 0~n次',' ConstInitVal
            while (token_stream[index].type == frontend::TokenType::COMMA)
            {
                new Term(token_stream[index++], result);
                if (!parseConstInitVal(result))
                {
                    level--;
                    return false;
                }
            }
        }
        if (token_stream[index].type != frontend::TokenType::RBRACE)
        {
            level--;
            return false;
        }
        new Term(token_stream[index++], result);
        lbrace_success = true;
        if (!lbrace_success)
        {
            level--;
            return false;
        }
    }
    if (!constexp_success && !lbrace_success)
    {
        level--;
        return false;
    }
    level--;
    return true;
}

// VarDecl -> BType VarDef { ',' VarDef } ';'
bool Parser::parseVarDecl(AstNode *parent)
{
    level++;
    VarDecl *result = new VarDecl(parent);
    log(result);
    // BType VarDef {',' VarDef} ';'
    if (!parseBType(result))
    {
        level--;
        return false;
    }
    if (!parseVarDef(result))
    {
        level--;
        return false;
    }
    // 0~n次',' VarDef
    while (token_stream[index].type == frontend::TokenType::COMMA)
    {
        new Term(token_stream[index++], result);
        if (!parseVarDef(result))
        {
            level--;
            return false;
        }
    }
    // ';'
    if (token_stream[index].type != frontend::TokenType::SEMICN)
    {
        level--;
        return false;
    }
    new Term(token_stream[index++], result);
    level--;
    return true;
}

// VarDef -> Ident { '[' ConstExp ']' } [ '=' InitVal ]
bool Parser::parseVarDef(AstNode *parent)
{
    level++;
    VarDef *result = new VarDef(parent);
    log(result);
    // Ident
    if (token_stream[index].type != frontend::TokenType::IDENFR)
    {
        level--;
        return false;
    }
    new Term(token_stream[index++], result);
    // 0~n次'[' ConstExp ']'
    while (token_stream[index].type == frontend::TokenType::LBRACK)
    {
        new Term(token_stream[index++], result);
        if (!parseConstExp(result))
        {
            level--;
            return false;
        }
        if (token_stream[index].type != frontend::TokenType::RBRACK)
        {
            level--;
            return false;
        }
        new Term(token_stream[index++], result);
    }
    // 可选'=' VarInitVal
    if (token_stream[index].type == frontend::TokenType::ASSIGN)
    {
        new Term(token_stream[index++], result);
        if (!parseInitVal(result))
        {
            level--;
            return false;
        }
    }
    level--;
    return true;
}

// InitVal -> Exp | '{' [ InitVal { ',' InitVal } ] '}'
bool Parser::parseInitVal(AstNode *parent)
{
    level++;
    auto result = new InitVal(parent);
    log(result);

    bool exp_success = false;
    bool lbrace_success = false;

    int saved_index = index;
    int target_child_nums = result->children.size();

    // Exp | '{'分支
    if (get_first_Exp().count(token_stream[index].type))
    {
        exp_success = parseExp(result);
        if (!exp_success)
        {
            revert(saved_index, result, target_child_nums);
        }
    }
    if (!exp_success && token_stream[index].type == frontend::TokenType::LBRACE)
    {
        new Term(token_stream[index++], result);
        // 可选InitVal
        if (get_first_InitVal().count(token_stream[index].type))
        {
            if (!parseInitVal(result))
            {
                level--;
                return false;
            }
            // 0~n次',' InitVal
            while (token_stream[index].type == frontend::TokenType::COMMA)
            {
                new Term(token_stream[index++], result);
                if (!parseInitVal(result))
                {
                    level--;
                    return false;
                }
            }
        }
        if (token_stream[index].type != frontend::TokenType::RBRACE)
        {
            level--;
            return false;
        }
        new Term(token_stream[index++], result);
        lbrace_success = true;
    }
    if (!lbrace_success && !exp_success)
    {
        // error
        level--;
        return false;
    }
    level--;
    return true;
}

// FuncDef -> FuncType Ident '(' [FuncFParams] ')' Block
bool Parser::parseFuncDef(AstNode *parent)
{
    level++;
    // FuncDef -> FuncType Ident '(' [FuncFParams] ')' Block
    FuncDef *result = new FuncDef(parent);
    log(result);
    if (!parseFuncType(result))
    {
        level--;
        return false;
    }
    if (token_stream[index].type != frontend::TokenType::IDENFR)
    {
        level--;
        return false;
    }
    new Term(token_stream[index++], result);
    if (token_stream[index].type != frontend::TokenType::LPARENT)
    {
        level--;
        return false;
    }
    new Term(token_stream[index++], result);
    if (get_first_FuncFParams().count(token_stream[index].type))
    {
        if (!parseFuncFParams(result))
        {
            level--;
            return false;
        }
    }
    if (token_stream[index].type != frontend::TokenType::RPARENT)
    {
        level--;
        return false;
    }
    new Term(token_stream[index++], result);
    if (!parseBlock(result))
    {
        level--;
        return false;
    }
    level--;
    return true;
}

// FuncType -> 'void' | 'int' | 'float'
bool Parser::parseFuncType(AstNode *parent)
{
    level++;
    FuncType *result = new FuncType(parent);
    log(result);
    if (token_stream[index].type == frontend::TokenType::VOIDTK)
    {
        new Term(token_stream[index++], result);
    }
    else if (token_stream[index].type == frontend::TokenType::INTTK)
    {
        new Term(token_stream[index++], result);
    }
    else if (token_stream[index].type == frontend::TokenType::FLOATTK)
    {
        new Term(token_stream[index++], result);
    }
    else
    {
        // error
        level--;
        return false;
    }
    level--;
    return true;
}

// FuncFParam -> BType Ident ['[' ']' { '[' Exp ']' }]
bool Parser::parseFuncFParam(AstNode *parent)
{
    level++;
    FuncFParam *result = new FuncFParam(parent);
    log(result);
    if (!parseBType(result))
    {
        level--;
        return false;
    }
    if (token_stream[index].type != frontend::TokenType::IDENFR)
    {
        level--;
        return false;
    }
    new Term(token_stream[index++], result);
    // 可选'[' ']'
    if (token_stream[index].type == frontend::TokenType::LBRACK)
    {
        new Term(token_stream[index++], result);
        if (token_stream[index].type != frontend::TokenType::RBRACK)
        {
            level--;
            return false;
        }
        new Term(token_stream[index++], result);
        // 0~n次'[' Exp ']'
        while (token_stream[index].type == frontend::TokenType::LBRACK)
        {
            new Term(token_stream[index++], result);
            if (!parseExp(result))
            {
                level--;
                return false;
            }
            if (token_stream[index].type != frontend::TokenType::RBRACK)
            {
                level--;
                return false;
            }
            new Term(token_stream[index++], result);
        }
    }
    level--;
    return true;
}

// FuncFParams -> FuncFParam { ',' FuncFParam }
bool Parser::parseFuncFParams(AstNode *parent)
{
    level++;
    FuncFParams *result = new FuncFParams(parent);
    log(result);
    if (!parseFuncFParam(result))
    {
        level--;
        return false;
    }
    // 0~n次',' FuncFParam
    while (token_stream[index].type == frontend::TokenType::COMMA)
    {
        new Term(token_stream[index++], result);

        if (!parseFuncFParam(result))
        {
            level--;
            return false;
        }
    }
    level--;
    return true;
}

// Block -> '{' { BlockItem } '}'
bool Parser::parseBlock(AstNode *parent)
{
    level++;
    Block *result = new Block(parent);
    log(result);
    if (token_stream[index].type != frontend::TokenType::LBRACE)
    {
        level--;
        return false;
    }
    new Term(token_stream[index++], result);
    // 0~n次BlockItem
    while (get_first_BlockItem().count(token_stream[index].type))
    {
        bool blockitem_result = parseBlockItem(result);
        printf("BlockItem Result:%d\n", blockitem_result);
        if (!blockitem_result)
        {
            level--;
            return false;
        }
    }
    if (token_stream[index].type != frontend::TokenType::RBRACE)
    {
        level--;
        return false;
    }
    new Term(token_stream[index++], result);
    level--;
    return true;
}

// BlockItem -> Decl | Stmt
bool Parser::parseBlockItem(AstNode *parent)
{
    level++;
    BlockItem *result = new BlockItem(parent);
    log(result);

    bool decl_success = false;
    bool stmt_success = false;

    int saved_index = index;
    int target_child_nums = result->children.size();

    if (get_first_Decl().count(token_stream[index].type))
    {
        decl_success = parseDecl(result);
        if (!decl_success)
        {
            revert(saved_index, result, target_child_nums);
        }
    }
    if (!decl_success && get_first_Stmt().count(token_stream[index].type))
    {
        stmt_success = parseStmt(result);
    }
    if (!decl_success && !stmt_success)
    {
        // error
        level--;
        return false;
    }
    level--;
    return true;
}

// Stmt -> LVal '=' Exp ';' | Block | 'if' '(' Cond ')' Stmt [ 'else' Stmt ] | 'while' '(' Cond ')' Stmt | 'break' ';' | 'continue' ';' | 'return' [Exp] ';' | [Exp] ';'
bool Parser::parseStmt(AstNode *parent)
{
    level++;
    Stmt *result = new Stmt(parent);
    log(result);

    bool lval_success = false;

    int saved_index = index;
    int target_child_nums = result->children.size();

    if (get_first_LVal().count(token_stream[index].type)) // LVal '=' Exp ';'
    {
        lval_success = parseLVal(result);
        if (!lval_success)
            goto parseStmt_lval_fail;
        if (token_stream[index].type != frontend::TokenType::ASSIGN)
            goto parseStmt_lval_fail;
        new Term(token_stream[index++], result);
        if (!parseExp(result))
        {
            goto parseStmt_lval_fail;
        }
        if (token_stream[index].type != frontend::TokenType::SEMICN)
        {
            goto parseStmt_lval_fail;
        }
        new Term(token_stream[index++], result);
        if (!lval_success)
        {
        parseStmt_lval_fail:
            lval_success = false;
            revert(saved_index, result, target_child_nums);
        }
        else
        {
            level--;
            return true;
        }
    }

    bool block_success = false;

    if (!lval_success && get_first_Block().count(token_stream[index].type)) // Block
    {
        block_success = parseBlock(result);
        if (!block_success)
        {
            revert(saved_index, result, target_child_nums);
        }
        else
        {
            level--;
            return true;
        }
    }

    bool keyword_success = false;

    if (token_stream[index].type == frontend::TokenType::IFTK) // 'if' '(' Cond ')' Stmt [ 'else' Stmt ]
    {
        new Term(token_stream[index++], result);
        new Term(token_stream[index++], result);
        parseCond(result);
        new Term(token_stream[index++], result);
        parseStmt(result);
        // 可选'else' Stmt
        if (token_stream[index].type == frontend::TokenType::ELSETK)
        {
            new Term(token_stream[index++], result);
            parseStmt(result);
        }
        keyword_success = true;
    }
    else if (token_stream[index].type == frontend::TokenType::WHILETK) // 'while' '(' Cond ')' Stmt
    {
        new Term(token_stream[index++], result);
        new Term(token_stream[index++], result);
        parseCond(result);
        new Term(token_stream[index++], result);
        parseStmt(result);
        keyword_success = true;
    }
    else if (token_stream[index].type == frontend::TokenType::BREAKTK) // 'break' ';'
    {
        new Term(token_stream[index++], result);
        new Term(token_stream[index++], result);
        keyword_success = true;
    }
    else if (token_stream[index].type == frontend::TokenType::CONTINUETK) // 'continue' ';'
    {
        new Term(token_stream[index++], result);
        new Term(token_stream[index++], result);
        keyword_success = true;
    }
    else if (token_stream[index].type == frontend::TokenType::RETURNTK) // 'return' [Exp] ';'
    {
        new Term(token_stream[index++], result);
        // 可选Exp
        if (get_first_Exp().count(token_stream[index].type))
        {
            parseExp(result);
        }
        new Term(token_stream[index++], result);
        keyword_success = true;
    }
    bool exp_success = false;
    if (!lval_success && !block_success && !keyword_success && get_first_Exp().count(token_stream[index].type)) // [Exp] ';'
    {
        exp_success = parseExp(result);
        if (exp_success && token_stream[index].type == frontend::TokenType::SEMICN)
            new Term(token_stream[index++], result);
        else
            exp_success = false;
        if (!exp_success)
        {
            revert(saved_index, result, target_child_nums);
        }
        else
        {
            level--;
            return true;
        }
    }

    bool semicn_success = false;

    if (!lval_success && !block_success && !keyword_success && !exp_success && token_stream[index].type == frontend::TokenType::SEMICN) // ';'
    {
        semicn_success = true;
        new Term(token_stream[index++], result);
    }

    if (!lval_success && !block_success && !keyword_success && !exp_success && !semicn_success)
    {
        // error
        level--;
        return false;
    }
    level--;
    return true;
}

// Exp -> AddExp
bool Parser::parseExp(AstNode *parent)
{
    level++;
    Exp *result = new Exp(parent);
    log(result);
    if (!parseAddExp(result))
    {
        level--;
        return false;
    }
    level--;
    return true;
}

// Cond -> LOrExp
bool Parser::parseCond(AstNode *parent)
{
    level++;
    Cond *result = new Cond(parent);
    log(result);
    if (!parseLOrExp(result))
    {
        level--;
        return false;
    }
    level--;
    return true;
}

// LVal -> Ident {'[' Exp ']'}
bool Parser::parseLVal(AstNode *parent)
{
    level++;
    LVal *result = new LVal(parent);
    log(result);
    if (token_stream[index].type != frontend::TokenType::IDENFR)
    {
        level--;
        return false;
    }
    new Term(token_stream[index++], result);
    // 0~n次'[' Exp ']'
    while (token_stream[index].type == frontend::TokenType::LBRACK)
    {
        new Term(token_stream[index++], result);
        if (!parseExp(result))
        {
            level--;
            return false;
        }
        if (token_stream[index].type != frontend::TokenType::RBRACK)
        {
            level--;
            return false;
        }
        new Term(token_stream[index++], result);
    }
    level--;
    return true;
}

// Number -> IntConst | floatConst
bool Parser::parseNumber(AstNode *parent)
{
    level++;
    Number *result = new Number(parent);
    log(result);
    if (token_stream[index].type != frontend::TokenType::INTLTR && token_stream[index].type != frontend::TokenType::FLOATLTR)
    {
        level--;
        return false;
    }
    new Term(token_stream[index++], result);
    level--;
    return true;
}

// PrimaryExp -> '(' Exp ')' | LVal | Number
bool Parser::parsePrimaryExp(AstNode *parent)
{
    level++;
    PrimaryExp *result = new PrimaryExp(parent);
    log(result);

    bool lparent_success = false;
    bool lval_success = false;
    bool number_success = false;

    int saved_index = index;
    int target_child_nums = result->children.size();

    if (token_stream[index].type == frontend::TokenType::LPARENT) // '(' Exp ')'
    {
        new Term(token_stream[index++], result);
        lparent_success = parseExp(result);
        if (lparent_success && token_stream[index].type == frontend::TokenType::RPARENT)
            new Term(token_stream[index++], result);
        else
            lparent_success = false;

        if (!lparent_success)
        {
            revert(saved_index, result, target_child_nums);
        }
    }
    if (!lparent_success && get_first_LVal().count(token_stream[index].type)) // LVal
    {
        lval_success = parseLVal(result);
        if (!lval_success)
        {
            revert(saved_index, result, target_child_nums);
        }
    }
    if (!lparent_success && !lval_success && get_first_Number().count(token_stream[index].type)) // Number
    {
        number_success = parseNumber(result);
    }
    if (!lparent_success && !lval_success && !number_success)
    {
        // error
        level--;
        return false;
    }
    level--;
    return true;
}

// UnaryExp -> PrimaryExp | Ident '(' [FuncRParams] ')' | UnaryOp UnaryExp
bool Parser::parseUnaryExp(AstNode *parent) // 此函数采用纯回溯会出现问题,需要改用LL(2),所以本函数中无视分支
{
    level++;
    UnaryExp *result = new UnaryExp(parent);
    log(result);

    if (token_stream[index].type == frontend::TokenType::IDENFR) // Ident '(' or PrimaryExp
    {
        if (token_stream[index + 1].type == frontend::TokenType::LPARENT)
        {
            // Ident '('
            new Term(token_stream[index++], result);
            new Term(token_stream[index++], result);
            // 可选FuncRParams
            if (get_first_FuncRParams().count(token_stream[index].type))
            {
                if (!parseFuncRParams(result))
                {
                    level--;
                    return false;
                }
            }
            if (token_stream[index].type != frontend::TokenType::RPARENT)
            {
                level--;
                return false;
            }
            // ')'
            new Term(token_stream[index++], result);
            level--;
            return true;
        }
        else // PrimaryExp
        {
            if (!parsePrimaryExp(result))
            {
                level--;
                return false;
            }
            level--;
            return true;
        }
    }
    if (get_first_PrimaryExp().count(token_stream[index].type)) // PrimaryExp
    {
        if (!parsePrimaryExp(result))
        {
            level--;
            return false;
        }
        level--;
        return true;
    }
    if (get_first_UnaryOp().count(token_stream[index].type)) // UnaryOp UnaryExp
    {
        if (!parseUnaryOp(result))
        {
            level--;
            return false;
        }
        if (!parseUnaryExp(result))
        {
            level--;
            return false;
        }
        level--;
        return true;
    }
    level--;
    return false;
}

// UnaryOp -> '+' | '-' | '!'
bool Parser::parseUnaryOp(AstNode *parent)
{
    level++;
    UnaryOp *result = new UnaryOp(parent);
    log(result);
    if (token_stream[index].type != frontend::TokenType::PLUS && token_stream[index].type != frontend::TokenType::MINU && token_stream[index].type != frontend::TokenType::NOT)
    {
        level--;
        return false;
    }
    new Term(token_stream[index++], result);
    level--;
    return true;
}

// FuncRParams -> Exp { ',' Exp }
bool Parser::parseFuncRParams(AstNode *parent)
{
    level++;
    FuncRParams *result = new FuncRParams(parent);
    log(result);
    if (!parseExp(result))
    {
        level--;
        return false;
    }
    // 0~n次',' Exp
    while (token_stream[index].type == frontend::TokenType::COMMA)
    {
        new Term(token_stream[index++], result);
        if (!parseExp(result))
        {
            level--;
            return false;
        }
    }
    level--;
    return true;
}

// MulExp -> UnaryExp { ('*' | '/' | '%') UnaryExp }
bool Parser::parseMulExp(AstNode *parent)
{
    level++;
    MulExp *result = new MulExp(parent);
    log(result);
    if (!parseUnaryExp(result))
    {
        level--;
        return false;
    }
    // 0~n次('*' | '/' | '%') UnaryExp
    while (token_stream[index].type == frontend::TokenType::MULT ||
           token_stream[index].type == frontend::TokenType::DIV ||
           token_stream[index].type == frontend::TokenType::MOD)
    {
        new Term(token_stream[index++], result);
        if (!parseUnaryExp(result))
        {
            level--;
            return false;
        }
    }
    level--;
    return true;
}

// AddExp -> MulExp { ('+' | '-') MulExp }
bool Parser::parseAddExp(AstNode *parent)
{
    level++;
    AddExp *result = new AddExp(parent);
    log(result);
    if (!parseMulExp(result))
    {
        level--;
        return false;
    }
    // 0~n次('+' | '-') MulExp
    while (token_stream[index].type == frontend::TokenType::PLUS ||
           token_stream[index].type == frontend::TokenType::MINU)
    {
        new Term(token_stream[index++], result);
        if (!parseMulExp(result))
        {
            level--;
            return false;
        }
    }
    level--;
    return true;
}

// RelExp -> AddExp { ('<' | '>' | '<=' | '>=') AddExp }
bool Parser::parseRelExp(AstNode *parent)
{
    level++;
    RelExp *result = new RelExp(parent);
    log(result);
    if (!parseAddExp(result))
    {
        level--;
        return false;
    }
    // 0~n次('<' | '>' | '<=' | '>=') AddExp
    while (token_stream[index].type == frontend::TokenType::LSS ||
           token_stream[index].type == frontend::TokenType::GTR ||
           token_stream[index].type == frontend::TokenType::LEQ ||
           token_stream[index].type == frontend::TokenType::GEQ)
    {
        new Term(token_stream[index++], result);
        if (!parseAddExp(result))
        {
            level--;
            return false;
        }
    }
    level--;
    return true;
}

// EqExp -> RelExp { ('==' | '!=') RelExp }
bool Parser::parseEqExp(AstNode *parent)
{
    level++;
    EqExp *result = new EqExp(parent);
    log(result);
    if (!parseRelExp(result))
    {
        level--;
        return false;
    }
    // 0~n次('==' | '!=') RelExp
    while (token_stream[index].type == frontend::TokenType::EQL ||
           token_stream[index].type == frontend::TokenType::NEQ)
    {
        new Term(token_stream[index++], result);
        if (!parseRelExp(result))
        {
            level--;
            return false;
        }
    }
    level--;
    return true;
}

// LAndExp -> EqExp [ '&&' LAndExp ]
bool Parser::parseLAndExp(AstNode *parent)
{
    level++;
    LAndExp *result = new LAndExp(parent);
    log(result);
    if (!parseEqExp(result))
    {
        level--;
        return false;
    }
    // 可选 '&&' LAndExp
    if (token_stream[index].type == frontend::TokenType::AND)
    {
        new Term(token_stream[index++], result);
        if (!parseLAndExp(result))
        {
            level--;
            return false;
        }
    }
    level--;
    return true;
}

// LOrExp -> LAndExp [ '||' LOrExp ]
bool Parser::parseLOrExp(AstNode *parent)
{
    level++;
    LOrExp *result = new LOrExp(parent);
    log(result);
    if (!parseLAndExp(result))
    {
        level--;
        return false;
    }
    // 可选 '||' LOrExp
    if (token_stream[index].type == frontend::TokenType::OR)
    {
        new Term(token_stream[index++], result);
        if (!parseLOrExp(result))
        {
            level--;
            return false;
        }
    }
    level--;
    return true;
}

// ConstExp -> AddExp
bool Parser::parseConstExp(AstNode *parent)
{
    level++;
    ConstExp *result = new ConstExp(parent);
    log(result);
    if (!parseAddExp(result))
    {
        level--;
        return false;
    }
    level--;
    return true;
}

void Parser::log(AstNode *node)
{
#ifdef DEBUG_PARSER
    print_tab(level);
    std::cout << "in parse" << toString(node->type) << ", cur_token_type::" << toString(token_stream[index].type) << ", token_val::" << token_stream[index].value << '\n';
#endif
}
