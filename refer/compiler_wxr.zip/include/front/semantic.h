/**
 * @file semantic.h
 * @author Yuntao Dai (d1581209858@live.com)
 * @brief 
 * @version 0.1
 * @date 2023-01-06
 * 
 * a Analyzer should 
 * @copyright Copyright (c) 2023
 * 
 */

#ifndef SEMANTIC_H
#define SEMANTIC_H

#include"ir/ir.h"
#include"front/abstract_syntax_tree.h"

#include<map>
#include<string>
#include<vector>
using std::map;
using std::string;
using std::vector;

namespace frontend
{

// definition of symbol table entry
struct STE {
    ir::Operand operand;
    vector<int> dimension;
    string literalVal;
};

using map_str_ste = map<string, STE>;
// definition of scope infomation
struct ScopeInfo {
    int cnt;
    string name;
    map_str_ste table;
};

// surpport lib functions
map<std::string,ir::Function*>* get_lib_funcs();

// definition of symbol table
struct SymbolTable{
    vector<ScopeInfo> scope_stack; // size用于指示当前是否在全局状态 (1为全局，>1则不为全局)
    map<std::string,ir::Function*> functions;
    int block_cnt = 0;

    /**
     * @brief enter a new scope
     */
    void add_scope();

    /**
     * @brief exit a scope, pop out informations
     */
    void exit_scope();

    void add_ste(string id, STE ste);

    string get_scoped_name(string id) const;

    /**
     * @brief get the right operand with the input name
     * @param id identifier name
     * @return Operand 
     */
    ir::Operand get_operand(string id) const;

    /**
     * @brief get the right ste with the input name
     * @param id identifier name
     * @return STE 
     */
    STE get_ste(string id) const;
};



// singleton class
struct Analyzer {
    int tmp_cnt;
    vector<ir::Instruction*> g_init_inst; // 全局变量初始化指令
    SymbolTable symbol_table;
    ir::Program ir_program;
    ir::Function* curr_function = nullptr;

    /**
     * @brief constructor
     */
    Analyzer();

    // analysis functions
    ir::Program get_ir_program(CompUnit*);
    void analyze_compunit(CompUnit*);
    vector<ir::Instruction *> analyze_decl(Decl*);
    void analyze_funcdef(FuncDef*);
    ir::Type analyze_functype(FuncType*);
    string analyze_ident(Term*);
    vector<ir::Operand> analyze_funcfparams(FuncFParams*);
    ir::Type analyze_btype(BType*);
    vector<ir::Instruction *> calculate_exp(Exp*); // 可能需要指令辅助
    void calculate_constexp(ConstExp*); // 兼容函数参数头的Exp (Exp->AddExp , ConstExp->AddExp) 结果写入到AddExp.v, 类型写入到AddExp.t
    vector<ir::Instruction *> calculate_addexp(AddExp*);
    vector<ir::Instruction *> calculate_mulexp(MulExp*);
    vector<ir::Instruction *> calculate_unaryexp(UnaryExp*);
    vector<ir::Instruction *> calculate_primaryexp(PrimaryExp*);
    vector<ir::Instruction *> calculate_lval(LVal*); 
    void calculate_number(Number*);
    vector<ir::Instruction *> analyze_block(Block*, bool);
    vector<ir::Instruction *> analyze_blockitem(BlockItem*);
    vector<ir::Instruction *> analyze_stmt(Stmt*);
    vector<ir::Instruction *> analyze_constdecl(ConstDecl*);
    vector<ir::Instruction *> analyze_vardecl(VarDecl*);

    vector<ir::Instruction *> calculate_cond(Cond*);
    vector<ir::Instruction *> calculate_lorexp(LOrExp*);
    vector<ir::Instruction *> calculate_landexp(LAndExp*);
    vector<ir::Instruction *> calculate_eqexp(EqExp*);
    vector<ir::Instruction *> calculate_relexp(RelExp*);
    

    // reject copy & assignment
    Analyzer(const Analyzer&) = delete;
    Analyzer& operator=(const Analyzer&) = delete;
};

} // namespace frontend

#endif