#ifndef GENERARATOR_H
#define GENERARATOR_H

#include "ir/ir.h"
#include "backend/rv_def.h"

#include<unordered_map>
#include<unordered_set>
#include<string>
#include<vector>
#include<fstream>

namespace backend {

struct Interval {
    std::string operand_name;
    int start;
    int end;
    ir::Type type;
};

// 最简单的变量位置管理器（每当遇到一个新变量或变量使用完毕，则将其存储在栈中，效率极低，需要使用时再从栈中加载出来）, 与Generator中生成指令的函数配合使用,
// struct registerAllocator {
//     std::unordered_map<std::string, int> stack_offset_table; // 记录变量在栈中的位置, $sp + stack_offset_table[name]
//     const ir::Function* curr_func = nullptr; // 当前正在生成的函数
//     int stack_size; // 在生成一个函数之前，遍历扫描函数，检测函数中涉及到的变量数目

//     std::unordered_set<std::string> global_vars; // 全局变量表, 用于处理函数调用, 函数调用前需将所有全局变量还原至原内存

//     void init_func(const ir::Function*); // 初始化函数, 估算本函数需要的栈空间, 安排函数参数（包含指令中涉及到的所有参数）所在位置
//     int get_offset(const std::string&); // 获得变量在栈中的位置
//     bool is_global(const std::string&); // 判断变量是否为全局变量
// };


struct Generator {
    const ir::Program& program;         // the program to gen
    std::ofstream& fout;                 // output file

    // registerAllocator迁移到Generator中
    std::unordered_map<std::string, int> stack_offset_table; // 记录变量在栈中的位置, $sp + stack_offset_table[name]
    const ir::Function* curr_func = nullptr; // 当前正在生成的函数
    int stack_size; // 在生成一个函数之前，遍历扫描函数，检测函数中涉及到的变量数目

    std::unordered_set<std::string> global_vars; // 全局变量表, 用于处理函数调用, 函数调用前需将所有全局变量还原至原内存

    // 被调用者需要保存的寄存器 (其实RA不算callee保存, 但为了实现简单, 一起保存)
    std::vector<rv::rvREG> saved_callee_regs {rv::rvREG::S0,rv::rvREG::S1,rv::rvREG::S2,rv::rvREG::S3,rv::rvREG::S4,rv::rvREG::S5,rv::rvREG::S6,rv::rvREG::S7,rv::rvREG::S8,rv::rvREG::S9,rv::rvREG::S10,rv::rvREG::S11,
                                              rv::rvREG::RA};
    std::string saved_callee_stack_prefix = "saved_callee_"; // 被调用者保存的寄存器在栈表中命名的前缀
    // 所有可用的整数寄存器
    std::vector<rv::rvREG> int_regs {rv::rvREG::T0,rv::rvREG::T1,rv::rvREG::T2,rv::rvREG::T3,rv::rvREG::T4,rv::rvREG::T5,rv::rvREG::T6,
                                     rv::rvREG::S0,rv::rvREG::S1,rv::rvREG::S2,rv::rvREG::S3,rv::rvREG::S4,rv::rvREG::S5,rv::rvREG::S6,rv::rvREG::S7,rv::rvREG::S8,rv::rvREG::S9,rv::rvREG::S10,rv::rvREG::S11};
                                    //    "a0","a1","a2","a3","a4","a5","a6","a7"}; (参数寄存器由自己分配控制)

    std::unordered_set<rv::rvREG> free_int_regs;

    // 用于跳转到指定IR地址, 记录地址->标签的映射
    std::unordered_map<int, std::string> jump_label_map;
    // 当前正在生成指令的IR地址
    int curr_ir_addr;

    // 用于生成不重复的跳转标签
    int label_count = 0;

    // 用于记录当前栈空间除了存放变量外, 底下还使用了多少空间(byte) (用于开局部数组)
    int curr_stack_used_bytes;

    void init_func(const ir::Function*); // 初始化函数, 估算本函数需要的栈空间, 安排函数参数（包含指令中涉及到的所有参数）所在位置
    int get_offset(const std::string&); // 获得变量在栈中的位置
    bool is_global(const std::string&); // 判断变量是否为全局变量


    Generator(ir::Program&, std::ofstream&);

    const ir::Function* curr_function = nullptr; // 当前生成函数的指针

    // reg allocate api
    // rv::rvREG getRd(ir::Operand);
    // rv::rvREG getRs1(ir::Operand);
    // rv::rvREG getRs2(ir::Operand);

    rv::rvREG alloc_and_load_int_reg(ir::Operand);

    rv::rvREG alloc_int_reg();

    // reg free or save api
    void free_int_reg(rv::rvREG int_reg);

    void save_int_operand(ir::Operand operand, rv::rvREG int_reg);

    // generate wrapper function
    void gen();
    void gen_func(const ir::Function&);
    void gen_instr(const ir::Instruction&);

    // 自定义生成函数
    void gen_global_data(); // 处理全局变量

    void gen_instr_mov(const ir::Instruction& instr);
    void gen_instr_unuse(const ir::Instruction& instr);

    // 算术函数
    void gen_instr_add(const ir::Instruction& instr); // 只有add, 没有addi, 因为我在LAB2中没有使用addi
    void gen_instr_sub(const ir::Instruction& instr); // 只有sub, 没有subi, 因为我在LAB2中没有使用subi
    void gen_instr_mul(const ir::Instruction& instr);
    void gen_instr_div(const ir::Instruction& instr);
    void gen_instr_mod(const ir::Instruction& instr);

    // 逻辑运算函数
    void gen_instr_lss(const ir::Instruction& instr);
    void gen_instr_leq(const ir::Instruction& instr);
    void gen_instr_gtr(const ir::Instruction& instr);
    void gen_instr_geq(const ir::Instruction& instr);
    void gen_instr_eq(const ir::Instruction& instr);
    void gen_instr_neq(const ir::Instruction& instr);
    void gen_instr_not(const ir::Instruction& instr);
    void gen_instr_and(const ir::Instruction& instr);
    void gen_instr_or(const ir::Instruction& instr);

    // 访存与指针运算
    void gen_instr_alloc(const ir::Instruction& instr);
    void gen_instr_load(const ir::Instruction& instr);
    void gen_instr_store(const ir::Instruction& instr);
    void gen_instr_getptr(const ir::Instruction& instr);

    // 调用返回
    void gen_instr_return(const ir::Instruction& instr);
    void gen_instr_call(const ir::Instruction& instr);

    // 跳转
    void gen_instr_goto(const ir::Instruction& instr);

    // 自定义输出函数
    void set_nopic();
    void set_data();
    void set_bss();
    void set_label(const std::string&);
    void set_text();
};



} // namespace backend


#endif