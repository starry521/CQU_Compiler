float a = 0.0;

float test_func()
{
    a = 2.2;
    return a;
}

int main()
{
    a = 1.1;
    test_func();
    return 0;
}