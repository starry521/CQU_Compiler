//test array define
int main(){
    int a[100][100] = {};
    int b[4][2] = {1, 2, 3, 4, 5, 6, 7, 8};
    return b[3][1] + b[0][0] + b[0][1] + b[2][0];
}