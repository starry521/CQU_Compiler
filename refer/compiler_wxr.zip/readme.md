# 重庆大学 2022 编译原理实验1、2、3

## 每个实验内容所在文件位置
- 实验1:/src/front/syntax.cpp, /src/front/lexical.cpp + 相应的头文件
- 实验2:/src/front/semantic.cpp + 相应的头文件
- 实验3:/src/backend/generator.cpp (没有实现浮点数) + 相应的头文件

## 代码量更少,可读性更高的实验1、2
使用实验框架宏,代码量更少,可读性更高的实验1、2: https://github.com/Khoray/CompilerLab

## 目录结构
目录结构： \
/bin		可执行文件 + 库文件 \
/build		构建项目的文件 \
/include	头文件 \
/src		源代码 \
/src/...	子模块: IR, frontend, backend, opt \
            third_party: 第三方库, 目前使用了 jsoncpp 用于生成和读取 json \
/test       测试框架, 可以用于自测 \
/CMakeList.txt \
/readme.md